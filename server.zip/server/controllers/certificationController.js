const UserCertification = require("../models/UserCertification");
const Certification = require("../models/Certification");

exports.getUserCertifications = async (req, res) => {
    try {
        const user_number = req.user.id; // Get user ID from JWT

        const certifications = await UserCertification.findAll({
            where: { user_number: user_number },
            include: [{ model: Certification, attributes: ["name"] }],
            attributes: ["valid_until"]
        });

        res.json(certifications);
    } catch (error) {
        res.status(500).json({ message: "Server error", error });
    }
};
