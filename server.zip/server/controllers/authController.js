const jwt = require("jsonwebtoken");
const User = require("../models/User");
require("dotenv").config();

exports.login = async (req, res) => {
    console.log("Login Request Body:", req.body); // Debug incoming request

    const { email, password } = req.body;

    try {
        const user = await User.findOne({ where: { email } });

        if (!user) {
            console.log("❌ User not found:", email);
            return res.status(400).json({ message: "User not found" });
        }

        if (user.password !== password) { // Directly compare plain text passwords
            console.log("❌ Invalid password for:", email);
            return res.status(400).json({ message: "Invalid credentials" });
        }

        // Generate JWT Token
        const token = jwt.sign(
            { id: user.employee_number, position: user.position },
            process.env.JWT_SECRET,
            { expiresIn: "1h" }
        );

        console.log("✅ Login successful:", user.employee_number);
        res.json({ id: user.employee_number, token });
    } catch (error) {
        console.error("❌ Server error:", error);
        res.status(500).json({ message: "Server error", error });
    }
};

exports.logout = (req, res) => {
    console.log("✅ Logout successful");
    res.json({ message: "Logout successful. Clear token on the client side." });
};
