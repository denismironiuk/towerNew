const User = require("../models/User");

exports.getWorkersForManager = async (req, res) => {
    try {
        const manager_number = req.user.id; // Get manager's ID from JWT

        const workers = await User.findAll({
            where: { manager_number: manager_number },
            attributes: ["employee_number", "name", "position", "department", "email"]
        });

        res.json(workers);
    } catch (error) {
        res.status(500).json({ message: "Server error", error });
    }
};
