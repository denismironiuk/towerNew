const { Sequelize } = require('sequelize');
require('dotenv').config();

const sequelize = new Sequelize(
    process.env.DB_NAME, 
    process.env.DB_USER, 
    process.env.DB_PASS, 
    {
        host: 'localhost',  // XAMPP uses localhost or 127.0.0.1
        dialect: 'mysql',
        port: 3306,         // Default MySQL port in XAMPP
        logging: false
    }
);

module.exports = sequelize;
