const { DataTypes } = require("sequelize");
const sequelize = require("../config/db");

const Certification = sequelize.define(
    "Certification",
    {
        id: {
            type: DataTypes.INTEGER,
            autoIncrement: true,
            primaryKey: true
        },
        name: {
            type: DataTypes.STRING(100),
            allowNull: false,
            unique: true
        }
    },
    {
        tableName: "certifications",
        timestamps: false
    }
);

module.exports = Certification;
