const { DataTypes } = require("sequelize");
const sequelize = require("../config/db");

const User = sequelize.define(
    "User",
    {
        employee_number: {
            type: DataTypes.STRING(20),
            primaryKey: true,
            allowNull: false
        },
        name: {
            type: DataTypes.STRING(100),
            allowNull: false
        },
        email: {
            type: DataTypes.STRING(100),
            allowNull: false,
            unique: true,
            validate: {
                isEmail: true
            }
        },
        password: {
            type: DataTypes.STRING(255),
            allowNull: false
        },
        position: {
            type: DataTypes.ENUM("user", "sam", "admin"),
            allowNull: false
        },
        department: {
            type: DataTypes.STRING(50),
            allowNull: true
        },
        manager_number: {
            type: DataTypes.STRING(20),
            allowNull: true
        }
    },
    {
        tableName: "users",
        timestamps: false
    }
);

// Define self-referencing relationship (optional)
User.hasMany(User, { foreignKey: "manager_number", as: "subordinates" });
User.belongsTo(User, { foreignKey: "manager_number", as: "manager" });

module.exports = User;
