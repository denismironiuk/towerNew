const { DataTypes } = require("sequelize");
const sequelize = require("../config/db");
const User = require("./User");
const Certification = require("./Certification");

const UserCertification = sequelize.define(
    "UserCertification",
    {
        id: {
            type: DataTypes.INTEGER,
            autoIncrement: true,
            primaryKey: true
        },
        user_number: {
            type: DataTypes.STRING(20),
            allowNull: false,
            references: {
                model: User,
                key: "employee_number"
            }
        },
        certification_id: {
            type: DataTypes.INTEGER,
            allowNull: false,
            references: {
                model: Certification,
                key: "id"
            }
        },
        valid_until: {
            type: DataTypes.DATE,
            allowNull: false
        }
    },
    {
        tableName: "user_certifications",
        timestamps: false
    }
);

// Define associations
User.belongsToMany(Certification, { through: UserCertification, foreignKey: "user_number" });
Certification.belongsToMany(User, { through: UserCertification, foreignKey: "certification_id" });

module.exports = UserCertification;
