const express = require("express");
const { authenticate } = require("../middleware/authMiddleware");
const { getUserCertifications } = require("../controllers/certificationController");

const router = express.Router();
router.get("/user-certifications", authenticate, getUserCertifications);

module.exports = router;
