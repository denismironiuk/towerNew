const express = require("express");
const { login, logout } = require("../controllers/authController");

const router = express.Router();
router.post("/login", login);
router.post("/logout", logout); // Logout is handled on the client side

module.exports = router;
