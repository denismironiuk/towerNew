const express = require("express");
const { authenticate, authorize } = require("../middleware/authMiddleware");
const { getWorkersForManager } = require("../controllers/userController");

const router = express.Router();
router.get("/workers", authenticate, authorize(["sam", "admin"]), getWorkersForManager);

module.exports = router;
