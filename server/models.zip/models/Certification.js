import { DataTypes } from "sequelize";
import sequelize from "../config/database.js"; // ✅ Added .js extension

const Certification = sequelize.define(
  "Certification",
  {
    id: {
      type: DataTypes.INTEGER,
      autoIncrement: true,
      primaryKey: true,
    },
    name: {
      type: DataTypes.STRING(100),
      allowNull: false,
      unique: true,
    },
    expires: {
      type: DataTypes.DATE,
      allowNull: false,
    },
  },
  {
    tableName: "certifications",
    timestamps: false,
  }
);

export default Certification;
