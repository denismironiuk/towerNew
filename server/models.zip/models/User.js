import { DataTypes } from "sequelize";
import sequelize from "../config/database.js";

const User = sequelize.define(
  "User",
  {
    employee_number: {
      type: DataTypes.STRING(20),
      primaryKey: true,
      allowNull: false,
    },
    name: {
      type: DataTypes.STRING(100),
      allowNull: false,
    },
    email: {
      type: DataTypes.STRING(100),
      allowNull: false,
      unique: true,
      validate: {
        isEmail: true,
      },
    },
    password: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    position: {
      type: DataTypes.ENUM("user", "sam", "admin"),
      allowNull: false,
    },
    department: {
      type: DataTypes.STRING(50),
      allowNull: true,
    },
    manager_number: {
      type: DataTypes.STRING(20),
      allowNull: true,
    },
  },
  {
    tableName: "users",
    timestamps: false,
  }
);

// ✅ Self-referencing relationship
User.hasMany(User, { foreignKey: "manager_number", as: "subordinates" });
User.belongsTo(User, { foreignKey: "manager_number", as: "manager" });

// ✅ Lazy-load associations
import Certification from "./Certification.js";
import UserCertification from "./UserCertification.js";
import UserTutorial from "./UserTutorial.js";
import Tutorial from "./Tutorial.js";


// 🔗 Certification relationship
User.belongsToMany(Certification, {
  through: UserCertification,
  foreignKey: "user_number",
  otherKey: "certification_id",
  as: "certifications",
});
User.hasMany(UserCertification, {
  foreignKey: "user_number",
  sourceKey: "employee_number",
});
UserCertification.belongsTo(User, {
  foreignKey: "user_number",
  targetKey: "employee_number",
});

// 🔗 Tutorial relationship
User.hasMany(UserTutorial, {
  foreignKey: "employee_number",
  sourceKey: "employee_number",
});
UserTutorial.belongsTo(User, {
  foreignKey: "employee_number",
  targetKey: "employee_number",
});


export default User;
