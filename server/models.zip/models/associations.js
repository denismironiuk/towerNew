import User from './User.js'; 
import AuditRecord from './AuditRecord.js'; 

// Define associations after models are imported
User.hasMany(AuditRecord, {
  foreignKey: 'employee_number',
  as: 'auditRecords', // Alias for association
});

AuditRecord.belongsTo(User, {
  foreignKey: 'employee_number',
  targetKey: 'employee_number',
  as: 'employee', // Alias for inverse relationship
  onDelete: 'CASCADE', // Optional: Ensure audit records are deleted when the user is deleted
});
AuditRecord.belongsTo(User, {
    foreignKey: "fab_manager_id",
    targetKey: "employee_number",
    as: "fabManager", // This alias should be used in the `include`
    onDelete: "CASCADE",
  });
  