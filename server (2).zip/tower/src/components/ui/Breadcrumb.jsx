// Breadcrumb.jsx
import React from "react";
import styles from "./Breadcrumb.module.css";
import { Link, useNavigate } from "react-router-dom";

const Breadcrumb = ({ onSave, isSaving }) => {
  const navigate = useNavigate();

  return (
    <div className={styles.breadcrumb}>
      <div>
        <Link to="/dashboard">Home</Link> &gt; <span>Create Audit</span>
      </div>
      <div className={styles.auditActions}>
        <button className={styles.save} onClick={onSave} disabled={isSaving}>
          {isSaving ? "Saving..." : "Save"}
        </button>
        <button className={styles.exit} onClick={() => navigate("/profile")}>Exit</button>
      </div>
    </div>
  );
};

export default Breadcrumb;
