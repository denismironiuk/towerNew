import React from "react";
import { useNavigate } from "react-router-dom"; // ✅ Import useNavigate
import styles from "./AuditActions.module.css";

const AuditActions = ({ handleSubmit }) => {
  const navigate = useNavigate(); // ✅ Initialize useNavigate

  return (
    <div className={styles.actions}>
      <button className={styles.save} onClick={handleSubmit}>Submit</button>
      
      {/* ✅ Exit button now redirects back to Profile Page */}
      <button className={styles.exit} onClick={() => navigate("/profile")}>
        Exit
      </button>
    </div>
  );
};

export default AuditActions;
