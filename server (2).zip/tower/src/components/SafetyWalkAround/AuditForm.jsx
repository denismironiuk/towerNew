import { useEffect, useState } from "react";
import styles from "./AuditForm.module.css";
import AuditSection from "./AuditSection";

const AuditForm = ({ formData, setFormData }) => {
  const [auditSections, setAuditSections] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // ✅ Fetch audit sections & questions using fetch API
  useEffect(() => {
    const fetchAuditData = async () => {
      try {
        // ✅ Fetch sections
        const sectionsResponse = await fetch("http://localhost:5000/api/audit/sections");
        if (!sectionsResponse.ok) throw new Error("Failed to fetch audit sections.");
        const sections = await sectionsResponse.json();

        // ✅ Fetch questions for each section
        const questionsPromises = sections.map((section) =>
          fetch(`http://localhost:5000/api/audit/sections/${section.sectionId}/questions`).then((res) =>
            res.ok ? res.json() : Promise.reject(`Failed to load questions for ${section.sectionId}`)
          )
        );

        const questionsData = await Promise.all(questionsPromises);

        // ✅ Combine sections & questions
        const formattedSections = sections.map((section, index) => ({
          ...section,
          questions: questionsData[index] || [],
        }));

        setAuditSections(formattedSections);
      } catch (err) {
        console.error("❌ Error fetching audit data:", err);
        setError(err.message || "Failed to load audit data.");
      } finally {
        setLoading(false);
      }
    };

    fetchAuditData();
  }, []);

  // ✅ Handle form field updates
  const updateFormData = (sectionId, questionId, field, value) => {
    setFormData((prev) => ({
      ...prev,
      [sectionId]: {
        ...prev[sectionId],
        [questionId]: {
          ...prev[sectionId]?.[questionId],
          [field]: value,
        },
      },
    }));
  };

  if (loading) return <p>Loading audit data...</p>;
  if (error) return <p style={{ color: "red" }}>{error}</p>;

  return (
    <div className={styles.auditForm}>
      {auditSections.map((section) => (
        <AuditSection
          key={section.sectionId}
          title={section.title}
          sectionId={section.sectionId}
          questions={section.questions}
          updateFormData={updateFormData}
          formData={formData}
        />
      ))}
    </div>
  );
};

export default AuditForm;
