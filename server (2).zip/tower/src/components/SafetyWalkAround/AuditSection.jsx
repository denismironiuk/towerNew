import React from "react";
import styles from "./AuditSection.module.css";
import AuditRow from "./AuditRow";

const AuditSection = ({ title, sectionId, questions, updateFormData, formData }) => {
  return (
    <div className={styles.auditSection}>
      <h2>{title}</h2>
      <div className={styles.table}>
        <div className={styles.header}>
          <span>Question</span>
          <span>Score</span>
          <span>Issue Found</span>
          <span>Corrective Actions</span>
          {/* <span>Follow Up</span> */}
        </div>
        {questions.map((q) => (
          <AuditRow
            key={q.id}
            sectionId={sectionId}
            questionId={q.id}
            text={q.text}
            example={q.example}
            updateFormData={updateFormData}
            savedData={formData?.[sectionId]?.[q.id]}  // ✅ Pass correct data for each row
          />
        ))}
      </div>
    </div>
  );
};

export default AuditSection;
