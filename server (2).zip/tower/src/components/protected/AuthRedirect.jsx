import { Navigate } from "react-router-dom";
import { useContext } from "react";
import AuthContext from "../../context/AuthContext"; // ✅ Import `AuthContext`

const AuthRedirect = ({ children }) => {
  const { user } = useContext(AuthContext); // ✅ Use `useContext(AuthContext)`

  if (user && user.position) {
    return <Navigate to={user.position === "admin" ? "/dashboard" : "/profile"} replace />;
  }

  return children; // ✅ If not logged in, show login page
};

export default AuthRedirect;
