import React, { useContext } from "react";
import { Navigate, Outlet } from "react-router-dom";
import AuthContext from "../../context/AuthContext";  // ✅ Import `AuthContext`

const ProtectedRoute = ({ allowedRoles,children }) => {
    const { token, user,logout } = useContext(AuthContext);  // ✅ Use `useContext(AuthContext)`

    console.log("🔍 Checking ProtectedRoute:", { token, user });

    // 🔴 Fix: Check if user exists before accessing `position`
    if (!token || !user) {
        logout()
        console.log("🚨 No token found! Redirecting to /login...");
        return <Navigate to="/login" replace />;
    }

    // 🔴 Fix: Ensure `user.position` exists before checking roles
    if (allowedRoles && (!user.position || !allowedRoles.includes(user.position))) {
        console.log(`🚨 User with position "${user.position}" is not authorized. Redirecting to /unauthorized...`);
        return <Navigate to="/unauthorized" replace />;
    }

    console.log("✅ User is authorized! Rendering Outlet...");
    return children;
};

export default ProtectedRoute;
