import React from "react";
import styles from "./EmployeeTable.module.css";

const EmployeeTable = ({ employees }) => (
  <table className={styles.table}>
    <thead>
      <tr>
        <th>Badge</th>
        <th>First Name</th>
        <th>Last Name</th>
        <th>Job Title</th>
        <th>Email</th>
      </tr>
    </thead>
    <tbody>
      {employees.length ? (
        employees.map((employee, index) => (
          <tr key={index}>
            <td><a href={`mailto:${employee.email}`}>{employee.badge}</a></td>
            <td>{employee.firstName}</td>
            <td>{employee.lastName}</td>
            <td>{employee.jobTitle}</td>
            <td><a href={`mailto:${employee.email}`}>{employee.email}</a></td>
          </tr>
        ))
      ) : (
        <tr>
          <td colSpan="5" className={styles.noResults}>
            No employees found
          </td>
        </tr>
      )}
    </tbody>
  </table>
);

export default EmployeeTable;
