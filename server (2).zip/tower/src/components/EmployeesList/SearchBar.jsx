import React from "react";
import styles from "./SearchBar.module.css";

const SearchBar = ({ searchQuery, setSearchQuery }) => (
  <div className={styles.searchBar}>
    <input
      type="text"
      placeholder="Search by name, badge, job title..."
      value={searchQuery}
      onChange={e => setSearchQuery(e.target.value)}
    />
    <button onClick={() => setSearchQuery("")}>Clear</button>
  </div>
);

export default SearchBar;
