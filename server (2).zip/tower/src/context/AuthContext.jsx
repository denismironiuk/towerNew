import React, { createContext, useState } from "react";

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  // ✅ Load token and user from localStorage (No useEffect needed)
  const storedToken = localStorage.getItem("token");
  const storedUser = JSON.parse(localStorage.getItem("user"));

  const [token, setToken] = useState(storedToken);
  const [user, setUser] = useState(storedUser || {});

  // ✅ Secure Login Function
  const login = (access_token, refresh_token, userData) => {
    localStorage.setItem("token", access_token);
    localStorage.setItem("refreshToken", refresh_token);
    localStorage.setItem("user", JSON.stringify(userData));

    setToken(access_token);
    setUser(userData);
  };

   // ✅ Logout & clear data
   const logout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("refreshToken");
    localStorage.removeItem("user");

    setToken(null);
    setUser({});
  };

  return (
    <AuthContext.Provider value={{ token, user, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

// ❌ Removed useAuth()
export default AuthContext;
