-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1
-- Время создания: Мар 26 2025 г., 08:35
-- Версия сервера: 10.4.32-MariaDB
-- Версия PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `tower`
--

-- --------------------------------------------------------

--
-- Структура таблицы `auditquestions`
--

CREATE TABLE `auditquestions` (
  `id` int(11) NOT NULL,
  `sectionId` varchar(255) NOT NULL,
  `questionId` varchar(255) NOT NULL,
  `text` text NOT NULL,
  `example` text DEFAULT NULL,
  `createdAt` datetime DEFAULT current_timestamp(),
  `updatedAt` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `auditquestions`
--

INSERT INTO `auditquestions` (`id`, `sectionId`, `questionId`, `text`, `example`, `createdAt`, `updatedAt`) VALUES
(1, 'section1', 'q1', 'Slip/trip hazards on floor?', 'Example: Wipes, packaging material, liquids, power cords, umbilical cords, etc.', '2025-03-18 09:54:39', '2025-03-18 09:54:39'),
(2, 'section1', 'q2', 'Falling objects - above or below?', 'Holes in floor or overhead that tools could drop through?', '2025-03-18 09:54:39', '2025-03-18 09:54:39'),
(3, 'section1', 'q3', 'Barricading Hazards?', 'Are all Raised Metal Floor openings properly barricaded?', '2025-03-18 09:54:39', '2025-03-18 09:54:39'),
(4, 'section1', 'q4', 'Is area or chase organized per local site requirements?', 'Work area and storage area cleanliness?', '2025-03-18 09:54:39', '2025-03-18 09:54:39'),
(5, 'section2', 'q5', 'Is the buddy system being used when required?', 'Are the appropriate number of CEs/customer technicians present?', '2025-03-18 09:54:39', '2025-03-18 09:54:39'),
(6, 'section2', 'q6', 'Customer Spec or AMAT Procedure available?', 'If PTP required, is it properly completed and present?', '2025-03-18 09:54:39', '2025-03-18 09:54:39'),
(7, 'section2', 'q7', 'Is a procedure or PTP in use for work as required?', 'Is an appropriate procedure being used?', '2025-03-18 09:54:39', '2025-03-18 09:54:39'),
(8, 'section2', 'q8', 'Proper ergonomic precautions being followed?', 'Proper lifting procedures, minimizing prolonged tasks, etc.', '2025-03-18 09:54:39', '2025-03-18 09:54:39'),
(9, 'section2', 'q9', 'Are proper use of LOTO and/or interlock defeating programs being followed?', 'Is LOTO stocked in the proper location or readily available?', '2025-03-18 09:54:39', '2025-03-18 09:54:39'),
(10, 'section2', 'q10', 'Job specific PPE being used?', 'Fall protection, bump caps, breathing air, safety equipment, etc.', '2025-03-18 09:54:39', '2025-03-18 09:54:39'),
(11, 'section3', 'q11', 'Shower / Eye Wash available and unobstructed?', 'Are showers and/or eye wash stations available and unobstructed?', '2025-03-18 09:54:39', '2025-03-18 09:54:39'),
(12, 'section3', 'q12', 'Emergency exits and signage in place?', 'Are any egress paths or exit doors blocked?', '2025-03-18 09:54:39', '2025-03-18 09:54:39'),
(13, 'section3', 'q13', 'Fire Extinguishers Present?', 'Fire extinguishers nearby and not blocked?', '2025-03-18 09:54:39', '2025-03-18 09:54:39'),
(14, 'section3', 'q14', 'Telephones in area functional?', 'Verify dial tone. Do you know the emergency phone number?', '2025-03-18 09:54:39', '2025-03-18 09:54:39'),
(15, 'section4', 'q15', 'Ladder / step stools properly stored?', 'Ladders secured in place in racks or storage area?', '2025-03-18 09:54:39', '2025-03-18 09:54:39'),
(16, 'section4', 'q16', 'Are chemicals stored and used properly?', 'Are chemical cabinets available nearby and utilized?', '2025-03-18 09:54:39', '2025-03-18 09:54:39'),
(17, 'section4', 'q17', 'Are hand tools available and in good condition?', 'No frayed cords? Calibration completed if required?', '2025-03-18 09:54:39', '2025-03-18 09:54:39'),
(18, 'section4', 'q18', 'Are customer provided support equipment in good repair?', 'Are carts, lifting devices, toolboxes in good condition?', '2025-03-18 09:54:39', '2025-03-18 09:54:39');

-- --------------------------------------------------------

--
-- Структура таблицы `auditrecords`
--

CREATE TABLE `auditrecords` (
  `id` int(11) NOT NULL,
  `employee_number` varchar(255) NOT NULL,
  `fab_manager_id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `date_completed` date NOT NULL,
  `location` varchar(255) NOT NULL,
  `shift` enum('Morning','Night') NOT NULL,
  `fab_area` varchar(255) NOT NULL,
  `toolset` varchar(255) NOT NULL,
  `additional_details` text DEFAULT NULL,
  `auditStatus` enum('Completed','Incomplete','Canceled') NOT NULL DEFAULT 'Incomplete',
  `createdAt` datetime NOT NULL DEFAULT current_timestamp(),
  `updatedAt` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `auditrecords`
--

INSERT INTO `auditrecords` (`id`, `employee_number`, `fab_manager_id`, `name`, `date_completed`, `location`, `shift`, `fab_area`, `toolset`, `additional_details`, `auditStatus`, `createdAt`, `updatedAt`) VALUES
(1, 'FIN001', 'SAM002', 'Ethan Walker', '2025-03-18', 'Fab1', 'Night', 'Etch', 'AMAT', NULL, 'Incomplete', '2025-03-18 13:09:00', '2025-03-18 13:09:00'),
(2, 'FIN001', 'SAM003', 'Ethan Walker', '2025-03-18', 'Fab2', 'Morning', 'Etch', 'AMAT', NULL, 'Incomplete', '2025-03-18 13:18:31', '2025-03-18 13:18:31'),
(3, 'FIN001', 'SAM005', 'Ethan Walker', '2025-03-18', 'Fab1', 'Morning', 'Etch', 'LAM', NULL, 'Incomplete', '2025-03-18 13:21:52', '2025-03-18 13:21:52'),
(4, 'FIN001', 'SAM003', 'Ethan Walker', '2025-03-18', 'Fab1', 'Morning', 'Deposition', 'AMAT', NULL, 'Incomplete', '2025-03-18 19:50:26', '2025-03-18 19:50:26'),
(5, 'FIN001', 'SAM002', 'Ethan Walker', '2025-03-18', 'Fab2', 'Morning', 'Deposition', 'AMAT', NULL, 'Incomplete', '2025-03-18 20:25:20', '2025-03-18 20:25:20'),
(6, 'SAM002', 'SAM003', 'Bob Manager', '2025-03-21', 'Fab1', 'Morning', 'Etch', 'AMAT', 'dvfsdfs', 'Incomplete', '2025-03-21 19:29:36', '2025-03-21 19:29:36'),
(8, 'SAM002', 'SAM003', 'Bob Manager', '2025-03-24', 'Fab1', 'Morning', 'Etch', 'AMAT', NULL, 'Incomplete', '2025-03-24 08:16:09', '2025-03-24 08:16:09'),
(9, 'SAM002', 'SAM002', 'Bob Manager', '2025-03-24', 'Fab1', 'Morning', 'Etch', 'AMAT', NULL, 'Incomplete', '2025-03-24 08:18:36', '2025-03-24 08:18:36'),
(10, 'SAM002', 'SAM001', 'Bob Manager', '2025-03-24', 'Fab1', 'Night', 'Etch', 'AMAT', NULL, 'Incomplete', '2025-03-24 08:20:13', '2025-03-24 08:20:13'),
(11, 'SAM002', 'SAM002', 'Bob Manager', '2025-03-24', 'Fab2', 'Morning', 'Etch', 'LAM', NULL, 'Incomplete', '2025-03-24 08:25:53', '2025-03-24 08:25:53'),
(12, 'SAM002', 'SAM002', 'Bob Manager', '2025-03-24', 'Fab1', 'Morning', 'Deposition', 'AMAT', NULL, '', '2025-03-24 08:34:31', '2025-03-24 08:34:36'),
(13, 'SAM002', 'SAM003', 'Bob Manager', '2025-03-24', 'Fab1', 'Night', 'Etch', 'AMAT', NULL, '', '2025-03-24 08:42:18', '2025-03-24 08:43:15'),
(14, 'SAM002', 'SAM003', 'Bob Manager', '2025-03-24', 'Fab1', 'Morning', 'Etch', 'AMAT', NULL, 'Completed', '2025-03-24 08:48:22', '2025-03-24 08:48:36'),
(15, 'SAM002', 'SAM002', 'Bob Manager', '2025-03-25', 'Fab1', 'Morning', 'Etch', 'AMAT', NULL, 'Incomplete', '2025-03-25 11:34:53', '2025-03-25 11:34:53'),
(16, 'SAM002', 'SAM002', 'Bob Manager', '2025-03-25', 'Fab1', 'Morning', 'Etch', 'AMAT', NULL, 'Completed', '2025-03-25 14:21:22', '2025-03-25 14:24:15'),
(17, 'SAM002', 'SAM002', 'Bob Manager', '2025-03-25', 'Fab1', 'Morning', 'Etch', 'AMAT', NULL, 'Incomplete', '2025-03-25 14:32:27', '2025-03-25 14:32:27'),
(18, 'SAM002', 'SAM002', 'Bob Manager', '2025-03-25', 'Fab1', 'Morning', 'Etch', 'AMAT', NULL, 'Completed', '2025-03-25 20:13:12', '2025-03-25 20:15:04'),
(19, 'SAM002', 'SAM002', 'Bob Manager', '2025-03-25', 'Fab1', 'Morning', 'Deposition', 'AMAT', NULL, 'Completed', '2025-03-25 20:18:15', '2025-03-25 20:18:34'),
(20, 'SAM002', 'SAM002', 'Bob Manager', '2025-03-25', 'Fab2', 'Morning', 'Deposition', 'LAM', NULL, 'Completed', '2025-03-25 20:22:40', '2025-03-25 20:23:07'),
(21, 'SAM002', 'SAM001', 'Bob Manager', '2025-03-25', 'Fab1', 'Morning', 'Etch', 'AMAT', NULL, 'Completed', '2025-03-25 20:42:44', '2025-03-25 20:43:10');

-- --------------------------------------------------------

--
-- Структура таблицы `auditsections`
--

CREATE TABLE `auditsections` (
  `id` int(11) NOT NULL,
  `sectionId` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `createdAt` datetime NOT NULL DEFAULT current_timestamp(),
  `updatedAt` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `auditsections`
--

INSERT INTO `auditsections` (`id`, `sectionId`, `title`, `createdAt`, `updatedAt`) VALUES
(1, 'section1', 'Slip, Trip and Fall Hazards', '2025-03-18 09:50:08', '2025-03-18 09:50:08'),
(2, 'section2', 'Work Area Safety', '2025-03-18 09:50:08', '2025-03-18 09:50:08'),
(3, 'section3', 'Emergency Equipment', '2025-03-18 09:50:08', '2025-03-18 09:50:08'),
(4, 'section4', 'Support Equipment', '2025-03-18 09:50:08', '2025-03-18 09:50:08');

-- --------------------------------------------------------

--
-- Структура таблицы `certifications`
--

CREATE TABLE `certifications` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `expires` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `certifications`
--

INSERT INTO `certifications` (`id`, `name`, `expires`) VALUES
(1, 'Fire Safety Training', '2025-12-31 00:00:00'),
(2, 'Machine Operation Level 1', '2025-12-31 00:00:00'),
(3, 'Chemical Handling Safety', '2025-12-31 00:00:00'),
(4, 'Electrical Safety Certification', '2025-12-31 00:00:00'),
(5, 'Emergency Response Training', '2025-12-31 00:00:00');

-- --------------------------------------------------------

--
-- Структура таблицы `incidents`
--

CREATE TABLE `incidents` (
  `id` int(11) NOT NULL,
  `audit_record_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `reported_at` datetime DEFAULT current_timestamp(),
  `status` enum('Open','Closed') NOT NULL DEFAULT 'Open',
  `issue_description` text NOT NULL,
  `score` enum('1','2','3','4') NOT NULL,
  `supporting_media` text DEFAULT NULL,
  `corrective_action` text DEFAULT NULL,
  `createdAt` datetime DEFAULT current_timestamp(),
  `updatedAt` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `incidents`
--

INSERT INTO `incidents` (`id`, `audit_record_id`, `section_id`, `reported_at`, `status`, `issue_description`, `score`, `supporting_media`, `corrective_action`, `createdAt`, `updatedAt`) VALUES
(1, 4, 1, '2025-03-18 20:22:26', 'Open', 'cbcbcb', '1', '', 'cbcbcbc', '2025-03-18 20:22:26', '2025-03-18 20:22:26'),
(2, 5, 1, '2025-03-18 20:25:58', 'Closed', '', '4', '', 'not need', '2025-03-18 20:25:58', '2025-03-18 20:25:58'),
(3, 5, 1, '2025-03-18 20:25:59', 'Open', 'sdgs', '2', '', 'fsfsf', '2025-03-18 20:25:59', '2025-03-18 20:25:59'),
(4, 5, 2, '2025-03-18 20:25:59', 'Open', 'sgsg', '3', '', 'sgsgs', '2025-03-18 20:25:59', '2025-03-18 20:25:59'),
(5, 5, 3, '2025-03-18 20:25:59', 'Open', 'sgsg', '1', '', 'sgsgs', '2025-03-18 20:25:59', '2025-03-18 20:25:59'),
(6, 5, 4, '2025-03-18 20:25:59', 'Open', 'sgsgs', '2', '', 'sgsgs', '2025-03-18 20:25:59', '2025-03-18 20:25:59'),
(7, 12, 1, '2025-03-24 08:34:36', 'Open', '', '2', '', '', '2025-03-24 08:34:36', '2025-03-24 08:34:36'),
(8, 13, 1, '2025-03-24 08:43:15', 'Open', '', '2', '', '', '2025-03-24 08:43:15', '2025-03-24 08:43:15'),
(9, 13, 1, '2025-03-24 08:43:15', 'Open', '', '2', '', '', '2025-03-24 08:43:15', '2025-03-24 08:43:15'),
(10, 13, 1, '2025-03-24 08:43:15', 'Open', '', '2', '', '', '2025-03-24 08:43:15', '2025-03-24 08:43:15'),
(11, 13, 1, '2025-03-24 08:43:15', 'Open', '', '1', '', '', '2025-03-24 08:43:15', '2025-03-24 08:43:15'),
(12, 14, 1, '2025-03-24 08:48:36', 'Open', '', '2', '', '', '2025-03-24 08:48:36', '2025-03-24 08:48:36'),
(13, 16, 1, '2025-03-25 14:24:14', 'Open', '', '3', '', '', '2025-03-25 14:24:14', '2025-03-25 14:24:14'),
(14, 16, 2, '2025-03-25 14:24:14', 'Open', '', '2', '', '', '2025-03-25 14:24:14', '2025-03-25 14:24:14'),
(15, 16, 2, '2025-03-25 14:24:14', 'Open', '', '2', '', '', '2025-03-25 14:24:14', '2025-03-25 14:24:14'),
(16, 18, 1, '2025-03-25 20:15:04', 'Open', '', '1', '/uploads/1742933704152-Screenshot 2025-03-18 202207.png', '', '2025-03-25 20:15:04', '2025-03-25 20:15:04'),
(17, 18, 1, '2025-03-25 20:16:14', 'Open', '', '1', '/uploads/1742933774653-Screenshot 2025-03-18 202207.png', '', '2025-03-25 20:16:14', '2025-03-25 20:16:14'),
(18, 18, 1, '2025-03-25 20:16:42', 'Open', '', '1', '/uploads/1742933802367-Screenshot 2025-03-18 202207.png', '', '2025-03-25 20:16:42', '2025-03-25 20:16:42'),
(19, 19, 1, '2025-03-25 20:18:34', 'Open', '', '1', '/uploads/1742933914492-Screenshot 2025-03-18 201309.png, /uploads/1742933914494-Screenshot 2025-03-18 201336.png, /uploads/1742933914495-Screenshot 2025-03-18 202207.png', '', '2025-03-25 20:18:34', '2025-03-25 20:18:34'),
(20, 20, 1, '2025-03-25 20:23:07', 'Open', '', '2', '/uploads/1742934187649-Screenshot 2025-03-18 201309.png, /uploads/1742934187650-Screenshot 2025-03-18 201336.png, /uploads/1742934187651-Screenshot 2025-03-18 202207.png', '', '2025-03-25 20:23:07', '2025-03-25 20:23:07'),
(21, 20, 1, '2025-03-25 20:23:07', 'Open', '', '2', '/uploads/1742934187718-Screenshot 2025-03-18 201309.png', '', '2025-03-25 20:23:07', '2025-03-25 20:23:07'),
(22, 21, 1, '2025-03-25 20:43:09', 'Closed', '', '4', '/uploads/1742935389543-Screenshot (7).png', '', '2025-03-25 20:43:09', '2025-03-25 20:43:09');

-- --------------------------------------------------------

--
-- Структура таблицы `sequelizemeta`
--

CREATE TABLE `sequelizemeta` (
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `sequelizemeta`
--

INSERT INTO `sequelizemeta` (`name`) VALUES
('20250318092604-create-audit-sections.js'),
('20250318094704-create-audit-questions.js'),
('20250318114234-create-audit-records.js'),
('20250318192455-create_incidents.js');

-- --------------------------------------------------------

--
-- Структура таблицы `tutorials`
--

CREATE TABLE `tutorials` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `tutorials`
--

INSERT INTO `tutorials` (`id`, `name`, `description`, `created_at`) VALUES
(1, 'Safety Training', 'General workplace safety procedures', '2025-03-12 20:28:31'),
(2, 'Fire Safety Awareness', 'Fire prevention and emergency response', '2025-03-12 20:28:31'),
(3, 'Electrical Safety', 'Handling electrical equipment safely', '2025-03-12 20:28:31'),
(4, 'Hazardous Materials Handling', 'Safe storage and disposal of hazardous materials', '2025-03-12 20:28:31'),
(5, 'Emergency Response Procedures', 'Evacuation and first-aid training', '2025-03-12 20:28:31'),
(6, 'Workplace Ergonomics', 'Proper posture and workspace setup for injury prevention', '2025-03-12 20:28:31'),
(7, 'Personal Protective Equipment (PPE)', 'Usage of safety gear in the workplace', '2025-03-12 20:28:31'),
(8, 'Chemical Spill Response', 'Steps to take in case of a chemical spill', '2025-03-12 20:28:31'),
(9, 'Machine Handling & Safety', 'Safe operation of industrial machinery', '2025-03-12 20:28:31'),
(10, 'Lockout-Tagout (LOTO) Training', 'Preventing accidental machine activation', '2025-03-12 20:28:31');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `employee_number` varchar(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `position` enum('user','sam','admin') NOT NULL,
  `department` varchar(50) DEFAULT NULL,
  `manager_number` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`employee_number`, `name`, `email`, `password`, `position`, `department`, `manager_number`) VALUES
('E999', 'Test User', 'test@example.com', '12345', 'admin', 'IT', NULL),
('FIN001', 'Ethan Walker', 'ethan.walker@example.com', '12345', 'user', 'Finance', 'SAM003'),
('FIN002', 'Ava Hall', 'ava.hall@example.com', '12345', 'user', 'Finance', 'SAM003'),
('FIN003', 'James Allen', 'james.allen@example.com', '12345', 'user', 'Finance', 'SAM003'),
('FIN004', 'Mia Young', 'mia.young@example.com', '12345', 'user', 'Finance', 'SAM003'),
('FIN005', 'Liam Hernandez', 'liam.hernandez@example.com', '12345', 'user', 'Finance', 'SAM003'),
('HR001', 'Laura Wilson', 'laura.wilson@example.com', '12345', 'user', 'HR', 'SAM002'),
('HR002', 'Daniel Lee', 'daniel.lee@example.com', '12345', 'user', 'HR', 'SAM002'),
('HR003', 'Sophia Taylor', 'sophia.taylor@example.com', '12345', 'user', 'HR', 'SAM002'),
('HR004', 'Oliver Martinez', 'oliver.martinez@example.com', '12345', 'user', 'HR', 'SAM002'),
('HR005', 'Isabella Thomas', 'isabella.thomas@example.com', '12345', 'user', 'HR', 'SAM002'),
('IT001', 'John Doe', 'john.doe@example.com', '12345', 'user', 'IT', 'SAM001'),
('IT002', 'Jane Smith', 'jane.smith@example.com', '12345', 'user', 'IT', 'SAM001'),
('IT003', 'Mike Johnson', 'mike.johnson@example.com', '12345', 'user', 'IT', 'SAM001'),
('IT004', 'Emily Davis', 'emily.davis@example.com', '12345', 'user', 'IT', 'SAM001'),
('IT005', 'Robert Brown', 'robert.brown@example.com', '12345', 'user', 'IT', 'SAM001'),
('MKT001', 'Benjamin Adams', 'benjamin.adams@example.com', '12345', 'user', 'Marketing', 'SAM005'),
('MKT002', 'Charlotte Nelson', 'charlotte.nelson@example.com', '12345', 'user', 'Marketing', 'SAM005'),
('MKT003', 'Henry Carter', 'henry.carter@example.com', '12345', 'user', 'Marketing', 'SAM005'),
('MKT004', 'Evelyn Mitchell', 'evelyn.mitchell@example.com', '12345', 'user', 'Marketing', 'SAM005'),
('MKT005', 'Alexander Perez', 'alexander.perez@example.com', '12345', 'user', 'Marketing', 'SAM005'),
('OPS001', 'Noah King', 'noah.king@example.com', '12345', 'user', 'Operations', 'SAM004'),
('OPS002', 'Emma Wright', 'emma.wright@example.com', '12345', 'user', 'Operations', 'SAM004'),
('OPS003', 'Lucas Lopez', 'lucas.lopez@example.com', '12345', 'user', 'Operations', 'SAM004'),
('OPS004', 'Amelia Scott', 'amelia.scott@example.com', '12345', 'user', 'Operations', 'SAM004'),
('OPS005', 'William Green', 'william.green@example.com', '12345', 'user', 'Operations', 'SAM004'),
('SAM001', 'Alice Manager', 'alice@example.com', '12345', 'sam', 'IT', NULL),
('SAM002', 'Bob Manager', 'bob@example.com', '12345', 'sam', 'HR', NULL),
('SAM003', 'Charlie Manager', 'charlie@example.com', '12345', 'sam', 'Finance', NULL),
('SAM004', 'Diana Manager', 'diana@example.com', '12345', 'sam', 'Operations', NULL),
('SAM005', 'Ethan Manager', 'ethan@example.com', '12345', 'sam', 'Marketing', NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `user_certifications`
--

CREATE TABLE `user_certifications` (
  `id` int(11) NOT NULL,
  `user_number` varchar(20) NOT NULL,
  `certification_id` int(11) NOT NULL,
  `valid_until` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `user_certifications`
--

INSERT INTO `user_certifications` (`id`, `user_number`, `certification_id`, `valid_until`) VALUES
(1, 'SAM001', 2, '2026-03-04 00:00:00'),
(2, 'SAM001', 5, '2025-07-31 00:00:00'),
(3, 'SAM002', 2, '2025-08-22 00:00:00'),
(4, 'SAM003', 3, '2025-06-11 00:00:00'),
(5, 'SAM004', 2, '2025-06-05 00:00:00'),
(6, 'SAM004', 4, '2026-01-03 00:00:00'),
(7, 'SAM005', 3, '2026-01-17 00:00:00'),
(8, 'SAM005', 3, '2026-03-15 00:00:00'),
(9, 'IT001', 2, '2025-10-01 00:00:00'),
(10, 'IT002', 1, '2025-10-04 00:00:00'),
(11, 'IT002', 5, '2025-05-09 00:00:00'),
(12, 'IT003', 5, '2025-09-07 00:00:00'),
(13, 'IT003', 5, '2026-02-03 00:00:00'),
(14, 'IT004', 3, '2025-10-03 00:00:00'),
(15, 'IT005', 3, '2026-01-24 00:00:00'),
(16, 'IT005', 5, '2025-12-21 00:00:00'),
(17, 'HR001', 2, '2025-10-03 00:00:00'),
(18, 'HR001', 2, '2026-02-06 00:00:00'),
(19, 'HR002', 1, '2025-10-17 00:00:00'),
(20, 'HR003', 1, '2025-08-02 00:00:00'),
(21, 'HR003', 4, '2025-04-18 00:00:00'),
(22, 'HR004', 2, '2025-09-20 00:00:00'),
(23, 'HR004', 4, '2025-07-10 00:00:00'),
(24, 'FIN001', 3, '2025-12-14 00:00:00'),
(25, 'FIN002', 5, '2025-12-04 00:00:00'),
(26, 'FIN003', 5, '2025-11-04 00:00:00'),
(27, 'FIN003', 4, '2026-03-19 00:00:00'),
(28, 'FIN004', 2, '2026-02-19 00:00:00'),
(29, 'FIN004', 4, '2026-01-12 00:00:00'),
(30, 'FIN005', 3, '2025-10-31 00:00:00'),
(31, 'FIN005', 4, '2025-07-10 00:00:00'),
(32, 'OPS001', 3, '2026-03-21 00:00:00'),
(33, 'OPS001', 4, '2025-04-28 00:00:00'),
(34, 'OPS002', 2, '2025-09-11 00:00:00'),
(35, 'OPS002', 1, '2025-09-29 00:00:00'),
(36, 'OPS003', 2, '2025-07-08 00:00:00'),
(37, 'OPS004', 3, '2025-09-03 00:00:00'),
(38, 'OPS004', 1, '2025-09-22 00:00:00'),
(39, 'OPS005', 3, '2025-06-02 00:00:00'),
(40, 'MKT001', 5, '2026-02-23 00:00:00'),
(41, 'MKT002', 1, '2025-12-07 00:00:00'),
(42, 'MKT002', 1, '2025-12-14 00:00:00'),
(43, 'MKT003', 1, '2025-10-02 00:00:00'),
(44, 'MKT003', 2, '2025-05-10 00:00:00'),
(45, 'MKT004', 5, '2025-06-07 00:00:00'),
(46, 'MKT005', 3, '2026-02-25 00:00:00'),
(47, 'MKT005', 2, '2025-06-19 00:00:00');

-- --------------------------------------------------------

--
-- Структура таблицы `user_tutorials`
--

CREATE TABLE `user_tutorials` (
  `id` int(11) NOT NULL,
  `employee_number` varchar(255) NOT NULL,
  `tutorial_id` int(11) NOT NULL,
  `completed_at` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `user_tutorials`
--

INSERT INTO `user_tutorials` (`id`, `employee_number`, `tutorial_id`, `completed_at`) VALUES
(39, 'HR001', 1, '2025-05-10'),
(40, 'HR001', 2, '2025-06-15'),
(41, 'HR002', 3, '2025-03-12'),
(42, 'HR002', 4, '2025-07-18'),
(43, 'HR003', 5, '2025-01-22'),
(44, 'HR003', 6, '2025-08-05'),
(45, 'HR003', 7, '2025-09-01'),
(46, 'IT001', 2, '2025-05-30'),
(47, 'IT001', 3, '2025-06-20'),
(48, 'IT002', 4, '2025-02-14'),
(49, 'IT002', 5, '2025-03-28'),
(50, 'FIN001', 1, '2025-07-10'),
(51, 'FIN001', 6, '2025-08-12'),
(52, 'FIN002', 7, '2025-10-05'),
(53, 'FIN002', 8, '2025-11-15'),
(54, 'OPS001', 2, '2025-03-14'),
(55, 'OPS001', 9, '2025-07-22'),
(56, 'OPS002', 3, '2025-05-08'),
(57, 'OPS002', 10, '2025-06-30');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `auditquestions`
--
ALTER TABLE `auditquestions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sectionId` (`sectionId`);

--
-- Индексы таблицы `auditrecords`
--
ALTER TABLE `auditrecords`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_audit_employee` (`employee_number`),
  ADD KEY `fk_audit_fab_manager` (`fab_manager_id`);

--
-- Индексы таблицы `auditsections`
--
ALTER TABLE `auditsections`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `sectionId` (`sectionId`);

--
-- Индексы таблицы `certifications`
--
ALTER TABLE `certifications`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD UNIQUE KEY `name_2` (`name`),
  ADD UNIQUE KEY `name_3` (`name`),
  ADD UNIQUE KEY `name_4` (`name`),
  ADD UNIQUE KEY `name_5` (`name`),
  ADD UNIQUE KEY `name_6` (`name`),
  ADD UNIQUE KEY `name_7` (`name`),
  ADD UNIQUE KEY `name_8` (`name`);

--
-- Индексы таблицы `incidents`
--
ALTER TABLE `incidents`
  ADD PRIMARY KEY (`id`),
  ADD KEY `audit_record_id` (`audit_record_id`),
  ADD KEY `section_id` (`section_id`);

--
-- Индексы таблицы `sequelizemeta`
--
ALTER TABLE `sequelizemeta`
  ADD PRIMARY KEY (`name`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Индексы таблицы `tutorials`
--
ALTER TABLE `tutorials`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`employee_number`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `email_2` (`email`),
  ADD UNIQUE KEY `email_3` (`email`),
  ADD UNIQUE KEY `email_4` (`email`),
  ADD UNIQUE KEY `email_5` (`email`),
  ADD UNIQUE KEY `email_6` (`email`),
  ADD UNIQUE KEY `email_7` (`email`),
  ADD UNIQUE KEY `email_8` (`email`),
  ADD UNIQUE KEY `email_9` (`email`),
  ADD KEY `manager_number` (`manager_number`);

--
-- Индексы таблицы `user_certifications`
--
ALTER TABLE `user_certifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_number` (`user_number`),
  ADD KEY `certification_id` (`certification_id`);

--
-- Индексы таблицы `user_tutorials`
--
ALTER TABLE `user_tutorials`
  ADD PRIMARY KEY (`id`),
  ADD KEY `employee_number` (`employee_number`),
  ADD KEY `tutorial_id` (`tutorial_id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `auditquestions`
--
ALTER TABLE `auditquestions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT для таблицы `auditrecords`
--
ALTER TABLE `auditrecords`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT для таблицы `auditsections`
--
ALTER TABLE `auditsections`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT для таблицы `certifications`
--
ALTER TABLE `certifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT для таблицы `incidents`
--
ALTER TABLE `incidents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT для таблицы `tutorials`
--
ALTER TABLE `tutorials`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT для таблицы `user_certifications`
--
ALTER TABLE `user_certifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=64;

--
-- AUTO_INCREMENT для таблицы `user_tutorials`
--
ALTER TABLE `user_tutorials`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `auditquestions`
--
ALTER TABLE `auditquestions`
  ADD CONSTRAINT `auditquestions_ibfk_1` FOREIGN KEY (`sectionId`) REFERENCES `auditsections` (`sectionId`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `auditrecords`
--
ALTER TABLE `auditrecords`
  ADD CONSTRAINT `fk_audit_employee` FOREIGN KEY (`employee_number`) REFERENCES `users` (`employee_number`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_audit_fab_manager` FOREIGN KEY (`fab_manager_id`) REFERENCES `users` (`employee_number`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `incidents`
--
ALTER TABLE `incidents`
  ADD CONSTRAINT `incidents_ibfk_1` FOREIGN KEY (`audit_record_id`) REFERENCES `auditrecords` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `incidents_ibfk_2` FOREIGN KEY (`section_id`) REFERENCES `auditsections` (`id`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`manager_number`) REFERENCES `users` (`employee_number`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `user_certifications`
--
ALTER TABLE `user_certifications`
  ADD CONSTRAINT `user_certifications_ibfk_13` FOREIGN KEY (`user_number`) REFERENCES `users` (`employee_number`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `user_certifications_ibfk_14` FOREIGN KEY (`certification_id`) REFERENCES `certifications` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `user_tutorials`
--
ALTER TABLE `user_tutorials`
  ADD CONSTRAINT `user_tutorials_ibfk_1` FOREIGN KEY (`employee_number`) REFERENCES `users` (`employee_number`) ON DELETE CASCADE,
  ADD CONSTRAINT `user_tutorials_ibfk_2` FOREIGN KEY (`tutorial_id`) REFERENCES `tutorials` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
