-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: tower
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `annualplan`
--

DROP TABLE IF EXISTS `annualplan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `annualplan` (
  `id` int NOT NULL AUTO_INCREMENT,
  `category` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `activity` varchar(255) NOT NULL,
  `reference` varchar(255) DEFAULT NULL,
  `owner` varchar(255) DEFAULT NULL,
  `dueDate` date NOT NULL,
  `startTime` time NOT NULL,
  `endTime` time NOT NULL,
  `status` varchar(255) DEFAULT 'pending',
  `recurrence` varchar(255) DEFAULT 'none',
  `fileUrl` varchar(255) DEFAULT NULL,
  `createdBy` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=78 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `annualplan`
--

LOCK TABLES `annualplan` WRITE;
/*!40000 ALTER TABLE `annualplan` DISABLE KEYS */;
INSERT INTO `annualplan` VALUES (69,'Safety','Audit','Monthly Walkthrough','SOP-001','John Doe','2025-07-02','22:25:40','23:25:40','pending','monthly',NULL,'system','2025-04-02 19:56:30','2025-04-02 19:56:30'),(70,'Safety','Audit','Monthly Walkthrough','SOP-001','John Doe','2025-04-03','09:46:52','09:46:52','completed','monthly',NULL,'system','2025-04-03 06:45:41','2025-04-03 06:46:52'),(71,'Fire Safety','Inspection','Extinguisher Check','FIRE-EXT-2025','Jane Smith','2025-04-20','14:00:00','15:00:00','pending','yearly',NULL,'system','2025-04-03 06:45:41','2025-04-03 06:45:41'),(72,'Equipment','Maintenance','Quarterly Machine Calibration','EQ-CAL-04','Ali Ben','2025-05-05','10:30:00','12:00:00','in-progress','quarterly',NULL,'admin','2025-04-03 06:45:41','2025-04-03 06:45:41'),(73,'Training','Workshop','First Aid Training','TRAIN-FA-2025','Nina Patel','2025-06-10','08:00:00','11:00:00','pending','none',NULL,'admin','2025-04-03 06:45:41','2025-04-03 06:45:41'),(74,'Environmental','Audit','Waste Management Check','ENV-WM-22','Carlos Ruiz','2025-07-01','15:00:00','16:30:00','completed','yearly',NULL,'system','2025-04-03 06:45:41','2025-04-03 06:45:41'),(75,'Safety','Audit','Monthly Walkthrough','SOP-001','John Doe','2025-05-15','09:00:00','10:00:00','pending','monthly',NULL,'system','2025-04-03 06:46:22','2025-04-03 06:46:22'),(76,'Safety','Audit','Monthly Walkthrough','SOP-001','John Doe','2025-04-03','09:46:55','09:46:55','completed','monthly',NULL,'system','2025-04-03 06:46:52','2025-04-03 06:46:55'),(77,'Safety','Audit','Monthly Walkthrough','SOP-001','John Doe','2025-06-03','09:46:22','10:46:22','pending','monthly',NULL,'system','2025-04-03 06:46:55','2025-04-03 06:46:55');
/*!40000 ALTER TABLE `annualplan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auditquestions`
--

DROP TABLE IF EXISTS `auditquestions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auditquestions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `text` text COLLATE utf8mb4_general_ci NOT NULL,
  `example` text COLLATE utf8mb4_general_ci,
  `createdAt` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime DEFAULT CURRENT_TIMESTAMP,
  `section_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_auditquestions_section_id` (`section_id`),
  CONSTRAINT `fk_auditquestions_section_id` FOREIGN KEY (`section_id`) REFERENCES `auditsections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auditquestions`
--

LOCK TABLES `auditquestions` WRITE;
/*!40000 ALTER TABLE `auditquestions` DISABLE KEYS */;
INSERT INTO `auditquestions` VALUES (1,'Slip/trip hazards on floor?','Example: Wipes, packaging material, liquids, power cords, umbilical cords, etc.','2025-03-18 09:54:39','2025-03-18 09:54:39',1),(2,'Falling objects - above or below?','Holes in floor or overhead that tools could drop through?','2025-03-18 09:54:39','2025-03-18 09:54:39',1),(3,'Barricading Hazards?','Are all Raised Metal Floor openings properly barricaded?','2025-03-18 09:54:39','2025-03-18 09:54:39',1),(4,'Is area or chase organized per local site requirements?','Work area and storage area cleanliness?','2025-03-18 09:54:39','2025-03-18 09:54:39',1),(5,'Is the buddy system being used when required?','Are the appropriate number of CEs/customer technicians present?','2025-03-18 09:54:39','2025-03-18 09:54:39',2),(6,'Customer Spec or AMAT Procedure available?','If PTP required, is it properly completed and present?','2025-03-18 09:54:39','2025-03-18 09:54:39',2),(7,'Is a procedure or PTP in use for work as required?','Is an appropriate procedure being used?','2025-03-18 09:54:39','2025-03-18 09:54:39',2),(8,'Proper ergonomic precautions being followed?','Proper lifting procedures, minimizing prolonged tasks, etc.','2025-03-18 09:54:39','2025-03-18 09:54:39',2),(9,'Are proper use of LOTO and/or interlock defeating programs being followed?','Is LOTO stocked in the proper location or readily available?','2025-03-18 09:54:39','2025-03-18 09:54:39',3),(10,'Job specific PPE being used?','Fall protection, bump caps, breathing air, safety equipment, etc.','2025-03-18 09:54:39','2025-03-18 09:54:39',3),(11,'Shower / Eye Wash available and unobstructed?','Are showers and/or eye wash stations available and unobstructed?','2025-03-18 09:54:39','2025-03-18 09:54:39',3),(12,'Emergency exits and signage in place?','Are any egress paths or exit doors blocked?','2025-03-18 09:54:39','2025-03-18 09:54:39',3),(13,'Fire Extinguishers Present?','Fire extinguishers nearby and not blocked?','2025-03-18 09:54:39','2025-03-18 09:54:39',4),(14,'Telephones in area functional?','Verify dial tone. Do you know the emergency phone number?','2025-03-18 09:54:39','2025-03-18 09:54:39',4),(15,'Ladder / step stools properly stored?','Ladders secured in place in racks or storage area?','2025-03-18 09:54:39','2025-03-18 09:54:39',4),(16,'Are chemicals stored and used properly?','Are chemical cabinets available nearby and utilized?','2025-03-18 09:54:39','2025-03-18 09:54:39',4),(17,'Are hand tools available and in good condition?','No frayed cords? Calibration completed if required?','2025-03-18 09:54:39','2025-03-18 09:54:39',4),(18,'Are customer provided support equipment in good repair?','Are carts, lifting devices, toolboxes in good condition?','2025-03-18 09:54:39','2025-03-18 09:54:39',4);
/*!40000 ALTER TABLE `auditquestions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auditrecords`
--

DROP TABLE IF EXISTS `auditrecords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auditrecords` (
  `id` int NOT NULL AUTO_INCREMENT,
  `employee_number` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `fab_manager_id` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `date_completed` date NOT NULL,
  `location` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `shift` enum('Morning','Night') COLLATE utf8mb4_general_ci NOT NULL,
  `fab_area` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `toolset` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `additional_details` text COLLATE utf8mb4_general_ci,
  `auditStatus` enum('Completed','Incomplete','Canceled') COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'Incomplete',
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_audit_employee` (`employee_number`),
  KEY `fk_audit_fab_manager` (`fab_manager_id`),
  CONSTRAINT `fk_audit_employee` FOREIGN KEY (`employee_number`) REFERENCES `users` (`employee_number`) ON DELETE SET NULL,
  CONSTRAINT `fk_audit_fab_manager` FOREIGN KEY (`fab_manager_id`) REFERENCES `users` (`employee_number`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auditrecords`
--

LOCK TABLES `auditrecords` WRITE;
/*!40000 ALTER TABLE `auditrecords` DISABLE KEYS */;
/*!40000 ALTER TABLE `auditrecords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auditsections`
--

DROP TABLE IF EXISTS `auditsections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auditsections` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auditsections`
--

LOCK TABLES `auditsections` WRITE;
/*!40000 ALTER TABLE `auditsections` DISABLE KEYS */;
INSERT INTO `auditsections` VALUES (1,'Slip, Trip and Fall Hazards','2025-03-18 09:50:08','2025-03-18 09:50:08'),(2,'Work Area Safety','2025-03-18 09:50:08','2025-03-18 09:50:08'),(3,'Emergency Equipment','2025-03-18 09:50:08','2025-03-18 09:50:08'),(4,'Support Equipment','2025-03-18 09:50:08','2025-03-18 09:50:08');
/*!40000 ALTER TABLE `auditsections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `certifications`
--

DROP TABLE IF EXISTS `certifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `certifications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `description` text COLLATE utf8mb4_general_ci,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `name_2` (`name`),
  UNIQUE KEY `name_3` (`name`),
  UNIQUE KEY `name_4` (`name`),
  UNIQUE KEY `name_5` (`name`),
  UNIQUE KEY `name_6` (`name`),
  UNIQUE KEY `name_7` (`name`),
  UNIQUE KEY `name_8` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `certifications`
--

LOCK TABLES `certifications` WRITE;
/*!40000 ALTER TABLE `certifications` DISABLE KEYS */;
INSERT INTO `certifications` VALUES (7,'Fire Safety Training','Comprehensive training','2025-04-08 20:06:31','2025-04-08 20:26:38'),(8,'Electrical Safety Certification','Safety measures for working with high-voltage electrical equipment.','2025-04-08 20:06:31','2025-04-08 20:06:31'),(9,'Workplace Ergonomics','Training to improve workplace posture and reduce repetitive strain.','2025-04-08 20:06:31','2025-04-08 20:06:31'),(10,'test',NULL,'2025-04-08 21:09:29','2025-04-08 21:09:29');
/*!40000 ALTER TABLE `certifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `events`
--

DROP TABLE IF EXISTS `events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `events` (
  `id` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `start` datetime NOT NULL,
  `end` datetime NOT NULL,
  `recurrence` enum('daily','weekly','monthly','quarterly','yearly','none') NOT NULL DEFAULT 'none',
  `status` enum('pending','completed') NOT NULL DEFAULT 'pending',
  `allDay` tinyint(1) NOT NULL DEFAULT '0',
  `category` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `activity` varchar(255) DEFAULT NULL,
  `owner` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `events`
--

LOCK TABLES `events` WRITE;
/*!40000 ALTER TABLE `events` DISABLE KEYS */;
INSERT INTO `events` VALUES ('1','Monthly Safety Audit','2025-04-02 07:00:00','2025-04-02 08:00:00','monthly','completed',0,'safety','audit','safety-check','john.doe','2025-04-03 07:39:57','2025-04-03 07:48:51'),('1743666425786','Monthly Safety Audit','2025-05-02 09:00:00','2025-05-02 10:00:00','monthly','completed',0,'safety','audit','safety-check','john.doe','2025-04-03 07:47:05','2025-04-03 07:47:10'),('1743666430645','Monthly Safety Audit','2025-06-02 09:00:00','2025-06-02 10:00:00','monthly','pending',0,'safety','audit','safety-check','john.doe','2025-04-03 07:47:10','2025-04-03 07:47:10'),('1743666614754','Quarterly Machine Check','2025-07-04 14:00:00','2025-07-04 15:30:00','quarterly','pending',0,'inspection','check','machine-status','inspector.bot','2025-04-03 07:50:14','2025-04-03 07:50:14'),('1743666709073','Weekly Fire Drill','2025-04-17 05:30:00','2025-04-17 06:00:00','weekly','pending',0,'safety','drill','fire-evacuation','jane.smith','2025-04-03 07:51:49','2025-04-03 08:24:43'),('1743669645196','test','2025-04-06 11:00:00','2025-04-06 12:00:00','daily','completed',0,'test','test','test','test','2025-04-03 08:40:45','2025-04-03 08:40:55'),('1743669655696','test','2025-04-07 11:00:00','2025-04-07 12:00:00','daily','pending',0,'test','test','test','test','2025-04-03 08:40:55','2025-04-03 08:40:55'),('1744055373420','new event','2025-04-08 05:00:00','2025-04-08 05:30:00','none','completed',0,'General','Task','Manual','You','2025-04-07 19:49:33','2025-04-07 19:50:59'),('2','Weekly Fire Drill','2025-04-03 05:30:00','2025-04-03 06:00:00','weekly','completed',0,'safety','drill','fire-evacuation','jane.smith','2025-04-03 07:39:57','2025-04-03 07:51:49'),('3','Quarterly Machine Check','2025-04-04 14:00:00','2025-04-04 15:30:00','quarterly','completed',0,'inspection','check','machine-status','inspector.bot','2025-04-03 07:39:57','2025-04-03 07:50:14'),('4','Annual Hazard Review','2025-04-05 10:00:00','2025-04-05 12:00:00','yearly','pending',0,'safety','review','hazard-review','safety.admin','2025-04-03 07:39:57','2025-04-03 07:39:57'),('5','One-Time First Aid Training','2025-04-06 08:00:00','2025-04-06 11:00:00','none','pending',0,'training','workshop','first-aid','trainer.alex','2025-04-03 07:39:57','2025-04-03 07:39:57'),('999999','test','2025-04-03 11:00:00','2025-04-03 12:00:00','daily','completed',0,'test','test','test','test','2025-04-03 07:39:57','2025-04-03 08:40:44');
/*!40000 ALTER TABLE `events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `safetyaudits`
--

DROP TABLE IF EXISTS `safetyaudits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `safetyaudits` (
  `id` int NOT NULL AUTO_INCREMENT,
  `category` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `activity` varchar(255) NOT NULL,
  `reference` varchar(255) DEFAULT NULL,
  `owner` varchar(255) DEFAULT NULL,
  `dueDate` datetime NOT NULL,
  `status` varchar(255) DEFAULT 'pending',
  `recurrence` varchar(255) DEFAULT 'none',
  `fileUrl` varchar(255) DEFAULT NULL,
  `createdBy` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `startTime` time NOT NULL DEFAULT '09:00:00',
  `endTime` time NOT NULL DEFAULT '10:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `safetyaudits`
--

LOCK TABLES `safetyaudits` WRITE;
/*!40000 ALTER TABLE `safetyaudits` DISABLE KEYS */;
INSERT INTO `safetyaudits` VALUES (1,'Safety','Review','Noise level audit','Low','John Doe','2025-04-01 00:00:00','pending','yearly',NULL,'Admin','2025-03-29 12:29:18','2025-03-29 12:29:18','09:00:00','10:00:00'),(2,'Health','Inspection','Air quality assessment','Moderate','Jane Smith','2025-05-15 00:00:00','scheduled','monthly',NULL,'Admin','2025-03-29 12:29:18','2025-03-29 12:29:18','09:00:00','10:00:00'),(3,'Environment','Survey','Waste management evaluation','High','Emily Johnson','2025-06-20 00:00:00','completed','quarterly',NULL,'Admin','2025-03-29 12:29:18','2025-03-29 12:29:18','09:00:00','10:00:00'),(4,'Safety','Drill','Fire evacuation drill','Critical','Michael Brown','2025-07-10 00:00:00','pending','biannually',NULL,'Admin','2025-03-29 12:29:18','2025-03-29 12:29:18','09:00:00','10:00:00'),(5,'Compliance','Audit','OSHA compliance check','Medium','Sarah Davis','2025-08-05 00:00:00','scheduled','annually',NULL,'Admin','2025-03-29 12:29:18','2025-03-29 12:29:18','09:00:00','10:00:00'),(6,'Health','Review & Audits','test','test','kostia','2025-03-29 00:00:00','pending','weekly','',NULL,'2025-03-29 17:19:09','2025-03-29 17:19:09','08:00:00','09:00:00');
/*!40000 ALTER TABLE `safetyaudits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sequelizemeta`
--

DROP TABLE IF EXISTS `sequelizemeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sequelizemeta` (
  `name` varchar(255) COLLATE utf8mb3_unicode_ci NOT NULL,
  PRIMARY KEY (`name`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sequelizemeta`
--

LOCK TABLES `sequelizemeta` WRITE;
/*!40000 ALTER TABLE `sequelizemeta` DISABLE KEYS */;
INSERT INTO `sequelizemeta` VALUES ('20250318092604-create-audit-sections.js'),('20250318094704-create-audit-questions.js'),('20250318114234-create-audit-records.js'),('20250318192455-create_incidents.js'),('20250329120217-create-safety-audit.cjs'),('20250329122410-add-timestamps-to-safety-audits.cjs'),('20250329141004-add-start-end-time-to-safety-audits.cjs'),('20250329141251-add-start-end-time-to-safety-audits.cjs'),('20250331184425-rename-completed-to-valid-until.cjs'),('20250402110741-create-annualplan.cjs'),('20250403071901-create-events.js'),('20250408195909-update-certifications-schema.js');
/*!40000 ALTER TABLE `sequelizemeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `swa-reports`
--

DROP TABLE IF EXISTS `swa-reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `swa-reports` (
  `id` int NOT NULL AUTO_INCREMENT,
  `audit_record_id` int NOT NULL,
  `section_id` int NOT NULL,
  `reported_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `status` enum('Open','Closed') COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'Open',
  `issue_description` text COLLATE utf8mb4_general_ci NOT NULL,
  `score` tinyint DEFAULT NULL,
  `supporting_media` text COLLATE utf8mb4_general_ci,
  `corrective_action` text COLLATE utf8mb4_general_ci,
  `createdAt` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `question_id` int DEFAULT NULL,
  `closed_by` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `closed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `audit_record_id` (`audit_record_id`),
  KEY `section_id` (`section_id`),
  KEY `fk_swareports_question` (`question_id`),
  KEY `fk_swareports_closed_by` (`closed_by`),
  CONSTRAINT `fk_swareports_closed_by` FOREIGN KEY (`closed_by`) REFERENCES `users` (`employee_number`) ON DELETE SET NULL,
  CONSTRAINT `fk_swareports_question` FOREIGN KEY (`question_id`) REFERENCES `auditquestions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_swareports_record` FOREIGN KEY (`audit_record_id`) REFERENCES `auditrecords` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_swareports_section` FOREIGN KEY (`section_id`) REFERENCES `auditsections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `swa-reports_chk_1` CHECK ((`score` between 1 and 4))
) ENGINE=InnoDB AUTO_INCREMENT=89 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `swa-reports`
--

LOCK TABLES `swa-reports` WRITE;
/*!40000 ALTER TABLE `swa-reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `swa-reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `swa_reports`
--

DROP TABLE IF EXISTS `swa_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `swa_reports` (
  `id` int NOT NULL AUTO_INCREMENT,
  `audit_record_id` int NOT NULL,
  `section_id` int NOT NULL,
  `reported_at` datetime DEFAULT NULL,
  `status` enum('Open','Closed') NOT NULL DEFAULT 'Open',
  `issue_description` text NOT NULL,
  `score` enum('1','2','3','4') NOT NULL,
  `supporting_media` text,
  `corrective_action` text,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `audit_record_id` (`audit_record_id`),
  KEY `section_id` (`section_id`),
  CONSTRAINT `swa_reports_ibfk_1` FOREIGN KEY (`audit_record_id`) REFERENCES `auditrecords` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `swa_reports_ibfk_2` FOREIGN KEY (`section_id`) REFERENCES `auditsections` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `swa_reports`
--

LOCK TABLES `swa_reports` WRITE;
/*!40000 ALTER TABLE `swa_reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `swa_reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tutorials`
--

DROP TABLE IF EXISTS `tutorials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tutorials` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `description` text COLLATE utf8mb4_general_ci,
  `createdAt` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tutorials`
--

LOCK TABLES `tutorials` WRITE;
/*!40000 ALTER TABLE `tutorials` DISABLE KEYS */;
INSERT INTO `tutorials` VALUES (1,'Safety Training','General workplace ','2025-03-31 10:01:22','2025-04-08 20:21:55'),(2,'Fire Safety Awareness','Fire prevention and emergency response','2025-03-31 10:01:22','2025-03-31 10:01:22'),(3,'Electrical Safety','Handling electrical equipment safely','2025-03-31 10:01:22','2025-03-31 10:01:22'),(4,'Hazardous Materials Handling','Safe storage and disposal of hazardous materials','2025-03-31 10:01:22','2025-03-31 10:01:22'),(5,'Emergency Response Procedures','Evacuation and first-aid training','2025-03-31 10:01:22','2025-03-31 10:01:22'),(6,'Workplace Ergonomics','Proper posture and workspace setup for injury prevention','2025-03-31 10:01:22','2025-03-31 10:01:22'),(7,'Personal Protective Equipment (PPE)','Usage of safety gear in the workplace','2025-03-31 10:01:22','2025-03-31 10:01:22'),(8,'Chemical Spill Response','Steps to take in case of a chemical spill','2025-03-31 10:01:22','2025-03-31 10:01:22'),(9,'Machine Handling & Safety','Safe operation of industrial machinery','2025-03-31 10:01:22','2025-03-31 10:01:22'),(10,'Lockout-Tagout (LOTO) Training','Preventing accidental machine activation','2025-03-31 10:01:22','2025-03-31 10:01:22'),(11,'Machine Learning','General Machine Learning','2025-03-31 19:07:40','2025-03-31 19:07:40');
/*!40000 ALTER TABLE `tutorials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_certifications`
--

DROP TABLE IF EXISTS `user_certifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_certifications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_number` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `certification_id` int NOT NULL,
  `valid_until` datetime NOT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_number` (`user_number`),
  KEY `certification_id` (`certification_id`),
  CONSTRAINT `user_certifications_ibfk_13` FOREIGN KEY (`user_number`) REFERENCES `users` (`employee_number`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `user_certifications_ibfk_14` FOREIGN KEY (`certification_id`) REFERENCES `certifications` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_certifications`
--

LOCK TABLES `user_certifications` WRITE;
/*!40000 ALTER TABLE `user_certifications` DISABLE KEYS */;
INSERT INTO `user_certifications` VALUES (64,'FIN002',7,'2025-07-08 21:24:16','2025-04-09 00:27:20','2025-04-09 00:27:20'),(65,'FIN003',8,'2026-04-08 21:38:30','2025-04-08 21:38:30','2025-04-08 21:38:30'),(66,'SAM002',7,'2025-07-08 21:55:57','2025-04-08 21:55:57','2025-04-08 21:55:57');
/*!40000 ALTER TABLE `user_certifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_tutorials`
--

DROP TABLE IF EXISTS `user_tutorials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_tutorials` (
  `id` int NOT NULL AUTO_INCREMENT,
  `employee_number` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `tutorial_id` int NOT NULL,
  `valid_until` date NOT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `employee_number` (`employee_number`),
  KEY `tutorial_id` (`tutorial_id`),
  CONSTRAINT `user_tutorials_ibfk_1` FOREIGN KEY (`employee_number`) REFERENCES `users` (`employee_number`) ON DELETE CASCADE,
  CONSTRAINT `user_tutorials_ibfk_2` FOREIGN KEY (`tutorial_id`) REFERENCES `tutorials` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_tutorials`
--

LOCK TABLES `user_tutorials` WRITE;
/*!40000 ALTER TABLE `user_tutorials` DISABLE KEYS */;
INSERT INTO `user_tutorials` VALUES (39,'HR001',1,'2025-05-10','2025-03-31 23:24:47','2025-03-31 23:24:47'),(40,'HR001',2,'2025-06-15','2025-03-31 23:24:47','2025-03-31 23:24:47'),(41,'HR002',3,'2025-03-12','2025-03-31 23:24:47','2025-03-31 23:24:47'),(42,'HR002',4,'2025-07-18','2025-03-31 23:24:47','2025-03-31 23:24:47'),(43,'HR003',5,'2025-01-22','2025-03-31 23:24:47','2025-03-31 23:24:47'),(44,'HR003',6,'2025-08-05','2025-03-31 23:24:47','2025-03-31 23:24:47'),(45,'HR003',7,'2025-09-01','2025-03-31 23:24:47','2025-03-31 23:24:47'),(46,'IT001',2,'2025-05-30','2025-03-31 23:24:47','2025-03-31 23:24:47'),(47,'IT001',3,'2025-06-20','2025-03-31 23:24:47','2025-03-31 23:24:47'),(48,'IT002',4,'2025-02-14','2025-03-31 23:24:47','2025-03-31 23:24:47'),(49,'IT002',5,'2025-03-28','2025-03-31 23:24:47','2025-03-31 23:24:47'),(50,'FIN001',1,'2025-07-10','2025-03-31 23:24:47','2025-03-31 23:24:47'),(51,'FIN001',6,'2025-08-12','2025-03-31 23:24:47','2025-03-31 23:24:47'),(52,'FIN002',7,'2025-10-05','2025-03-31 23:24:47','2025-03-31 23:24:47'),(53,'FIN002',8,'2025-11-15','2025-03-31 23:24:47','2025-03-31 23:24:47'),(54,'OPS001',2,'2025-03-14','2025-03-31 23:24:47','2025-03-31 23:24:47'),(55,'OPS001',9,'2025-07-22','2025-03-31 23:24:47','2025-03-31 23:24:47'),(56,'OPS002',3,'2025-05-08','2025-03-31 23:24:47','2025-03-31 23:24:47'),(57,'OPS002',10,'2025-06-30','2025-03-31 23:24:47','2025-03-31 23:24:47'),(58,'FIN002',1,'2025-06-30','2025-03-31 22:17:25','2025-03-31 22:17:25'),(59,'FIN002',2,'2025-09-30','2025-03-31 22:18:04','2025-03-31 22:18:04'),(60,'FIN003',1,'2025-07-07','2025-04-07 20:28:21','2025-04-07 20:28:21'),(61,'SAM002',1,'2025-10-08','2025-04-08 21:58:54','2025-04-08 21:58:54');
/*!40000 ALTER TABLE `user_tutorials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `employee_number` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `position` enum('user','sam','admin') COLLATE utf8mb4_general_ci NOT NULL,
  `department` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `manager_number` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`employee_number`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `email_2` (`email`),
  UNIQUE KEY `email_3` (`email`),
  UNIQUE KEY `email_4` (`email`),
  UNIQUE KEY `email_5` (`email`),
  UNIQUE KEY `email_6` (`email`),
  UNIQUE KEY `email_7` (`email`),
  UNIQUE KEY `email_8` (`email`),
  UNIQUE KEY `email_9` (`email`),
  KEY `manager_number` (`manager_number`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`manager_number`) REFERENCES `users` (`employee_number`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('E999','Test User','test@example.com','00000','admin','IT',NULL),('FIN001','Ethan Walker','ethan.walker@example.com','00000','user','Finance','SAM003'),('FIN002','Ava Hall','ava.hall@example.com','12345','user','Finance','SAM003'),('FIN003','James Allen','james.allen@example.com','12345','user','Finance','SAM003'),('FIN004','Mia Young','mia.young@example.com','12345','user','Finance','SAM003'),('FIN005','Liam Hernandez','liam.hernandez@example.com','12345','user','Finance','SAM003'),('HR001','Laura Wilson','laura.wilson@example.com','12345','user','HR','SAM002'),('HR002','Daniel Lee','daniel.lee@example.com','12345','user','HR','SAM002'),('HR003','Sophia Taylor','sophia.taylor@example.com','12345','user','HR','SAM002'),('HR004','Oliver Martinez','oliver.martinez@example.com','12345','user','HR','SAM002'),('HR005','Isabella Thomas','isabella.thomas@example.com','12345','user','HR','SAM002'),('IT001','John Doe','john.doe@example.com','12345','user','IT','SAM001'),('IT002','Jane Smith','jane.smith@example.com','12345','user','IT','SAM001'),('IT003','Mike Johnson','mike.johnson@example.com','12345','user','IT','SAM001'),('IT004','Emily Davis','emily.davis@example.com','12345','user','IT','SAM001'),('IT005','Robert Brown','robert.brown@example.com','12345','user','IT','SAM001'),('MKT001','Benjamin Adams','benjamin.adams@example.com','12345','user','Marketing','SAM005'),('MKT002','Charlotte Nelson','charlotte.nelson@example.com','12345','user','Marketing','SAM005'),('MKT003','Henry Carter','henry.carter@example.com','12345','user','Marketing','SAM005'),('MKT004','Evelyn Mitchell','evelyn.mitchell@example.com','12345','user','Marketing','SAM005'),('MKT005','Alexander Perez','alexander.perez@example.com','12345','user','Marketing','SAM005'),('OPS001','Noah King','noah.king@example.com','12345','user','Operations','SAM004'),('OPS002','Emma Wright','emma.wright@example.com','12345','user','Operations','SAM004'),('OPS003','Lucas Lopez','lucas.lopez@example.com','12345','user','Operations','SAM004'),('OPS004','Amelia Scott','amelia.scott@example.com','12345','user','Operations','SAM004'),('OPS005','William Green','william.green@example.com','12345','user','Operations','SAM004'),('SAM001','Alice Manager','alice@example.com','12345','sam','IT',NULL),('SAM002','Bob Manager','bob@example.com','12345','sam','HR',NULL),('SAM003','Charlie Manager','charlie@example.com','12345','sam','Finance',NULL),('SAM004','Diana Manager','diana@example.com','12345','sam','Operations',NULL),('SAM005','Ethan Manager','ethan@example.com','12345','sam','Marketing',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-09  7:58:51
