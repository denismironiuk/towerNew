export const fakeUsers = [
  {
    username: "admin",
    password: "admin123",
    role: "admin",
  },
  {
    username: "sam",
    password: "sam123",
    role: "SAM",
    profile: {
      name: "Kosta Amirov",
      role: "Station Activity Manager",
      department: "Etch",
      certifications: [
        { name: "Centura Poly", date: "22/11/2025" },
        { name: "Centura Metal", date: "02/06/2025" },
        { name: "Asher", date: "12/02/2025" },
        { name: "Metrology", date: "12/02/2025" },
      ],
      tutorials: [{ name: "Safety Training", date: "26/05/2025" }],
      swa: { total: 10, last: "12/12/2024" },
    },
  },
  {
    username: "user",
    password: "user123",
    role: "user",
    profile: {
      name: "Amirov",
      role: "Customer Service Engineer",
      department: "Dry Etch",
      certifications: [
        { name: "Centura legacy5200", date: "22/11/2025" },
        { name: "Centura AP", date: "02/08/2025" },
        { name: "Qualified Electrician", date: "12/01/2025" },
      ],
      tutorials: [{ name: "Safety Training", date: "26/05/2025" }],
      swa: { total: 10, last: "12/12/2024" },
    },
  },
];

// ✅ Add the missing fakeLogin function
export const fakeLogin = (username, password) => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      const user = fakeUsers.find((u) => u.username === username && u.password === password);
      if (user) {
        resolve(user);
      } else {
        reject("Invalid username or password!");
      }
    }, 1000);
  });
};

// Fake API function to fetch user profile
export const fetchUserProfile = (username) => {
  return new Promise((resolve) => {
    setTimeout(() => {
      const user = fakeUsers.find((u) => u.username === username);
      resolve(user ? user.profile : null);
    }, 1000);
  });
};
