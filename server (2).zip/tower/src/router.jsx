import { createBrowserRouter, Navigate, Outlet } from "react-router-dom";
import { lazy, Suspense } from "react";
import ProtectedRoute from "./components/protected/ProtectedRoute";
import NotFound from "./pages/NotFound";
import AuthRedirect from "./components/protected/AuthRedirect";
import AuditPage from "./features/audit/pages/AuditPage";
import SubordinatesPage from "./features/sam/pages/SubordinatesPage";
import TasksPage from "./features/sam/pages/TasksPage";
import ReportsPage from "./features/sam/pages/ReportsPage";
import SubordinateDetails from "./features/sam/components/SubordinateDetails";
import AnnualPlanPage from "./features/admin/AnnualPlanPage/AnnualPlanPage";
import IncidentReportPage from "./features/admin/IncidentReportPage/IncidentReportPage";
import SafetyAuditPage from "./features/admin/SafetyAuditPage/SafetyAuditPage";
import TrainingsPage from "./features/admin/TrainingPage/TrainingsPage";
import DoWeSafetyWalkPage from "./features/admin/DoWeSafetyWalkPage/DoWeSafetyWalkPage";
import DashboardLayout from "./features/admin/AdminDashboardPage/layout/DashboardLayout";

import AvailabelTrainingsPage from "./features/admin/TrainingPage/pages/AvailabelTrainingsPage";
import AvailableCertificationsPage from "./features/admin/DoWeSafetyWalkPage/pages/AvailableCertificationsPage";



// ✅ Lazy load all components
const Authentication = lazy(() => import("./features/authentication/components/Authentication"));
const AdminDashboard = lazy(() => import("./features/admin/AdminDashboardPage/AdminDashboard"));
const SafetyWalkAround = lazy(() => import("./features/swa/pages/SafetyWalkAroundPage"));
const Profile = lazy(() => import("./features/profile/pages/Profile"));
const TutorialAssignment = lazy(() => import("./features/admin/TrainingPage/pages/TrainingAssignmentPage"))
const CertificationAssignment = lazy(() => import("./features/admin/DoWeSafetyWalkPage/pages/CertificationAssignmentPage"))

// ✅ Centralized Suspense Wrapper
const LazyWrapper = ({ children }) => <Suspense fallback={<div>Loading...</div>}>{children}</Suspense>;
const ForgotPassword = lazy(() => import("./features/authentication/pages/ForgotPassword"));
const ResetPassword = lazy(() => import("./features/authentication/pages/ResetPassword"));

const router = createBrowserRouter([
  { path: "/", element: <Navigate to="/login" /> },
  {
    path: "/forgot-password",
    element: (
      <LazyWrapper>
        <AuthRedirect>
          <ForgotPassword />
        </AuthRedirect>
      </LazyWrapper>
    ),
  },
  {
    path: "/reset-password/:token",
    element: (
      <LazyWrapper>
        <ResetPassword />
      </LazyWrapper>
    ),
  },
  

  // ✅ Public Routes
  {
    path: "/login",
    element: (
      <LazyWrapper>
        <AuthRedirect>
          <Authentication />
        </AuthRedirect>
      </LazyWrapper>
    ),
  },

  // ✅ Admin Dashboard Route (Protected)
  {
    path: "/dashboard",
    element: <ProtectedRoute allowedRoles={["admin"]}> 
    <DashboardLayout/> </ProtectedRoute>,
    children: [
      { index: true, element: <LazyWrapper><AdminDashboard /></LazyWrapper> },
      {
        path: "annual-plan",
        element: <LazyWrapper><AnnualPlanPage /></LazyWrapper>
      },
      {
        path: "incident-report",
        element: <LazyWrapper><IncidentReportPage /></LazyWrapper>
      },
      {
        path: "safety-audit",
        element: <LazyWrapper><SafetyAuditPage /></LazyWrapper>,
        children:[

        ]
      },
      {
        path: "safety-training",
        element: <LazyWrapper><TrainingsPage /></LazyWrapper>,
        children: [
          {
            index: true, // ✅ default when "/safety-training"
            element: <LazyWrapper><TutorialAssignment /></LazyWrapper>,
          },
          {
            path: "workers",
            element: <LazyWrapper><TutorialAssignment /></LazyWrapper>,
          },
          {
            path: "list",
            element: <LazyWrapper><AvailabelTrainingsPage /></LazyWrapper>,
          }
        ]
      },
      {
        path: "safety-certification",
        element: <LazyWrapper><DoWeSafetyWalkPage/></LazyWrapper>,
        children: [
          {
            index: true, 
            element: <LazyWrapper><CertificationAssignment/></LazyWrapper>,
          },
          {
            path: "workers",
            element: <LazyWrapper><CertificationAssignment /></LazyWrapper>,
          },
          {
            path: "list",
            element: <LazyWrapper><AvailableCertificationsPage/></LazyWrapper>,
          }
        ]
      },
      
    ],
  },
  

  // ✅ Profile Route (Protected for User & SAM)
  {
    path: "/profile",
    element: <ProtectedRoute allowedRoles={["user", "sam"]} >
      <Outlet/>
    </ProtectedRoute>,
    children: [
      { index: true, element: <LazyWrapper><Profile /></LazyWrapper> },
  
      // ✅ Only accessible for "sam" users
      { path: ":subordinateId", element: <LazyWrapper><SubordinateDetails /></LazyWrapper> }, // ✅ New User Profile Route
      { path: "subordinates", element: <LazyWrapper><SubordinatesPage /></LazyWrapper> },
      { path: "tasks", element: <LazyWrapper><TasksPage /></LazyWrapper> },
      { path: "reports", element: <LazyWrapper><ReportsPage /></LazyWrapper> },
    ],
  },
  // ✅ Audit Form Route (Accessible from Profile Page)
  {
    path: "/audit",
    element: <ProtectedRoute allowedRoles={["user", "sam"]} >
      <Outlet/>
    </ProtectedRoute>,
    children: [
      { index: true, element: <LazyWrapper><AuditPage /></LazyWrapper> },
    ],
  },

 
  // ✅ Safety Walk Around (Protected for Multiple Roles)
  {
    path: "/safety-walk-around/:auditRecordId",
    element: <ProtectedRoute allowedRoles={["user", "sam"]} >
    <Outlet/>
  </ProtectedRoute>,
    children: [
      { index: true, element: <LazyWrapper><SafetyWalkAround /></LazyWrapper> },
    ],
  },

  // ✅ 404 - Not Found Route
  { path: "*", element: <NotFound /> },
]);

export default router;
