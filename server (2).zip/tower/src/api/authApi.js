import API from "./api"; // ✅ Use axiosInstance instead of axios

// ✅ Login API Call
export const loginUser = async (email, password) => {
    try {
        const response = await API.post("/auth/login", { email, password });

        // ✅ Store tokens in localStorage
        localStorage.setItem("token", response.data.access_token);
        localStorage.setItem("refreshToken", response.data.refresh_token);

        return response.data;
    } catch (error) {
        throw error.response?.data?.message || "Login failed";
    }
};

// ✅ Verify User API Call
export const verifyUser = async () => {
    try {
        const response = await API.get("/auth/me");
        return response.data;
    } catch (error) {
        throw error.response?.data?.message || "Unauthorized";
    }
};

// ✅ Refresh Token API Call
export const refreshToken = async () => {
    try {
        const response = await API.post("/auth/refresh", {
            refresh_token: localStorage.getItem("refreshToken"),
        });

        // ✅ Store new token
        localStorage.setItem("token", response.data.access_token);

        return response.data.access_token;
    } catch (error) {
        console.error("❌ Error refreshing token:", error);
        logoutUser(); // ✅ Logout if refresh fails
        throw error;
    }
};

// ✅ Logout Function (Clears all stored data)
export const logoutUser = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("refreshToken");
    localStorage.removeItem("user");
};
