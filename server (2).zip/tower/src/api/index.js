import API from "./api";
import { loginUser, verifyUser, logoutUser } from "./authApi";


export {
    API,
    loginUser,
    verifyUser,
    logoutUser,
    
};
