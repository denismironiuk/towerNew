import axios from "axios";

const API_URL = "http://localhost:5000/api/users"; // Change if your backend uses a different URL

// ✅ Fetch all Fab Site Managers
export const fetchFabManagers = async () => {
  try {
    const response = await axios.get(`${API_URL}/fab-managers`);
    return response.data;
  } catch (error) {
    console.error("❌ Error fetching Fab Managers:", error);
    throw error;
  }
};
