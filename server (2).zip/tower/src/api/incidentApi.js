import axios from "axios";

const API_URL = "http://localhost:5000/api/incidents"; // ✅ Update if needed

// ✅ Create a new incident
export const createIncident = async (incidentData, token) => {
  try {
    const response = await axios.post(API_URL, incidentData, {
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json"
      }
    });
    return response.data;
  } catch (error) {
    console.error("❌ Error creating incident:", error.response?.data || error);
    throw error;
  }
};

// ✅ Fetch incidents
export const fetchIncidents = async (token) => {
  try {
    const response = await axios.get(API_URL, {
      headers: {
        Authorization: `Bearer ${token}`
      }
    });
    return response.data;
  } catch (error) {
    console.error("❌ Error fetching incidents:", error.response?.data || error);
    throw error;
  }
};
