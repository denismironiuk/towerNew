import axios from "axios";
const API_URL = "http://localhost:5000/api/users";

// ✅ Get all subordinates
export const fetchSubordinates = async (token) => {
  try {
    const response = await axios.get(`${API_URL}/workers`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    return response.data;
  } catch (error) {
    console.error("❌ Error fetching subordinates:", error.response?.data || error);
    throw error;
  }
};
