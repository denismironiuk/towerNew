import React, { useContext, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import Navbar from "../components/SafetyWalkAround/Navbar";
import AuditForm from "../components/SafetyWalkAround/AuditForm";
import styles from "./SafetyWalkAround.module.css";
import {createIncident} from '../api/incidentApi'
import AuthContext from "../context/AuthContext";

const SafetyWalkAround = () => {
  const {token}=useContext(AuthContext)
  const navigate = useNavigate();
  const { auditRecordId } = useParams();
  const [formData, setFormData] = useState({});
 

  // ✅ Save Data ONLY When Clicking the Button
  const handleSave = async () => {
    console.log("🚀 Saving Audit Data:", JSON.stringify(formData, null, 2));
  
    if (!formData || Object.keys(formData).length === 0) {
      alert("⚠️ No data to save!");
      return;
    }
  
    try {
      let incidentsToSave = [];
  
      // ✅ Loop through sections
      Object.keys(formData).forEach((sectionKey) => {
        const sectionId = sectionKey.replace("section", ""); // Extract section number
        const questions = formData[sectionKey];
  
        // ✅ Loop through questions
        Object.keys(questions).forEach((questionId) => {
          const { score, issue, action } = questions[questionId];
  
          // ✅ Prepare incident data
          const incidentData = {
            audit_record_id: auditRecordId, // ✅ Use audit record ID from URL params
            section_id: sectionId,
            issue_description: issue || "", // Optional
            score: score,
            supporting_media: "", // No media for now
            corrective_action: action || "", // Optional
          };
  
          incidentsToSave.push(incidentData);
        });
      });
  
      console.log("🚀 Sending Incidents to DB:", JSON.stringify(incidentsToSave, null, 2));
 
      // ✅ Send all incidents to backend
      for (let incident of incidentsToSave) {
        await createIncident(incident, token);
      }
  
      alert("✅ Audit data saved successfully!");
      navigate("/dashboard"); // ✅ Redirect after saving
    } catch (error) {
      console.error("❌ Error saving audit data:", error);
      alert("Error saving audit. Please try again.");
    }
  };
  
  return (
    <div className={styles.container}>
      <Navbar />

      {/* ✅ Breadcrumb Navigation */}
      <div className={styles.breadcrumb}>
        <div><Link to="/dashboard">Home</Link> &gt; <span>Create Audit</span></div> 
        <div className={styles.auditActions}>
          <button className={styles.save} onClick={handleSave}>Save</button>
          <button className={styles.exit} onClick={() => navigate("/profile")}>Exit</button>
        </div>
      </div>

      {/* ✅ Pass state & update function to AuditForm */}
      <AuditForm formData={formData} setFormData={setFormData} />
    </div>
  );
};

export default SafetyWalkAround;
