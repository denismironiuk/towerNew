import React, { useRef, useEffect, useState } from "react";

const EditableEhsDashboard = () => {
    const canvasRef = useRef(null);
    
    // Default points for sections
    const [sections, setSections] = useState([
        [[300, 300], [880, 300], [960, 260], [960, 310], [880, 360], [300, 360]],
        [[300, 360], [880, 360], [960, 410], [960, 460], [880, 510], [300, 510]],
        [[300, 510], [880, 510], [960, 560], [960, 610], [880, 660], [300, 660]],
        [[300, 660], [880, 660], [960, 710], [960, 760], [880, 810], [300, 810]],
        [[300, 810], [880, 810], [960, 860], [960, 910], [880, 960], [300, 960]],
    ]);

    useEffect(() => {
        const canvas = canvasRef.current;
        const ctx = canvas.getContext("2d");
        
        canvas.width = 975;
        canvas.height = 768;

        function drawPolygon(points, color) {
            ctx.beginPath();
            ctx.moveTo(points[0][0], points[0][1]);
            for (let i = 1; i < points.length; i++) {
                ctx.lineTo(points[i][0], points[i][1]);
            }
            ctx.closePath();
            ctx.fillStyle = color;
            ctx.fill();
            ctx.strokeStyle = "white";
            ctx.lineWidth = 2;
            ctx.stroke();
        }

        // Clear canvas before drawing
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        // Draw the EHS Dashboard Circle
        ctx.beginPath();
        ctx.arc(180, 384, 120, 0, 2 * Math.PI);
        ctx.fillStyle = "#2c233d";
        ctx.fill();
        ctx.strokeStyle = "white";
        ctx.lineWidth = 2;
        ctx.stroke();
        ctx.fillStyle = "white";
        ctx.font = "bold 22px Arial";
        ctx.fillText("EHS Dashboard", 110, 390);

        // Colors for sections
        const colors = ["#6D377D", "#7D44A3", "#9655BE", "#B26FD6", "#CA8AEF"];
        
        // Draw each section
        sections.forEach((points, index) => drawPolygon(points, colors[index]));
    }, [sections]); // Redraw when points change

    // Function to update a specific point
    const updatePoint = (sectionIndex, pointIndex, axis, value) => {
        setSections(prevSections => {
            const updatedSections = [...prevSections];
            updatedSections[sectionIndex] = [...updatedSections[sectionIndex]];
            updatedSections[sectionIndex][pointIndex] = [...updatedSections[sectionIndex][pointIndex]];
            updatedSections[sectionIndex][pointIndex][axis === "x" ? 0 : 1] = value;
            return updatedSections;
        });
    };

    return (
        <div style={{ display: "flex", gap: "20px" }}>
            {/* Canvas Display */}
            <canvas ref={canvasRef} width={975} height={768} style={{ backgroundColor: "transparent" }} />
            
            {/* Control Panel */}
            <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
                <h3>Adjust Points</h3>
                {sections.map((section, sectionIndex) => (
                    <div key={sectionIndex} style={{ borderBottom: "1px solid gray", paddingBottom: "10px" }}>
                        <h4>Section {sectionIndex + 1}</h4>
                        {section.map((point, pointIndex) => (
                            <div key={pointIndex}>
                                <label>Point {pointIndex + 1} (X, Y): </label>
                                <input
                                    type="number"
                                    value={point[0]}
                                    onChange={(e) => updatePoint(sectionIndex, pointIndex, "x", parseInt(e.target.value))}
                                    style={{ width: "60px", marginRight: "5px" }}
                                />
                                <input
                                    type="number"
                                    value={point[1]}
                                    onChange={(e) => updatePoint(sectionIndex, pointIndex, "y", parseInt(e.target.value))}
                                    style={{ width: "60px" }}
                                />
                            </div>
                        ))}
                    </div>
                ))}
            </div>
        </div>
    );
};

export default EditableEhsDashboard;
