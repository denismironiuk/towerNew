import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { ThemeProvider, CssBaseline, createTheme } from "@mui/material";
import "@mui/material/styles";
import "@mui/x-data-grid";

import '@fontsource/roboto/300.css';
import '@fontsource/roboto/400.css';
import '@fontsource/roboto/500.css';
import '@fontsource/roboto/700.css';

import './index.css'
import App from './App.jsx'
import './utils/axiosConfig.js'
createRoot(document.getElementById('root')).render(

    <App />
  
)
