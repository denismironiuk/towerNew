import React from "react";

import ProfileContainer from "../containers/ProfileContainer";

const Profile = () => {

  return <ProfileContainer />;
};

export default Profile;
