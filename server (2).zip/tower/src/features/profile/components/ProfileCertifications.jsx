import React from "react";
import { Box, Typography, List, ListItem, ListItemText, Divider } from "@mui/material";

const ProfileCertifications = ({ certifications = [] }) => {
  const formatDate = (dateString) => {
    if (!dateString) return "N/A";
    return new Date(dateString).toLocaleDateString("ru-RU");
  };

  return (
    <Box mt={4}>
      <Typography variant="h6" gutterBottom>
        Certifications
      </Typography>

      {certifications.length === 0 ? (
        <Typography variant="body2" color="text.secondary">
          No certifications assigned.
        </Typography>
      ) : (
        <List disablePadding>
          {certifications.map((cert, index) => (
            <React.Fragment key={index}>
              <ListItem>
                <ListItemText sx={{display:'flex',justifyContent:'space-between'}}
                  primary={cert.name}
                  secondary={`Valid Until: ${formatDate(cert.valid_until)}`}
                />
              </ListItem>
              {index < certifications.length - 1 && <Divider />}
            </React.Fragment>
          ))}
        </List>
      )}
    </Box>
  );
};

export default ProfileCertifications;
