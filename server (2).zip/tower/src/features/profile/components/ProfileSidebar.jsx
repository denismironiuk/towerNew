import React, { useContext } from "react";
import styles from "../styles/ProfileSidebar.module.css";
import ProfilePic from "../../../assets/default.webp";  
import TowerLogo from "../../../assets/Tower_Semiconductor.svg.png";
import { Link } from "react-router-dom";
import AuthContext from "../../../context/AuthContext";

const ProfileSidebar = ({ user }) => {
  const { logout } = useContext(AuthContext);

  const handleLogout = () => {
    if (window.confirm("Are you sure you want to log out?")) {
      logout();
    }
  };

  return (
    <aside className={styles.container}>
      <div className={styles.sidebar}>
        <img src={TowerLogo} alt="Tower Semiconductor" className={styles.logo} />
        <img src={ProfilePic} alt="User" className={styles.profileImage} />

        <div className={styles.info}>
          <h2>👤 Personal Information</h2>
          <h3>{user?.name || "Unknown"}</h3>
          <p>{user?.position || "No Position"}</p>
          <p>{user?.department || "No Department"}</p>
        </div>

        <nav className={styles.nav}>
          <ul>
            {["sam", "manager"].includes(user?.position) && (
              <>
                <li><Link to="/profile/subordinates">👥 Subordinates</Link></li>
                <li><Link to="/profile/tasks">📋 Tasks</Link></li>
                
              </>
            )}
          </ul>
        </nav>
      </div>

      <button className={styles.logoutButton} onClick={handleLogout}>
        🚪 Logout
      </button>
    </aside>
  );
};

export default ProfileSidebar;
