import React from "react";
import { Box, Typography, List, ListItem, ListItemText, Divider } from "@mui/material";

const ProfileTutorials = ({ tutorials = [] }) => {
  const formatDate = (dateString) => {
    if (!dateString) return "N/A";
    return new Date(dateString).toLocaleDateString("ru-RU");
  };

  return (
    <Box mt={4}>
      <Typography variant="h6" gutterBottom>
        Tutorials
      </Typography>

      {tutorials.length === 0 ? (
        <Typography variant="body2" color="text.secondary">
          No tutorials assigned.
        </Typography>
      ) : (
        <List disablePadding>
          {tutorials.map((tutorial, index) => (
            <React.Fragment key={index}>
              <ListItem>
                <ListItemText sx={{display:'flex',justifyContent:'space-between'}}
                  primary={tutorial.name}
                  secondary={`Valid Until: ${formatDate(tutorial.valid_until)}`}
                />
              </ListItem>
              {index < tutorials.length - 1 && <Divider />}
            </React.Fragment>
          ))}
        </List>
      )}
    </Box>
  );
};

export default ProfileTutorials;
