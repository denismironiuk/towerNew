import React from "react";
import { Box, Typography, List, ListItem, ListItemText } from "@mui/material";

const ProfileSWA = ({ auditRecordCount = 0, lastAuditRecord = null }) => {
  const formatDate = (date) => {
    if (!date) return "N/A";
    return new Date(date).toLocaleDateString("ru-RU");
  };

  return (
    <Box mt={4}>
      <Typography variant="h6" gutterBottom>
        SWA (Safety Walk-Around)
      </Typography>

      <List disablePadding>
        <ListItem>
          <ListItemText primary="Total Audits" secondary={auditRecordCount} />
        </ListItem>
        {lastAuditRecord && (
          <ListItem>
            <ListItemText
              primary="Last Completed"
              secondary={formatDate(lastAuditRecord.date_completed)}
            />
          </ListItem>
        )}
      </List>
    </Box>
  );
};

export default ProfileSWA;
