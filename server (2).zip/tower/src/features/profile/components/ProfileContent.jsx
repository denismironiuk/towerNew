import React from 'react';
import styles from '../styles/ProfileContent.module.css';
import ProfileCertifications from './ProfileCertifications';
import ProfileTutorials from './ProfileTutorials';
import ProfileSWA from './ProfileSWA';
import { useNavigate } from 'react-router-dom';

const ProfileContent = ({ user, isCurrentUser }) => {
  const navigate = useNavigate();

  console.log(user);
  const handleNewAudit = () => {
    navigate('/audit', { state: { user } }); // ✅ Pass user data via React Router state
  };
  return (
    <div className={styles.content}>
      <ProfileCertifications certifications={user?.certifications} />
      <ProfileTutorials tutorials={user?.tutorials} />
      <ProfileSWA
        lastAuditRecord={user?.lastAuditRecord}
        auditRecordCount={user?.auditRecordCount}
      />

      {/* <ProfileSWA swa={user.swa} /> */}
      {isCurrentUser && (
  <div style={{ width: "100%", display: "flex", justifyContent: "flex-end" }}>
    <button className={styles.auditButton} onClick={handleNewAudit}>
      New Audit
    </button>
  </div>
)}
    </div>
  );
};

export default ProfileContent;
