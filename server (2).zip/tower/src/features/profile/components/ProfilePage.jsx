// ProfilePage.jsx
import React from "react";
import ProfileSidebar from "./ProfileSidebar";
import ProfileContent from "./ProfileContent";
import styles from "../styles/ProfilePage.module.css";

const ProfilePage = ({ profile }) => {
 
  return (
    <div className={styles.profilePage}>
      <ProfileSidebar user={profile}  />
      <ProfileContent user={profile} isCurrentUser={profile.isCurrentUser} />
    </div>
  );
};

export default ProfilePage;
