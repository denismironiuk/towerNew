// ProfileContainer.jsx
import React from "react";
import useProfile from "../hooks/useProfile";
import ProfilePage from "../components/ProfilePage";

const ProfileContainer = () => {
  const { profile, loading  } = useProfile();
  
  console.log(profile)

  if (loading) {
    return <div>Loading profile...</div>;
  }

  if (!profile) {
    return <div>Error loading profile</div>;
  }

  return <ProfilePage profile={{...profile,isCurrentUser:true}}  />;
};

export default ProfileContainer;
