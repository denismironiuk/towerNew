// hooks/useProfile.js
import { useState, useEffect, useContext } from "react";
import AuthContext from "../../../context/AuthContext";
import { useNavigate } from "react-router-dom";
import axiosInstance from "../../../utils/axiosConfig";

const useProfile = () => {
  const { token, user, logout } = useContext(AuthContext);
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    if (user.position === "admin") {
      navigate("/dashboard", { replace: true });
    }
  }, [user.position, navigate]);

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        if (process.env.NODE_ENV !== "production") {
          console.log("📡 Fetching profile...");
        }

        const { data } = await axiosInstance.get("/user-profile");

        if (process.env.NODE_ENV !== "production") {
          console.log("🔹 Profile Data:", data);
        }

        setProfile(data);
      } catch (error) {
        console.error("❌ Error fetching profile:", error.message);

        if (error.response?.status === 401) {
          console.log("🚨 Token expired, logging out...");
          logout();
          navigate("/login", { replace: true });
        }
      } finally {
        setLoading(false);
      }
    };

    if (token) {
      fetchProfile();
    }
  }, [token, logout, navigate]);

  return { profile, loading,logout };
};

export default useProfile;
