// api/auditRecordApi.js
import axiosInstance from "../../../utils/axiosConfig"

const API_URL = "/audit-records"; // Base path only

// ✅ Get all audit records
export const fetchAuditRecords = async () => {
  try {
    const response = await axiosInstance.get(API_URL);
    return response.data;
  } catch (error) {
    console.error("❌ Error fetching audit records:", error);
    throw error;
  }
};

// ✅ Get audit record by ID
export const fetchAuditRecordById = async (id) => {
  try {
    const response = await axiosInstance.get(`${API_URL}/${id}`);
    return response.data;
  } catch (error) {
    console.error("❌ Error fetching audit record:", error);
    throw error;
  }
};

// ✅ Add a new audit record
export const createAuditRecord = async ({ data }) => {
  try {
    const response = await axiosInstance.post(API_URL, data);
    return response.data;
  } catch (error) {
    console.error("❌ Error adding audit record:", error);
    throw error;
  }
};

// ✅ Update an audit record
export const updateAuditRecord = async ({ id, data }) => {
  try {
    const response = await axiosInstance.put(`${API_URL}/${id}`, data);
    return response.data;
  } catch (error) {
    console.error("❌ Error updating audit record:", error);
    throw error;
  }
};

// ✅ Delete an audit record
export const deleteAuditRecord = async (id) => {
  try {
    const response = await axiosInstance.delete(`${API_URL}/${id}`);
    return response.data;
  } catch (error) {
    console.error("❌ Error deleting audit record:", error);
    throw error;
  }
};
