import React from "react";
import styles from "../styles/AuditInstructions.module.css";

const AuditInstructions = () => {
  return (
    <div className={styles.instructions}>
      <h3>Directions for completing this audit:</h3>
      <ul>
        <li>Only audit work areas that you are familiar with.</li>
        <li><b>DO NOT</b> disturb individuals performing maintenance unless an imminent dangerous condition is noticed.</li>
        <li>Complete all portions of the audit ensuring to include comments for scores 1, 2, or 3.</li>
        <li>Scoring is based on a 4.0 scale. Section and overall score is an average of all scores.</li>
        <li>Questions? Direct them to your manager!</li>
      </ul>
    </div>
  );
};

export default AuditInstructions;
