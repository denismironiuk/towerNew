// AuditForm.jsx with required field validation and red border on Save
import React, { useEffect, useState, useMemo, useCallback } from 'react';
import {
  Box,
  TextField,
  MenuItem,
  Autocomplete
} from '@mui/material';
import AuditInstructions from './AuditInstructions';
import AuditRatingLegend from './AuditRatingLegend';
import { fetchFabManagers } from '../../../api/userApi';
import debounce from 'lodash.debounce';

const LOCATIONS = ['Fab1', 'Fab2'];
const SHIFTS = ['Morning', 'Night'];
const FAB_AREAS = ['Etch', 'Deposition'];
const TOOLSETS = ['AMAT', 'LAM'];

const AuditForm = ({ formData, setFormData, formTouched }) => {
  const [fabManagers, setFabManagers] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    const loadFabManagers = async () => {
      try {
        const data = await fetchFabManagers();
        setFabManagers(data);
      } catch (error) {
        console.error('❌ Error loading fab managers:', error);
      }
    };
    loadFabManagers();
  }, []);

  const filteredManagers = useMemo(() => {
    if (!searchQuery) return fabManagers;
    return fabManagers.filter((manager) =>
      manager.name.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [searchQuery, fabManagers]);

  const handleManagerInputChange = useCallback(
    debounce((value) => {
      setSearchQuery(value);
    }, 30),
    []
  );

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSelectManager = (event, value) => {
    if (value) {
      setFormData({
        ...formData,
        fab_manager: value.employee_number,
        fab_manager_name: value.name,
      });
    }
  };

  const getError = (field) => formTouched && !formData[field];

  return (
    <>
      <Box
        sx={{
          display: 'flex',
          flexWrap: 'wrap',
          justifyContent: 'space-around',
          gap: 2,
          pt: 2
        }}
      >
        <Box sx={{ flex: 1 }}>
          <TextField
            label="Name"
            name="name"
            value={formData.name}
            onChange={handleChange}
            fullWidth
            InputProps={{ readOnly: true }}
            error={getError('name')}
            
            
          />
          <TextField
            label="Date Audit Completed"
            name="date_completed"
            value={formData.date_completed}
            onChange={handleChange}
            fullWidth
            InputProps={{ readOnly: true }}
            sx={{ mt: 2 }}
            error={getError('date_completed')}
           
            
          />
          <TextField
            select
            label="Location"
            name="location"
            value={formData.location}
            onChange={handleChange}
            fullWidth
            sx={{ mt: 2 }}
            error={getError('location')}
            
            
          >
            {LOCATIONS.map((loc) => (
              <MenuItem key={loc} value={loc}>{loc}</MenuItem>
            ))}
          </TextField>
          <TextField
            select
            label="Current Shift"
            name="shift"
            value={formData.shift}
            onChange={handleChange}
            fullWidth
            sx={{ mt: 2 }}
            error={getError('shift')}
            
            
          >
            {SHIFTS.map((shift) => (
              <MenuItem key={shift} value={shift}>{shift}</MenuItem>
            ))}
          </TextField>
        </Box>

        <Box sx={{ flex: 1 }}>
          <Autocomplete
            options={filteredManagers}
            getOptionLabel={(option) => option.name || ''}
            inputValue={searchQuery}
            onInputChange={(event, newInputValue) =>
              handleManagerInputChange(newInputValue)
            }
            onChange={handleSelectManager}
            renderInput={(params) => (
              <TextField
                {...params}
                label="Fab Site Manager"
                fullWidth
                error={getError('fab_manager')}
                
                
              />
            )}
          />
          <TextField
            select
            label="Fab/Area"
            name="fab_area"
            value={formData.fab_area}
            onChange={handleChange}
            fullWidth
            sx={{ mt: 2 }}
            error={getError('fab_area')}
            
            
          >
            {FAB_AREAS.map((area) => (
              <MenuItem key={area} value={area}>{area}</MenuItem>
            ))}
          </TextField>
          <TextField
            select
            label="Toolset"
            name="toolset"
            value={formData.toolset}
            onChange={handleChange}
            fullWidth
            sx={{ mt: 2 }}
            error={getError('toolset')}
            
            
            
          >
            {TOOLSETS.map((tool) => (
              <MenuItem key={tool} value={tool}>{tool}</MenuItem>
            ))}
          </TextField>
          <TextField
            label="Additional Tool Detail"
            name="additional_details"
            value={formData.additional_details}
            onChange={handleChange}
            fullWidth
            sx={{ mt: 2 }}
          />
        </Box>

        <Box sx={{ flex: 1 }}>
          <AuditInstructions />
        </Box>
      </Box>

      <AuditRatingLegend />
    </>
  );
};

export default AuditForm;