import React from "react";
import styles from "../styles/AuditRatingLegend.module.css";

const AuditRatingLegend = () => {
  return (
    <div className={styles.legend}>
      
      <ul>
        <li ><span className={styles.red}>1</span> - Unsafe: Needs escalation / immediate attention required.</li>
        <li ><span className={styles.yellow}>2</span> - Unsafe / Near miss: Notification of safety issue.</li>
        <li ><span className={styles.green}>3</span>- Quick clean up: Corrected on the spot.</li>
        <li ><span className={styles.blue}>4</span> - Safe condition.</li>
      </ul>
    </div>
  );
};

export default AuditRatingLegend;
