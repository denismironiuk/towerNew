import AuditContainer from "../containers/AuditContainer";


const AuditPage = () => {
  

  return (

    
    <AuditContainer/>
    
  );
};

export default AuditPage;
