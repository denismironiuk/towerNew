import React, { useContext, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import AuthContext from '../../../context/AuthContext';
import Navbar from '../../commons/Navbar';
import Breadcrumb from '../../../components/ui/Breadcrumb';
import AuditForm from '../components/AuditForm';
import { createAuditRecord } from '../services/auditRecordApi';

const initialFormData = {
  name: '',
  date_completed: new Date().toISOString().split('T')[0],
  location: '',
  shift: '',
  fab_area: '',
  toolset: '',
  additional_details: '',
  fab_manager: '',
};

const AuditCreateContainer = () => {
  const { token, user } = useContext(AuthContext);
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    ...initialFormData,
    name: user?.name || '',
  });

  const [formTouched, setFormTouched] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  const isFormValid = () => {
    return (
      formData.name?.trim() &&
      formData.date_completed?.trim() &&
      formData.location &&
      formData.shift &&
      formData.fab_area &&
      formData.toolset &&
      formData.fab_manager
    );
  };

  const handleSave = async () => {
    setFormTouched(true);
    if (!isFormValid()) {
      console.warn('Form is invalid, please complete all required fields.');
      return;
    }

    try {
      setIsSaving(true);
      const { fab_manager, ...rest } = formData;
      const payload = {
        ...rest,
        fab_manager_id: fab_manager,
      };
      const newRecord = await createAuditRecord({ data: payload });
      console.log('✅ Audit record saved:', newRecord);
      navigate(`/safety-walk-around/${newRecord.id}`);
    } catch (error) {
      console.error('❌ Error saving audit record:', error);
      alert('Failed to save audit record.');
    } finally {
      setIsSaving(false);
    }
  };

  if (!token || !user) return <div>Loading...</div>;

  return (
    <>
      <Navbar />
      <Breadcrumb onSave={handleSave} isSaving={isSaving} />
      <AuditForm
        formData={formData}
        setFormData={setFormData}
        formTouched={formTouched}
      />
    </>
  );
};

export default AuditCreateContainer;
