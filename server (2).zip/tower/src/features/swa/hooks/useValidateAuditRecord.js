import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { fetchAuditRecordById } from '../../audit/services/auditRecordApi';

const useValidateAuditRecord = (auditRecordId, token) => {
  const [auditRecord, setAuditRecord] = useState(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const validate = async () => {
      try {
        const record = await fetchAuditRecordById(auditRecordId, token);
        if (!record || record.auditStatus !== 'Incomplete') {
          alert('Access denied: This audit is already completed or does not exist.');
          return navigate('/dashboard');
        }
        setAuditRecord(record);
      } catch (error) {
        console.error('❌ Error validating audit:', error);
        alert('Failed to validate audit. Redirecting...');
        navigate('/profile');
      } finally {
        setLoading(false);
      }
    };

    validate();
  }, [auditRecordId, token, navigate]);

  return { auditRecord, loading };
};

export default useValidateAuditRecord;
