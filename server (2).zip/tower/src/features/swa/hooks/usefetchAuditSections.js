import { useState, useEffect } from "react";
import { fetchAuditSections, fetchAuditQuestions } from "../services/incidentService"; // adjust the path if needed

const useFetchAuditSections = () => {
  const [auditSections, setAuditSections] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchAuditData = async () => {
      try {
        const sections = await fetchAuditSections();
        const questionsPromises = sections.map((section) =>
          fetchAuditQuestions(section.id)
        );
        const questionsData = await Promise.all(questionsPromises);

        const formattedSections = sections.map((section, index) => ({
          ...section,
          questions: questionsData[index] || [],
        }));

        setAuditSections(formattedSections);
      } catch (err) {
        console.error("❌ Error fetching audit data:", err);
        setError(err.message || "Failed to load audit data.");
      } finally {
        setLoading(false);
      }
    };

    fetchAuditData();
  }, []);

  return { auditSections, loading, error };
};

export default useFetchAuditSections;
