// SafetyWalkAroundContainer.js
import React, { useContext, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import AuthContext from "../../../context/AuthContext";
import Navbar from "../../commons/Navbar";
import styles from "../styles/SafetyWalkAround.module.css";
import { updateAuditRecord } from "../../audit/services/auditRecordApi";
import SWAForm from "../components/SWAForm";
import useValidateAuditRecord from "../hooks/useValidateAuditRecord";
import axiosInstance from "../../../utils/axiosConfig";

const SafetyWalkAroundContainer = () => {
  const { token } = useContext(AuthContext);
  const { auditRecordId } = useParams();
  const { loading } = useValidateAuditRecord(auditRecordId, token);
  const [formData, setFormData] = useState({});
  const navigate = useNavigate();

  const handleSave = async () => {
    if (!formData || Object.keys(formData).length === 0) {
      alert("⚠️ No data to save!");
      return;
    }

    try {
      const incidents = [];
      const formDataToSend = new FormData();

      Object.entries(formData).forEach(([sectionId, questions]) => {
        Object.entries(questions).forEach(([questionId, { score, issue, action, files = [] }]) => {
          const numericScore = parseInt(score);
          if (!numericScore || numericScore < 1 || numericScore > 4) return;

          const localId = `${sectionId}_${questionId}`;

          incidents.push({
            local_id: localId,
            audit_record_id: auditRecordId,
            section_id: parseInt(sectionId),
            question_id: parseInt(questionId),
            issue_description: issue || "",
            score: numericScore,
            corrective_action: action || "",
          });

          files.forEach((file) => {
            formDataToSend.append("files", file);
            formDataToSend.append("file_map", localId);
          });
        });
      });

      formDataToSend.append("incidents", JSON.stringify(incidents));

      await axiosInstance.post("/swa-report", formDataToSend, {
        headers: {
          "Content-Type": "multipart/form-data",
          Authorization: `Bearer ${token}`,
        },
      });

      await updateAuditRecord({ id: auditRecordId, data: { auditStatus: "Completed" }, token });

      alert("✅ Audit completed successfully!");
      navigate("/profile");
    } catch (error) {
      console.error("❌ Error saving audit data:", error);
      alert("Error saving audit. Please try again.");
    }
  };

  if (loading) return <div className={styles.container}>Loading...</div>;

  return (
    <div className={styles.container}>
      <Navbar />
      <div className={styles.breadcrumb}>
        <div>
          <Link to="/dashboard">Home</Link> &gt; <span>Complete Audit</span>
        </div>
        <div className={styles.auditActions}>
          <button className={styles.save} onClick={handleSave}>Save</button>
          <button className={styles.exit} onClick={() => navigate("/profile")}>Exit</button>
        </div>
      </div>
      <SWAForm formData={formData} setFormData={setFormData} />
    </div>
  );
};

export default SafetyWalkAroundContainer;