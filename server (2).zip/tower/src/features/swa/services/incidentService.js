import axiosInstance from "../../../utils/axiosConfig";

const INCIDENTS_URL = "/swa-report"; // baseURL already set

// Create Incident
export const createIncident = async (incidentData) => {
  try {
    const response = await axiosInstance.post(INCIDENTS_URL, incidentData);
    return response.data;
  } catch (error) {
    console.error("❌ Error creating incident:", error.response?.data || error.message);
    throw error;
  }
};

// Fetch Incidents
export const fetchIncidents = async () => {
  try {
    const response = await axiosInstance.get(INCIDENTS_URL);
    return response.data;
  } catch (error) {
    console.error("❌ Error fetching incidents:", error.response?.data || error.message);
    throw error;
  }
};



// ✅ Fetch all audit sections
export const fetchAuditSections = async () => {
  const response = await axiosInstance.get("/audit/sections");
  return response.data;
};

// ✅ Fetch all questions for a section
export const fetchAuditQuestions = async (sectionId) => {
  const response = await axiosInstance.get(`/audit/sections/${sectionId}/questions`);
  return response.data;
};

// You can later add: createAudit, updateAudit, deleteAudit etc.
// ✅ Create multiple incidents
export const createMultipleIncidents = async (incidentList) => {
    try {
      const response = await axiosInstance.post(`${INCIDENTS_URL}`, incidentList);
      return response.data;
    } catch (error) {
      console.error("❌ Error creating multiple incidents:", error.response?.data || error.message);
      throw error;
    }
  };

  export const createIncidentWithFiles = async (incident, files = []) => {
    try {
      const formData = new FormData();
  
      // Add all fields
      Object.entries(incident).forEach(([key, value]) => {
        formData.append(key, value);
      });
  
      // Append multiple files
      files.forEach((file) => {
        formData.append("files", file); // or use the exact field name your backend expects
      });
  
      const response = await axiosInstance.post(`${INCIDENTS_URL}`, formData);
      return response.data;
    } catch (error) {
      console.error("❌ Error creating incident:", error.response?.data || error.message);
      throw error;
    }
  };
  