import SWASections from "./SWASections";
import useFetchAuditSections from "../hooks/usefetchAuditSections";
import { CircularProgress, Typography, Box } from "@mui/material";

const SWAForm = ({ formData, setFormData }) => {
  const { auditSections, error, loading } = useFetchAuditSections();

  const updateFormData = (sectionId, questionId, field, value) => {
    setFormData((prev) => {
      const existingQuestion = prev[sectionId]?.[questionId] || {};
      const updatedField = field === "files"
        ? [...(existingQuestion.files || []), ...value]
        : value;

      return {
        ...prev,
        [sectionId]: {
          ...prev[sectionId],
          [questionId]: {
            ...existingQuestion,
            [field]: updatedField,
          },
        },
      };
    });
  };

  if (loading) return <CircularProgress />;
  if (error) return <Typography color="error">{error}</Typography>;

  return (
    <Box p={3}>
      {auditSections.map((section) => (
        <SWASections
          key={section.id}
          title={section.title}
          sectionId={section.id}
          questions={section.questions}
          updateFormData={updateFormData}
          formData={formData}
        />
      ))}
    </Box>
  );
};

export default SWAForm;
