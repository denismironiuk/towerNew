import React from "react";
import { Box, Grid, Typography, Select, MenuItem, TextField } from "@mui/material";

const SWARows = ({ sectionId, questionId, text, example, updateFormData, savedData }) => {
  return (
    <Grid container spacing={2} alignItems="flex-start" sx={{ mb: 2 }}>
      {/* Question */}
      <Grid item xs={12} md={3}>
        <Typography variant="subtitle1" fontWeight="bold">{text}</Typography>
        <Typography variant="body2" color="text.secondary">{example}</Typography>
      </Grid>

      {/* Score */}
      <Grid item xs={12} md={2}>
        <Select
          fullWidth
          value={savedData?.score || ""}
          onChange={(e) => updateFormData(sectionId, questionId, "score", e.target.value)}
          displayEmpty
        >
          <MenuItem value="">Select</MenuItem>
          {[1, 2, 3, 4].map((score) => (
            <MenuItem key={score} value={score}>{score}</MenuItem>
          ))}
        </Select>
      </Grid>

      {/* Issue */}
      <Grid item xs={12} md={3}>
        <TextField
          label="Issue"
          fullWidth
          value={savedData?.issue || ""}
          onChange={(e) => updateFormData(sectionId, questionId, "issue", e.target.value)}
        />
      </Grid>

      {/* Action */}
      <Grid item xs={12} md={4}>
        <TextField
          label="Corrective Action"
          fullWidth
          value={savedData?.action || ""}
          onChange={(e) => updateFormData(sectionId, questionId, "action", e.target.value)}
        />
      </Grid>
    </Grid>
  );
};

export default SWARows;
