import React from "react";
import { Box, Typography, Divider } from "@mui/material";
import SWARows from "./SWARows";

const SWASections = ({ title, sectionId, questions, updateFormData, formData }) => {
  return (
    <Box sx={{ mb: 5 }}>
      <Typography variant="h6" sx={{ mb: 2 }}>{title}</Typography>
      <Divider sx={{ mb: 2 }} />
      {questions.map((q) => (
        <SWARows
          key={q.id}
          sectionId={sectionId}
          questionId={q.id}
          text={q.text}
          example={q.example}
          updateFormData={updateFormData}
          savedData={formData?.[sectionId]?.[q.id]}
        />
      ))}
    </Box>
  );
};

export default SWASections;
