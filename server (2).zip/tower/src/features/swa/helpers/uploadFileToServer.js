import axiosInstance from "../api/axiosInstance"; // Adjust path based on your structure

export const uploadFileToServer = async (file, token) => {
  const formData = new FormData();
  formData.append("file", file);

  const response = await axiosInstance.post("/upload", formData, {
    headers: {
      "Content-Type": "multipart/form-data",
      Authorization: `Bearer ${token}`,
    },
  });

  return response.data.fileUrl; // Adjust if backend returns something different
};
