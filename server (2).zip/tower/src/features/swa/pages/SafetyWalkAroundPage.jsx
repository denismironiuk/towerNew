import React from 'react'
import SafetyWalkAroundContainer from '../containers/SafetyWalkAroundContainer'

const SafetyWalkAroundPage = () => {
  return (
  <SafetyWalkAroundContainer/>
  )
}

export default SafetyWalkAroundPage