// features/subordinates/services/subordinateService.js
import axiosInstance from "../../../utils/axiosConfig";


export const getSubordinates = () => axiosInstance.get(`/users/workers`);
export const getSubordinateById = (id) => axiosInstance.get(`/subordinates/${id}`);
// ✅ Fetch incidents assigned to a specific manager
export const getSubordinatesIncidents = () => axiosInstance.get(`/swa-report/manager`);



