import React from "react";
import { useQuery } from "@tanstack/react-query";
import ReportsTable from "../components/ReportsTable";
import axiosInstance from "../../../utils/axiosConfig";

const fetchSWAReports = async () => {
    const res = await axiosInstance.get("/swa/reports"); // токен уже прикрепляется
    return res.data; // ✅ данные придут в нужном виде
  };

const SWAReportContainer = () => {
  const { data, isLoading, error } = useQuery({
    queryKey: ["swaReports"],
    queryFn: fetchSWAReports,
  });

  if (isLoading) return <p>Loading...</p>;
  if (error) return <p>Error: {error.message}</p>;

  return <ReportsTable data={data} />;
};

export default SWAReportContainer;
