// containers/SubordinatesContainer.jsx
import React, { useState } from 'react';
import { useFetch } from '../hooks/useFetch';
import { getSubordinates } from '../services/samService';

import SubordinatesList from '../components/SubordinatesList';


const SubordinatesContainer = () => {
  const { data: subordinates, loading, error, refetch } = useFetch(getSubordinates);
 
 
  console.log(error)
console.log(subordinates)



  return (
   
    <SubordinatesList
    employees={subordinates || []}
    loading={loading}
    error={error}
    refetch={refetch}
  
    />
  );
};

export default SubordinatesContainer;
