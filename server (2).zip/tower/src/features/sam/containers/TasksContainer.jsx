import React from 'react'
import { useFetch } from '../hooks/useFetch';
import { getSubordinatesIncidents } from '../services/samService';
import TasksList from '../components/TasksList';
import ReportsTable from '../components/ReportsTable';
import { useQuery } from '@tanstack/react-query';
const TasksContainer = () => {
  const { data = [], isLoading } = useQuery({
    queryKey: ["summaryBySection"],
    queryFn: () => fetchSummary(token),
  });
  return (
    <ReportsTable
    data={data || []}
  

    
    />
  )
}

export default TasksContainer