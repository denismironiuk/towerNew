// hooks/useSubordinateProfile.js
import { useQuery } from "@tanstack/react-query";
import axios from "../../../utils/axiosConfig";

export const useSubordinateProfile = (employee_number) => {
  return useQuery({
    queryKey: ["subordinate", employee_number],
    queryFn: async () => {
      const res = await axios.get(`/users/workers/${employee_number}`);
      return res.data;
    },
    enabled: !!employee_number,
  });
};
