import React from 'react'

const SubordinateDetailPage = () => {
  return (
    <div>SubordinateDetailPage</div>
  )
}

export default SubordinateDetailPage