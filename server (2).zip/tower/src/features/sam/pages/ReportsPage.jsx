import React from 'react'
import Navbar from '../../commons/Navbar'

const ReportsPage = () => {
  return (
    <>
    <Navbar/>
   
    </>
  )
}

export default ReportsPage