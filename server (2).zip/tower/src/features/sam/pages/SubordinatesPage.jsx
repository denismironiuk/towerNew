import React from 'react'
import SubordinatesContainer from '../containers/SubordinatesContainer'
import Navbar from '../../commons/Navbar'

const SubordinatesPage = () => {
  return (
    <>
    <Navbar/>
    <SubordinatesContainer/>
    </>
  )
}

export default SubordinatesPage