import React from 'react'
import Navbar from '../../commons/Navbar'
import TasksContainer from '../containers/TasksContainer'
import ManagerReportTable from '../components/ManagerreportTable'
import ManagerSectionSummary from '../components/ManagerSectionSummary'
import SWAReportContainer from '../containers/SWAReportContainer'
const TasksPage = () => {
  return (
    <>
    <Navbar/>
   {/* <TasksContainer/> */}
   {/* <ManagerReportTable/> */}
   <ManagerSectionSummary/>
   {/* <SWAReportContainer/> */}
    </>
  )
}

export default TasksPage