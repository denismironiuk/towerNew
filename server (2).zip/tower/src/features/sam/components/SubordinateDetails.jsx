// pages/SubordinateProfile.jsx
import React from "react";
import { useParams } from "react-router-dom";
import { useSubordinateProfile } from "../hooks/useSubordinateProfile";
import ProfilePage from "../../profile/components/ProfilePage";


const SubordinateDetails = () => {
  const { subordinateId } = useParams();
  const { data, isLoading, isError } = useSubordinateProfile(subordinateId);

  if (isLoading) return <p>Loading subordinate...</p>;
  if (isError || !data) return <p>Error loading subordinate profile</p>;

  return <ProfilePage profile={{...data,isCurrentUser: false}} />;
};

export default SubordinateDetails;
