// SubordinatesTableGrid.jsx
import React from "react";
import styles from "./SubordinatesTableGrid.module.css";

const SubordinatesTable = ({ employees }) => {
  console.log(employees)
  return (
    <div className={styles.gridContainer}>
      <div className={styles.gridHeader}>
        <span>#</span>
        <span>Badge</span>
        <span>First Name</span>
        <span>Last Name</span>
        <span>Job Title</span>
        <span>Email</span>
      </div>

      {employees?.length ? (
        employees.map((employee, index) => {
          const [lastName, firstName] = employee.name.trim().split(" ");

          return (
            <div key={index} className={styles.gridRow}>
              <span>{index + 1}</span>
              <span>{employee.employee_number}</span>
              <span>{firstName}</span>
              <span>{lastName}</span>
              <span>{employee.position}</span>
              <span>{employee.email}</span>
            </div>
          );
        })
      ) : (
        <div className={styles.noResults}>No employees found</div>
      )}
    </div>
  );
};

export default SubordinatesTable;