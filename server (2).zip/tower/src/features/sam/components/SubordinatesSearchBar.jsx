import React from "react";
import styles from "./SubordinatesSearchBar.module.css";

const SubordinatesSearchBar = ({ searchTerm, setSearchTerm }) => (
  <div className={styles.searchBar}>
    <input
      type="text"
      placeholder="Search by name, badge, job title..."
      value={searchTerm}
      onChange={e => setSearchTerm(e.target.value)}
    />
    <button onClick={() => setSearchTerm("")}>Clear</button>
  </div>
);

export default SubordinatesSearchBar;