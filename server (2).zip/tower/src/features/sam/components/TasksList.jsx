import React, { useState, useEffect } from "react";
import {
  Box,
  Typography,
  TextField,
  Dialog,
  DialogTitle,
  DialogContent,
  Link as MuiLink,
  IconButton
} from "@mui/material";
import { DataGrid } from "@mui/x-data-grid";
import { useNavigate } from "react-router-dom";
import VisibilityIcon from "@mui/icons-material/Visibility";
import { LocalizationProvider, DatePicker } from "@mui/x-date-pickers";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import dayjs from "dayjs";

const BASE_URL = "http://localhost:5000";

const downloadFile = async (url) => {
  try {
    const response = await fetch(url);
    const blob = await response.blob();
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = url.split("/").pop();
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  } catch (error) {
    console.error("Download failed:", error);
  }
};

const getColumns = (onViewFiles) => [
  { field: "id", headerName: "Incident ID", width: 90 },
  { field: "auditor", headerName: "Auditor", flex: 1 },
  {
    field: "reported_at",
    headerName: "Audit Date",
    width: 200,
    type: "dateTime",
    valueGetter: (params) => {
      const dateValue = new Date(params);
      return isNaN(dateValue.getTime()) ? null : dateValue;
    },
    valueFormatter: (params) => {
      if (!params) return "N/A";
      return new Intl.DateTimeFormat("en-US", {
        year: "numeric",
        month: "short",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit"
      }).format(new Date(params));
    }
  },
  { field: "description", headerName: "Description", flex: 1 },
  { field: "corrective_action", headerName: "Corrective Actions", flex: 1 },
  { field: "status", headerName: "Status", width: 150 },
  {
    field: "files",
    headerName: "Files",
    width: 100,
    sortable: false,
    renderCell: (params) => {
      const files = (params.row.files || []).map((f) => {
        const encoded = f
          .split("/")
          .map(part => encodeURIComponent(part)) // encodes spaces, special characters
          .join("/");
      
        return f.startsWith("http") ? f : `${BASE_URL}${encoded}`;
      });
      if (!files.length) return "—";
      return (
        <IconButton
          color="primary"
          onClick={(e) => {
            e.stopPropagation();
            onViewFiles(files);
          }}
          title={`View ${files.length} file${files.length > 1 ? "s" : ""}`}
        >
          <VisibilityIcon />
        </IconButton>
      );
    }
  }
];

const TasksList = ({ incidents, loading, error }) => {
  const [searchTerm, setSearchTerm] = useState("");
  const [filteredIncidents, setFilteredIncidents] = useState([]);
  const [statusFilter, setStatusFilter] = useState("");
  const [auditorFilter, setAuditorFilter] = useState("");
  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selectedFiles, setSelectedFiles] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    setFilteredIncidents(incidents);
  }, [incidents]);

  useEffect(() => {
    const timeout = setTimeout(() => {
      let filtered = incidents;

      if (searchTerm.trim()) {
        filtered = filtered.filter((incident) =>
          Object.values(incident).some((field) =>
            field?.toString().toLowerCase().includes(searchTerm.toLowerCase())
          )
        );
      }

      if (statusFilter) {
        filtered = filtered.filter((incident) => incident.status === statusFilter);
      }

      if (auditorFilter) {
        filtered = filtered.filter((incident) => incident.auditor === auditorFilter);
      }

      if (startDate) {
        filtered = filtered.filter((incident) =>
          dayjs(incident.reported_at).isAfter(dayjs(startDate))
        );
      }

      if (endDate) {
        filtered = filtered.filter((incident) =>
          dayjs(incident.reported_at).isBefore(dayjs(endDate))
        );
      }

      setFilteredIncidents(filtered);
    }, 300);

    return () => clearTimeout(timeout);
  }, [searchTerm, statusFilter, auditorFilter, startDate, endDate, incidents]);

  const handleViewFiles = (files) => {
    setSelectedFiles(files);
    setDialogOpen(true);
  };

  const handleDownloadAll = async () => {
    for (const fileUrl of selectedFiles) {
      await downloadFile(fileUrl);
    }
  };

  if (loading) return <Typography>Loading incidents...</Typography>;
  if (error) return <Typography color="error">Error: {error}</Typography>;

  return (
    <Box p={3}>
      <Typography variant="h4" gutterBottom>
        Incident Reports
      </Typography>

      <LocalizationProvider dateAdapter={AdapterDayjs}>
        <Box display="flex" gap={2} sx={{ mb: 2, flexWrap: "wrap" }}>
          <TextField
            label="Search"
            variant="outlined"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            sx={{ flex: 1, minWidth: "250px" }}
          />
          <DatePicker
            label="From Date"
            value={startDate}
            onChange={(newValue) => setStartDate(newValue)}
          />
          <DatePicker
            label="To Date"
            value={endDate}
            onChange={(newValue) => setEndDate(newValue)}
          />
        </Box>
      </LocalizationProvider>

      <Box height={400}>
        <DataGrid
          rows={filteredIncidents || []}
          columns={getColumns(handleViewFiles)}
          pageSize={5}
          loading={loading}
          getRowId={(row) => row.id}
          sx={{
            ".MuiDataGrid-cell:focus": { outline: "none" }
          }}
        />
      </Box>

      {/* Modal: File Preview and Download */}
      <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)} maxWidth="md" fullWidth>
        <DialogTitle>Attached Files</DialogTitle>
        <DialogContent>
          <Box display="flex" justifyContent="flex-end" mb={2}>
            <Typography
              variant="button"
              sx={{ cursor: "pointer", color: "primary.main", fontWeight: "bold" }}
              onClick={handleDownloadAll}
            >
              ⬇️ Download All
            </Typography>
          </Box>

          <Box display="flex" flexWrap="wrap" gap={3}>
            {selectedFiles.map((file, index) => {
              const isImage = /\.(jpg|jpeg|png|gif|webp)$/i.test(file);
              const fileName = file.split("/").pop();

              return (
                <Box key={index} textAlign="center">
                  {isImage ? (
                    <img
                      src={file}
                      alt={fileName}
                      style={{
                        width: 150,
                        height: 150,
                        objectFit: "cover",
                        borderRadius: 8,
                        marginBottom: 8
                      }}
                    />
                  ) : (
                    <Typography variant="body2" mb={1}>
                      {fileName}
                    </Typography>
                  )}
                  <Box>
                  <MuiLink href={file} target="_blank" rel="noopener noreferrer">
  🔍 Preview
</MuiLink>
                    |{" "}
                    <Typography
                      component="span"
                      variant="body2"
                      sx={{ cursor: "pointer", color: "primary.main", fontWeight: 500 }}
                      onClick={() => downloadFile(file)}
                    >
                      ⬇️ Download
                    </Typography>
                  </Box>
                </Box>
              );
            })}
          </Box>
        </DialogContent>
      </Dialog>
    </Box>
  );
};

export default TasksList;
