// ManagerReportTable.jsx — description column takes full space
import React, { useContext, useMemo } from "react";
import {
  Box,
  CircularProgress,
  Typography,
  Chip,
  List,
  ListItem,
  ListItemText
} from "@mui/material";
import { DataGrid } from "@mui/x-data-grid";
import AuthContext from "../../../context/AuthContext";
import { useQuery } from "@tanstack/react-query";
import axiosInstance from "../../../utils/axiosConfig";

const fetchGroupedReports = async (token) => {
  const { data } = await axiosInstance.get("/swa-report/manager/grouped-by-section", {
    headers: { Authorization: `Bearer ${token}` },
  });
  return data;
};

const groupByAuditIdAndStatus = (data) => {
  const groupedMap = new Map();

  data.forEach((section) => {
    section.reports.forEach((report) => {
      const { auditId, createdAt, createdBy, manager, department, questions } = report;

      questions.forEach((q) => {
        const status = q.status === "Open" ? "Open" : "Closed";
        const key = `${auditId}-${status}`;

        if (!groupedMap.has(key)) {
          groupedMap.set(key, {
            id: key,
            auditId,
            auditor: createdBy?.name || "",
            manager: manager || "",
            department: department || "",
            auditDate: new Date(createdAt).toLocaleDateString(),
            issues: [],
            actions: [],
            files: false,
            status,
          });
        }

        const entry = groupedMap.get(key);
        if (q.description) entry.issues.push(q.description);
        if (q.corrective_action) entry.actions.push(q.corrective_action);
        if (q.supporting_media) entry.files = true;
      });
    });
  });

  return Array.from(groupedMap.values());
};

const ManagerReportTable = () => {
  const { token } = useContext(AuthContext);

  const { data, isLoading, error } = useQuery({
    queryKey: ["sectionGroupedReports"],
    queryFn: () => fetchGroupedReports(token),
  });

  const groupedRows = useMemo(() => {
    if (!data) return [];
    return groupByAuditIdAndStatus(data);
  }, [data]);

  const columns = [
    { field: "auditId", headerName: "Task", width: 100 },
    { field: "auditor", headerName: "Auditor", width: 150 },
    { field: "manager", headerName: "Manager", width: 150 },
    { field: "department", headerName: "Department", width: 120 },
    { field: "auditDate", headerName: "Audit Date", width: 120 },
    {
      field: "issues",
      headerName: "Description",
      flex: 1,
      minWidth: 250,
      renderCell: (params) => (
        <List dense sx={{ paddingY: 0 }}>
          {params.value.map((issue, index) => (
            <ListItem key={index} disablePadding>
              <ListItemText primary={issue} primaryTypographyProps={{ fontSize: "0.85rem" }} />
            </ListItem>
          ))}
        </List>
      ),
    },
    {
      field: "actions",
      headerName: "Corrective Action",
      width: 250,
      renderCell: (params) => (
        <List dense sx={{ paddingY: 0 }}>
          {params.value.map((act, index) => (
            <ListItem key={index} disablePadding>
              <ListItemText primary={act} primaryTypographyProps={{ fontSize: "0.85rem" }} />
            </ListItem>
          ))}
        </List>
      ),
    },
    {
      field: "files",
      headerName: "Files",
      width: 80,
      renderCell: (params) => (params.value ? "📎" : "—"),
    },
    {
      field: "status",
      headerName: "Status",
      width: 100,
      renderCell: (params) => (
        <Chip
          label={params.value}
          color={params.value === "Open" ? "warning" : "success"}
          size="small"
        />
      ),
    },
  ];

  if (isLoading) return <Box textAlign="center" mt={4}><CircularProgress /></Box>;
  if (error) return <Typography color="error" textAlign="center" mt={4}>Error: {error.message || error}</Typography>;

  return (
    <Box sx={{ width: "100%", mt: 2 }}>
      <Typography variant="h5" gutterBottom>
        SWA Reports Summary
      </Typography>
      <DataGrid
        rows={groupedRows}
        columns={columns}
        autoHeight
        disableRowSelectionOnClick
        pageSizeOptions={[10, 25, 50]}
        initialState={{ pagination: { paginationModel: { pageSize: 10 } } }}
      />
    </Box>
  );
};

export default ManagerReportTable;