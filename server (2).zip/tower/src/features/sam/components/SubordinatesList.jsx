import React, { useState, useEffect } from "react";
import SubordinatesSearchBar from "./SubordinatesSearchBar";

import styles from "./SubordinatesList.module.css";
import DataGrid from "../../reusable/DataGrid";
import { useNavigate } from "react-router-dom";

const generateColumns = (employees) => {
  if (!employees.length) return [];
  return Object.keys(employees[0]).map((key) => ({ key, label: key.replace(/_/g, " ").toUpperCase() }));
};

const SubordinatesList = ({ employees, loading, error }) => {
  const [searchTerm, setSearchTerm] = useState("");
  const [filteredEmployees, setFilteredEmployees] = useState(employees);
  const [columns, setColumns] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    if (employees.length) {
      setColumns(generateColumns(employees));
    }
  }, [employees]);

  useEffect(() => {
    const timeout = setTimeout(() => {
      if (searchTerm.trim() === "") {
        setFilteredEmployees(employees);
      } else {
        setFilteredEmployees(
          employees.filter((emp) =>
            Object.values(emp).some((field) =>
              field?.toString().toLowerCase().includes(searchTerm.toLowerCase())
            )
          )
        );
      }
    }, 300); // Add debounce to reduce frequent re-renders

    return () => clearTimeout(timeout);
  }, [searchTerm, employees]);

  const handleRowClick = (employee) => {
    navigate(`/profile/${employee.employee_number}`); // Navigate to user profile
  };

  if (loading) return <div>Loading subordinates...</div>;
  if (error) return <div>Error: {error}</div>;

  return (
    <div className={styles.container}>
      <SubordinatesSearchBar searchTerm={searchTerm} setSearchTerm={setSearchTerm} />
      <DataGrid data={filteredEmployees} columns={columns} layout="grid" onRowClick={handleRowClick}/>
    </div>
  );
};

export default SubordinatesList;
