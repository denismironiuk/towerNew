// ManagerSectionSummary.jsx — Apply Changes Button to update overall status
import React, { useContext, useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import AuthContext from '../../../context/AuthContext';
import axiosInstance from '../../../utils/axiosConfig';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Chip,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  CircularProgress,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Grid,
  Divider,
} from '@mui/material';
import { DataGrid } from '@mui/x-data-grid';
import { KeyboardArrowDown } from '@mui/icons-material';

const fetchSummary = async (token) => {
  const { data } = await axiosInstance.get('/swa-report/summary-by-section', {
    headers: { Authorization: `Bearer ${token}` },
  });
  return data;
};

const fetchDetails = async ({ auditId, sectionId, token }) => {
  const { data } = await axiosInstance.get(
    `/swa-report/audit/${auditId}/section/${sectionId}`,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );
  return data;
};

const ManagerSectionSummary = () => {
  const { token } = useContext(AuthContext);
  const queryClient = useQueryClient();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [dialogDetails, setDialogDetails] = useState([]);
  const [dialogTitle, setDialogTitle] = useState('');
  const [dialogContext, setDialogContext] = useState({
    auditId: null,
    sectionId: null,
  });

  const mutation = useMutation({
    mutationFn: ({ id, status }) =>
      axiosInstance.patch(
        `/swa-report/${id}/status`,
        { status },
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      ),
    onSuccess: () => {
      queryClient.invalidateQueries(['summaryBySection']);
    },
  });

  const { data = [], isLoading } = useQuery({
    queryKey: ['summaryBySection'],
    queryFn: () => fetchSummary(token),
  });

  const handleOpenDialog = async (row) => {
    const response = await fetchDetails({
      auditId: row.audit_id,
      sectionId: row.section_id,
      token,
    });
    setDialogDetails(response);
    setDialogContext({ auditId: row.audit_id, sectionId: row.section_id });
    setDialogTitle(`Audit #${row.audit_id} — ${row.section_title}`);
    setDialogOpen(true);
  };

  const handleStatusChange = (id, newStatus) => {
    setDialogDetails((prev) =>
      prev.map((item) =>
        item.id === id ? { ...item, status: newStatus } : item
      )
    );
    mutation.mutate({ id, status: newStatus });
  };

  const handleApplyChanges = async () => {
    const allClosed = dialogDetails.every((q) => q.status === 'Closed');
    if (allClosed) {
      try {
        await axiosInstance.patch(
          `/swa-report/section/${dialogContext.auditId}/${dialogContext.sectionId}/close`,
          {},
          { headers: { Authorization: `Bearer ${token}` } }
        );
        queryClient.invalidateQueries(['summaryBySection']);
      } catch (err) {
        console.error('Failed to close section:', err);
      }
    }
    setDialogOpen(false);
  };

  const columns = [
    { field: 'audit_id', headerName: 'Audit ID', width: 90 },
    { field: 'section_id', headerName: 'Section ID', width: 100 },
    { field: 'section_title', headerName: 'Section', width: 200 },
    { field: 'user_name', headerName: 'User', width: 140 },
    { field: 'total_questions', headerName: 'Total', width: 90 },
    { field: 'open_issues', headerName: 'Open', width: 80 },
    { field: 'closed_issues', headerName: 'Closed', width: 90 },
    {
      field: 'last_reported_at',
      headerName: 'Reported At',
      width: 150,
      valueGetter: (params) => new Date(params).toLocaleString(),
    },
    {
      field: 'overall_status',
      headerName: 'Status',
      width: 100,
      renderCell: (params) => (
        <Chip
          label={params.value}
          color={params.value === 'Open' ? 'warning' : 'success'}
          size="small"
        />
      ),
    },
    {
      field: 'expand',
      headerName: '',
      width: 70,
      sortable: false,
      renderCell: (params) => (
        <IconButton size="small" onClick={() => handleOpenDialog(params.row)}>
          <KeyboardArrowDown />
        </IconButton>
      ),
    },
  ];

  return (
    <Card sx={{ p: 3, borderRadius: 3, boxShadow: 2 }}>
      <CardContent>
        <Typography variant="h5" gutterBottom>
          SWA Section Summary
        </Typography>

        {isLoading ? (
          <CircularProgress />
        ) : (
          <Box>
            <DataGrid
              rows={data.map((d, i) => ({ ...d, id: i }))}
              columns={columns}
              autoHeight
              disableRowSelectionOnClick
              hideFooterSelectedRowCount
              initialState={{
                pagination: { paginationModel: { pageSize: 10 } },
              }}
              pageSizeOptions={[10, 25, 50]}
              sx={{
                border: 'none', // Remove outer border
                '& .MuiDataGrid-cell': {
                  borderBottom: 'none', // Remove cell borders
                },
                '& .MuiDataGrid-columnHeaders': {
                  borderBottom: 'none', // Remove header bottom border
                },
                '& .MuiDataGrid-virtualScroller': {
                  marginTop: 0,
                },
                '& .MuiDataGrid-footerContainer': {
                  borderTop: 'none', // Remove footer border
                },
              }}
            />
          </Box>
        )}

        <Dialog
          open={dialogOpen}
          onClose={() => setDialogOpen(false)}
          maxWidth="lg"
          fullWidth
        >
          <DialogTitle>{dialogTitle}</DialogTitle>
          <DialogContent dividers>
            <Box>
              <Grid container spacing={2} sx={{ fontWeight: 600, mb: 1 }}>
                <Grid item xs={3}>
                  Question
                </Grid>
                <Grid item xs={3}>
                  Description
                </Grid>
                <Grid item xs={3}>
                  Corrective Action
                </Grid>
                <Grid item xs={3}>
                  Status
                </Grid>
              </Grid>
              <Divider sx={{ mb: 2 }} />
              {dialogDetails.map((q, i) => (
                <Grid
                  container
                  spacing={2}
                  key={i}
                  sx={{
                    mb: 1,
                    border: '1px solid #eee',
                    borderRadius: 2,
                    p: 2,
                    background: '#fafafa',
                  }}
                >
                  <Grid item xs={3}>
                    <Typography variant="body2">{q.question_text}</Typography>
                  </Grid>
                  <Grid item xs={3}>
                    <Typography
                      sx={{
                        maxWidth: '20ch',
                        wordWrap: 'break-word',
                      }}
                      variant="body2"
                    >
                      {q.issue_description || '—'}
                    </Typography>
                  </Grid>
                  <Grid item xs={3}>
                    <Typography
                      sx={{
                        maxWidth: '20ch',
                        wordWrap: 'break-word',
                      }}
                      variant="body2"
                    >
                      {q.corrective_action || '—'}
                    </Typography>
                  </Grid>
                  <Grid item xs={3}>
                    <FormControl size="small" fullWidth>
                      <InputLabel>Status</InputLabel>
                      <Select
                        value={q.status}
                        label="Status"
                        onChange={(e) =>
                          handleStatusChange(q.id, e.target.value)
                        }
                      >
                        <MenuItem value="Open">Open</MenuItem>
                        <MenuItem value="Closed">Closed</MenuItem>
                      </Select>
                    </FormControl>
                  </Grid>
                </Grid>
              ))}
            </Box>
          </DialogContent>
          <DialogActions>
            {/* <Button onClick={handleApplyChanges} variant="contained" color="primary">
              Apply Changes
            </Button> */}
            <Button onClick={() => setDialogOpen(false)}>Close</Button>
          </DialogActions>
        </Dialog>
      </CardContent>
    </Card>
  );
};

export default ManagerSectionSummary;
