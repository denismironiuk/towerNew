import React, { useState, useMemo } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Typography,
  TextField,
  TablePagination,
  TableSortLabel,
  CircularProgress,
} from "@mui/material";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import axiosInstance from "../../../utils/axiosConfig";


const updateSWAReportStatus = async (auditId, newStatus) => {
  const res = await axiosInstance.put(`/swa/reports/${auditId}/status`, {
    newStatus,
  });
  return res.data;
};


const GroupedReportsTable = ({ data = [] }) => {
  

  const [searchTerm, setSearchTerm] = useState("");
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const [sortConfig, setSortConfig] = useState({ key: "rawDate", direction: "desc" });
  const [statusMap, setStatusMap] = useState({});

  // ✅ React Query mutation for status update
  const { mutate, isLoading: isUpdating } = useMutation({
    mutationFn: ({ auditId, newStatus }) => updateSWAReportStatus(auditId, newStatus),
    onSuccess: (_, { auditKey, newStatus }) => {
      setStatusMap((prev) => ({ ...prev, [auditKey]: newStatus }));
      // Optionally refetch the entire SWA reports list:
      // queryClient.invalidateQueries(["swaReports"]);
    },
    onError: () => {
      alert("❌ Failed to update status on server.");
    },
  });

  const handleSort = (key) => {
    setSortConfig((prev) => ({
      key,
      direction: prev.key === key && prev.direction === "asc" ? "desc" : "asc",
    }));
  };

  const splitIntoChunks = (text, length = 30) => {
    if (!text || text.trim() === "") return ["Not provided"];
    return text.match(new RegExp(`.{1,${length}}`, "g")) || [];
  };

  const handleToggleStatus = (auditKey, currentStatus) => {
    const newStatus = currentStatus === "Closed" ? "Open" : "Closed";
    const auditId = auditKey.split("_")[0];

    if (currentStatus === "Closed") {
      const confirmed = window.confirm("Are you sure you want to reopen this task?");
      if (!confirmed) return;
    }

    mutate({ auditId, newStatus, auditKey });
  };

  const filteredRows = useMemo(() => {
    const grouped = data.reduce((acc, item) => {
      const key = `${item.audit_id}_${item.overall_status}`;
      const matchesSearch =
        item.audit_id.toString().includes(searchTerm.toLowerCase()) ||
        item.user_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.issue_description.toLowerCase().includes(searchTerm.toLowerCase());

      if (!matchesSearch) return acc;

      if (!acc[key]) {
        acc[key] = {
          audit_id: `000${item.audit_id}`,
          rawAuditId: item.audit_id,
          auditor: item.user_name,
          audit_date: new Date(item.last_reported_at).toLocaleDateString(),
          rawDate: item.last_reported_at,
          status: item.overall_status,
          issues: [],
        };
      }

      acc[key].issues.push({
        description: item.issue_description,
        corrective_action: item.corrective_action,
      });

      return acc;
    }, {});

    return Object.values(grouped).filter((group) => group.issues.length > 0);
  }, [data, searchTerm]);

  const sortedRows = useMemo(() => {
    return [...filteredRows].sort((a, b) => {
      const aVal = a[sortConfig.key]?.toString().toLowerCase();
      const bVal = b[sortConfig.key]?.toString().toLowerCase();
      return sortConfig.direction === "asc"
        ? aVal.localeCompare(bVal)
        : bVal.localeCompare(aVal);
    });
  }, [filteredRows, sortConfig]);

  const paginatedRows = useMemo(() => {
    return sortedRows.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage);
  }, [sortedRows, page, rowsPerPage]);

  return (
    <Paper sx={{ borderRadius: 2, p: 2 }}>
      <Typography variant="h6" sx={{ mb: 2 }}>
        SWA Task Overview
      </Typography>

      <TextField
        label="Search"
        variant="outlined"
        size="small"
        value={searchTerm}
        onChange={(e) => {
          setSearchTerm(e.target.value);
          setPage(0);
        }}
        sx={{ mb: 2 }}
      />

      <TableContainer>
        <Table size="small">
          <TableHead sx={{ backgroundColor: "#e0f7fa" }}>
            <TableRow>
              {["audit_id", "auditor", "rawDate", "", "", "status"].map((key, i) => (
                <TableCell key={i}>
                  {key && key !== "" ? (
                    <TableSortLabel
                      active={sortConfig.key === key}
                      direction={sortConfig.direction}
                      onClick={() => handleSort(key)}
                    >
                      {{
                        audit_id: "Task",
                        auditor: "Auditor",
                        rawDate: "Audit Date",
                        status: "Status",
                      }[key]}
                    </TableSortLabel>
                  ) : (
                    i === 3 ? "Description" : "Corrective Actions"
                  )}
                </TableCell>
              ))}
            </TableRow>
          </TableHead>

          <TableBody>
            {paginatedRows.map((group) => {
              const auditKey = `${group.rawAuditId}_${group.status}`;
              const currentStatus = statusMap[auditKey] || group.status;

              return group.issues.map((issue, idx) => (
                <TableRow key={`${auditKey}_${idx}`}>
                  {idx === 0 && (
                    <>
                      <TableCell rowSpan={group.issues.length} sx={{ verticalAlign: "top" }}>
                        {group.audit_id}
                      </TableCell>
                      <TableCell rowSpan={group.issues.length} sx={{ verticalAlign: "top" }}>
                        {group.auditor}
                      </TableCell>
                      <TableCell rowSpan={group.issues.length} sx={{ verticalAlign: "top" }}>
                        {group.audit_date}
                      </TableCell>
                    </>
                  )}

                  <TableCell sx={{ whiteSpace: "pre-wrap" }}>
                    {splitIntoChunks(issue.description).map((chunk, i) => (
                      <div key={i}>{chunk}</div>
                    ))}
                  </TableCell>

                  <TableCell sx={{ whiteSpace: "pre-wrap" }}>
                    {splitIntoChunks(issue.corrective_action).map((chunk, i) => (
                      <div key={i}>{chunk}</div>
                    ))}
                  </TableCell>

                  {idx === 0 && (
                    <TableCell
                      rowSpan={group.issues.length}
                      sx={{
                        color: currentStatus === "Open" ? "green" : "red",
                        fontWeight: "bold",
                        textDecoration: "underline",
                        cursor: isUpdating ? "not-allowed" : "pointer",
                        verticalAlign: "center",
                        position: "relative",
                      }}
                      onClick={() =>
                        !isUpdating && handleToggleStatus(auditKey, currentStatus)
                      }
                    >
                      {isUpdating ? (
                        <CircularProgress size={16} color="inherit" />
                      ) : (
                        currentStatus
                      )}
                    </TableCell>
                  )}
                </TableRow>
              ));
            })}
          </TableBody>
        </Table>
      </TableContainer>

      <TablePagination
        component="div"
        count={sortedRows.length}
        page={page}
        onPageChange={(_, newPage) => setPage(newPage)}
        rowsPerPage={rowsPerPage}
        onRowsPerPageChange={(e) => {
          setRowsPerPage(parseInt(e.target.value, 10));
          setPage(0);
        }}
        rowsPerPageOptions={[5, 10, 25, 50, 100]}
      />
    </Paper>
  );
};

export default GroupedReportsTable;
