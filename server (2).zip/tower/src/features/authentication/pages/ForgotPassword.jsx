import React, { useState } from "react";
import styles from "../components/Authentication.module.css";
import { useForgotPassword } from "../hooks/useforgotPassword";

const ForgotPassword = () => {
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  const { mutate, isLoading } = useForgotPassword();

  const handleSubmit = (e) => {
    e.preventDefault();
    setMessage("");
    setError("");

    mutate(
      { email },
      {
        onSuccess: (res) => {
            setMessage(res.message || "Reset link sent to your email.");
            if (res.redirectUrl) {
              window.location.href = res.redirectUrl; // ✅ immediate redirect
            }
          },
        onError: (err) => {
          setError(err.response?.data?.message || "Failed to send reset link.");
        },
      }
    );
  };

  return (
    <div className={styles.container}>
      <h2 className={styles.title}>Forgot Password</h2>
      <form onSubmit={handleSubmit} className={styles.form}>
        {message && <p className={styles.success}>{message}</p>}
        {error && <p className={styles.error}>{error}</p>}

        <div className={styles.inputContainer}>
          <label htmlFor="email">Email Address:</label>
          <input
            id="email"
            type="email"
            placeholder="Enter your email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>

        <button type="submit" className={styles.signInButton} disabled={isLoading}>
          {isLoading ? "Sending..." : "Send Reset Link"}
        </button>
      </form>
    </div>
  );
};

export default ForgotPassword;
