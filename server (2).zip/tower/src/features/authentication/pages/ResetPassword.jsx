import React, { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useResetPassword } from "../hooks/useResetPassword";
import styles from "../components/Authentication.module.css";

const ResetPassword = () => {
  const { token } = useParams();
  const navigate = useNavigate();
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const { mutate, isLoading } = useResetPassword();

  const handleSubmit = (e) => {
    e.preventDefault();
    setError("");

    if (password !== confirm) {
      return setError("Passwords do not match.");
    }

    mutate(
      { token, password },
      {
        onSuccess: (res) => {
          setSuccess(res.message || "Password successfully reset.");
          setTimeout(() => navigate("/login"), 2000);
        },
        onError: (err) => {
          setError(err.response?.data?.message || "Reset failed.");
        },
      }
    );
  };

  return (
    <div className={styles.container}>
      <h2 className={styles.title}>Reset Password</h2>
      <form onSubmit={handleSubmit} className={styles.form}>
        {error && <p className={styles.error}>{error}</p>}
        {success && <p className={styles.success}>{success}</p>}

        <div className={styles.inputContainer}>
          <label htmlFor="password">New Password:</label>
          <input
            id="password"
            type="password"
            placeholder="Enter new password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>

        <div className={styles.inputContainer}>
          <label htmlFor="confirm">Confirm Password:</label>
          <input
            id="confirm"
            type="password"
            placeholder="Confirm new password"
            value={confirm}
            onChange={(e) => setConfirm(e.target.value)}
            required
          />
        </div>

        <button
          type="submit"
          className={styles.signInButton}
          disabled={isLoading}
        >
          {isLoading ? "Resetting..." : "Reset Password"}
        </button>
      </form>
    </div>
  );
};

export default ResetPassword;
