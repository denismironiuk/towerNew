import React, { useState, useContext } from "react";
import { AuthContext } from "../../../context/AuthContext";
import { useNavigate } from "react-router-dom";
import AuthForm from "../../components/auth/AuthForm";

const LoginPage = () => {
    const { login } = useContext(AuthContext);
    const navigate = useNavigate();
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [error, setError] = useState(null);

    const handleLogin = async (e) => {
        e.preventDefault();
        setError(null);
        try {
            await login(email, password);
            navigate("/dashboard");
        } catch (err) {
            setError("Login failed. Please check credentials.");
        }
    };

    return (
        <div>
            <h2>Login</h2>
            <AuthForm
                email={email}
                setEmail={setEmail}
                password={password}
                setPassword={setPassword}
                handleSubmit={handleLogin}
                error={error}
            />
        </div>
    );
};

export default LoginPage;
