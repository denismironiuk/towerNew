// src/services/authService.js
import axiosInstance from "../../../utils/axiosConfig"; // uses baseURL etc.

export const loginUser = async ({ employee_number, password }) => {
  const res = await axiosInstance.post("/auth/login", { employee_number, password });
  return res.data;
};
export const sendForgotPassword = async ({ email }) => {
    const res = await axiosInstance.post("/auth/forgot-password", { email });
    return res.data;
  };
  export const resetPassword = async ({ token, password }) => {
    const res = await axiosInstance.post(`/auth/reset-password/${token}`, {
      password,
    });
    return res.data;
  };
  