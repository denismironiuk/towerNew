import React, { useState, useContext } from "react";
import { useNavigate, Link } from "react-router-dom";
import { useLogin } from "../hooks/useLogin";
import AuthContext from "../../../context/AuthContext";
import styles from "./Authentication.module.css";
import Tower from "../../../assets/Tower_Semiconductor.svg.png";

const Authentication = () => {
  const [userName, setUserName] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();
  const { login } = useContext(AuthContext);
  const { mutateAsync: loginMutate, isLoading } = useLogin();

  const handleLogin = async (e) => {
    e.preventDefault();
    setError("");

    try {
      const data = await loginMutate({
        employee_number: userName,
        password,
      });

      const { access_token, refresh_token, user } = data;

      login(access_token, refresh_token, user);

      navigate(user.position === "admin" ? "/dashboard" : "/profile");
    } catch (err) {
      setError(
        err?.response?.data?.message || err.message || "Login failed. Please try again."
      );
    } finally {
      setPassword("");
    }
  };

  return (
    <div className={styles.container}>
      <img src={Tower} alt="Tower Semiconductor" className={styles.logo} />
      <h2 className={styles.title}>Sign in to your account</h2>

      <form onSubmit={handleLogin} className={styles.form}>
        {error && <p className={styles.error}>{error}</p>}

        <div className={styles.inputContainer}>
          <label htmlFor="username">User Name:</label>
          <input
            type="text"
            id="username"
            placeholder="Enter your username"
            value={userName}
            onChange={(e) => setUserName(e.target.value)}
            required
          />
        </div>

        <div className={styles.inputContainer}>
          <label htmlFor="password">Password:</label>
          <input
            type="password"
            id="password"
            placeholder="Enter your password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            autoComplete="current-password"
          />
        </div>

        

        <button type="submit" className={styles.signInButton} disabled={isLoading}>
          {isLoading ? "Signing in..." : "Sign In"}
        </button>

        {/* ✅ Forgot Password Link */}
        <div className={styles.forgotPassword}>
          <Link to="/forgot-password">Forgot password?</Link>
        </div>
      </form>
    </div>
  );
};

export default Authentication;
