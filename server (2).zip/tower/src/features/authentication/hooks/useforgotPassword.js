import { useMutation } from "@tanstack/react-query";
import { sendForgotPassword } from "../services/authService";

export const useForgotPassword = () => {
  return useMutation({
    mutationFn: sendForgotPassword,
  });
};
