import React from "react";
import styles from "./DataGrid.module.css";

const DataGrid = ({ data, columns, layout = "grid", onRowClick }) => {
    return (
      <div className={layout === "grid" ? styles.gridContainer : styles.tableContainer}>
        {/* Render Column Headers */}
        <div className={styles.gridHeader} style={{ gridTemplateColumns: `repeat(${columns.length}, 1fr)` }}>
          {columns.map((col) => (
            <span key={col.key}>{col.label}</span>
          ))}
        </div>
  
        {/* Render Data Rows */}
        {data?.length ? (
          data.map((item, index) => (
            <div
              key={index}
              className={styles.gridRow}
              style={{ gridTemplateColumns: `repeat(${columns.length}, 1fr)` }}
              onClick={() => onRowClick && onRowClick(item)}
            >
              {columns.map((col) => (
                <span key={col.key}>{col.render ? col.render(item[col.key], item) : item[col.key]}</span>
              ))}
            </div>
          ))
        ) : (
          <div className={styles.noResults}>No records found</div>
        )}
      </div>
    );
  };
  

export default DataGrid;
