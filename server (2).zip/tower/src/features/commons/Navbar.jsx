import React, { useContext } from "react";

import styles from "./Navbar.module.css";
import logo from "../../assets/Tower_Semiconductor.svg.png";
import userlogo from "../../assets/default.webp";
import AuthContext from "../../context/AuthContext";
import { Link } from "react-router-dom";

const Navbar = () => {
 const{user,logout}= useContext(AuthContext)

  return (
    <nav className={styles.navbar}>
      <img src={logo} alt="Company Logo" className={styles.logo} />
      
      <div className={styles.user}>
      <Link to={user?.position === 'admin' ? '/dashboard' : '/profile'}>
            {user?.position === 'admin' ? 'Dashboard' : 'Profile'}
          </Link>
        
        <span>{user?.name || "Guest User"}</span>
        <img src={userlogo} alt="User" className={styles.userIcon} onClick={()=>logout()} />
      </div>
    </nav>
  );
};

export default Navbar;
