// src/store/eventSlice.js
import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  items: [],
};

const eventSlice = createSlice({
  name: 'events',
  initialState,
  reducers: {
    setEvents: (state, action) => {
      state.items = action.payload;
    },
    addEvent: (state, action) => {
      state.items.push(action.payload);
    },
    updateEvent: (state, action) => {
      const index = state.items.findIndex(e => e.id === action.payload.id);
      if (index !== -1) state.items[index] = action.payload;
    },
    deleteEvent: (state, action) => {
      state.items = state.items.filter(e => e.id !== action.payload);
    },
  },
});

export const { setEvents, addEvent, updateEvent, deleteEvent } = eventSlice.actions;
export default eventSlice.reducer;
