// src/api/events.js
import axiosInstance from "../../../../utils/axiosConfig";

export const fetchEvents = () => axiosInstance.get('/events');

export const createEvent = (event) => axiosInstance.post('/events', event);

export const updateEvent = (id, updates) =>
  axiosInstance.put(`/events/${id}`, updates);

export const deleteEvent = (id) =>
  axiosInstance.delete(`/events/${id}`);
