import axiosInstance from "../../../../utils/axiosConfig";

const API_URL = '/annualplan'; // Adjust if needed

export const getAllPlans = () => axiosInstance.get(API_URL);

export const getPlanById = (id) => axiosInstance.get(`${API_URL}/${id}`);

export const createPlan = (data) => axiosInstance.post(API_URL, data);

export const updatePlan = (id, data) => axiosInstance.put(`${API_URL}/${id}`, data);

export const deletePlan = (id) => axiosInstance.delete(`${API_URL}/${id}`);
