import React, { useEffect, useRef, useState } from "react";
import FullCalendar from "@fullcalendar/react";
import timeGridPlugin from "@fullcalendar/timegrid";
import dayGridPlugin from "@fullcalendar/daygrid";
import interactionPlugin from "@fullcalendar/interaction";
import { Box, ToggleButton, ToggleButtonGroup, Typography } from "@mui/material";
import dayjs from "dayjs";

export default function AnnualPlanCalendar() {
  const [view, setView] = useState("dayGridMonth");
  const calendarRef = useRef(null);
  const [events, setEvents] = useState([]);

  // ✅ Load plans from backend
  const fetchPlans = async () => {
    try {
      const res = await fetch("http://localhost:5000/api/annualplan");
      const data = await res.json();
      const styled = data.map((event) => ({
        ...event,
        backgroundColor: event.status === "completed" ? "#4caf50" : "#000",
        borderColor: event.status === "completed" ? "#4caf50" : "#000",
        textColor: "#fff",
        display: "block",
      }));
      setEvents(styled);
    } catch (err) {
      console.error("Failed to load events", err);
    }
  };

  useEffect(() => {
    fetchPlans();
  }, []);

  const updatePlan = async (id, data) => {
    await fetch(`http://localhost:5000/api/annualplan/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    fetchPlans();
  };

  const createPlan = async (data) => {
    await fetch("http://localhost:5000/api/annualplan", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    fetchPlans();
  };

  const handleViewChange = (_, newView) => {
    if (!newView) return;
    setView(newView);
    calendarRef.current?.getApi().changeView(newView);
  };

  const handleEventClick = (info) => {
    const confirmDone = window.confirm("Mark this task as completed?");
    if (!confirmDone) return;

    const event = info.event;
    const props = event.extendedProps;
    const recurrence = props.recurrence?.toLowerCase();
    const originalStart = dayjs(event.start);
    const originalEnd = dayjs(event.end);
    const duration = originalEnd.diff(originalStart, "minute");

    updatePlan(event.id, { status: "completed" });

    if (!recurrence || recurrence === "none") return;

    let nextStart;
    switch (recurrence) {
      case "daily": nextStart = originalStart.add(1, "day"); break;
      case "weekly": nextStart = originalStart.add(1, "week"); break;
      case "monthly": nextStart = originalStart.add(1, "month"); break;
      case "quarterly": nextStart = originalStart.add(3, "month"); break;
      case "yearly": nextStart = originalStart.add(1, "year"); break;
      default: return;
    }

    const nextEnd = nextStart.add(duration, "minute");

    createPlan({
      title: event.title,
      activity: props.activity,
      recurrence,
      category: props.category,
      type: props.type,
      reference: props.reference,
      owner: props.owner,
      createdBy: props.createdBy,
      dueDate: nextStart.format("YYYY-MM-DD"),
      startTime: nextStart.format("HH:mm:ss"),
      endTime: nextEnd.format("HH:mm:ss"),
      status: "pending",
    });
  };

  return (
    <Box p={3}>
      <Typography variant="h5" mb={2}>Work Plan</Typography>

      <ToggleButtonGroup value={view} exclusive onChange={handleViewChange} sx={{ mb: 2 }}>
        <ToggleButton value="timeGridDay">Day</ToggleButton>
        <ToggleButton value="timeGridWeek">Week</ToggleButton>
        <ToggleButton value="dayGridMonth">Month</ToggleButton>
      </ToggleButtonGroup>

      <FullCalendar
        plugins={[timeGridPlugin, dayGridPlugin, interactionPlugin]}
        initialView={view}
        ref={calendarRef}
        height="auto"
        events={events}
        editable
        selectable
        slotMinTime="08:00:00"
        slotMaxTime="17:00:00"
        headerToolbar={{ left: "prev,next today", center: "title", right: "" }}
        eventClick={handleEventClick}
        eventDrop={(info) => {
          const newStart = dayjs(info.event.start);
          const newEnd = dayjs(info.event.end);
          updatePlan(info.event.id, {
            dueDate: newStart.format("YYYY-MM-DD"),
            startTime: newStart.format("HH:mm:ss"),
            endTime: newEnd.format("HH:mm:ss"),
          });
        }}
        eventContent={(eventInfo) => (
          <div
            title={eventInfo.event.title}
            style={{ whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", padding: "2px 4px", fontSize: "0.85rem" }}
          >
            {eventInfo.event.title}
          </div>
        )}
      />
    </Box>
  );
}
