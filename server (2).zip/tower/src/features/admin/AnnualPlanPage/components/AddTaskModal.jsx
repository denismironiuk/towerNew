// File: components/AddTaskModal.jsx
import React, { useState, useEffect } from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Select,
  MenuItem,
  Button,
  FormControl,
  InputLabel,
  Stack,
} from "@mui/material";

export default function AddTaskModal({ open, onClose, onAdd, onUpdate, dateInfo, taskToEdit }) {
  const [title, setTitle] = useState("");
  const [recurrence, setRecurrence] = useState("none");

  useEffect(() => {
    if (taskToEdit) {
      setTitle(taskToEdit.title || "");
      setRecurrence(taskToEdit.recurrence || "none");
    } else {
      setTitle("");
      setRecurrence("none");
    }
  }, [taskToEdit]);

  const handleSubmit = () => {
    if (!title.trim()) return;

    const baseTask = {
      title,
      recurrence,
      backgroundColor: "#000",
      textColor: "#fff",
      status: "pending",
    };

    if (taskToEdit) {
      onUpdate({ ...taskToEdit, ...baseTask });
    } else {
      onAdd({
        id: String(Date.now()),
        ...baseTask,
        start: dateInfo.startStr,
        end: dateInfo.endStr,
      });
    }

    onClose();
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle>{taskToEdit ? "Edit Task" : "Add New Task"}</DialogTitle>
      <DialogContent>
        <Stack spacing={2} mt={1}>
          <TextField
            label="Task Title"
            fullWidth
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />
          <FormControl fullWidth>
            <InputLabel>Recurrence</InputLabel>
            <Select
              value={recurrence}
              onChange={(e) => setRecurrence(e.target.value)}
              label="Recurrence"
            >
              <MenuItem value="none">None</MenuItem>
              <MenuItem value="day">Daily</MenuItem> 
              <MenuItem value="month">Monthly</MenuItem>
              <MenuItem value="6months">Every 6 Months</MenuItem>
              <MenuItem value="year">Yearly</MenuItem>
            </Select>
          </FormControl>
        </Stack>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Cancel</Button>
        <Button variant="contained" onClick={handleSubmit} color="success">
          {taskToEdit ? "Save Changes" : "Add"}
        </Button>
      </DialogActions>
    </Dialog>
  );
}