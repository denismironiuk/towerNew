import React, { useRef, useEffect, useState } from "react";
import FullCalendar from "@fullcalendar/react";
import timeGridPlugin from "@fullcalendar/timegrid";
import dayGridPlugin from "@fullcalendar/daygrid";
import interactionPlugin from "@fullcalendar/interaction";
import {
  Box,
  ToggleButtonGroup,
  ToggleButton,
  Typography,
  Dialog,
  DialogTitle,
  DialogContent,
  TextField,
  MenuItem,
  DialogActions,
  Button
} from "@mui/material";
import dayjs from "dayjs";
import { useSelector, useDispatch } from "react-redux";
import {
  setEvents,
  updateEvent,
  addEvent,
} from "../store/eventSlice";
import {
  fetchEvents,
  updateEvent as updateEventAPI,
  createEvent as createEventAPI,
} from "../services/eventsService";

export default function AnnualPlanCalendar() {
  const dispatch = useDispatch();
  const events = useSelector((state) => state.events.items);
  const [view, setView] = useState("timeGridWeek");
  const calendarRef = useRef(null);
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
const [newEventData, setNewEventData] = useState({
  title: "",
  start: null,
  end: null,
  category: "",
  recurrence: "none",
});

  const getNextValidDate = (startDate, recurrenceUnit) => {
    let nextDate = startDate.add(1, recurrenceUnit);
  
    // While nextDate is Friday (5) or Saturday (6), keep adding 1 day
    while ([5, 6].includes(nextDate.day())) {
      nextDate = nextDate.add(1, 'day');
    }
  
    return nextDate;
  };
  

  const calculateNextRecurrence = (event) => {
    const originalStart = dayjs(event.start);
    const originalEnd = dayjs(event.end);
    if (!originalStart.isValid() || !originalEnd.isValid()) return null;
  
    const recurrence = (event.recurrence || '').toLowerCase();
    let unit;
  
    switch (recurrence) {
      case 'daily':
        unit = 'day';
        break;
      case 'weekly':
        unit = 'week';
        break;
      case 'monthly':
        unit = 'month';
        break;
      case 'quarterly':
        unit = 'month';
        break;
      case 'yearly':
        unit = 'year';
        break;
      default:
        console.warn('Unsupported recurrence:', recurrence);
        return null;
    }
  
    const increment = recurrence === 'quarterly' ? 3 : 1;
    const nextStart = getNextValidDate(originalStart, unit === 'month' && increment > 1 ? 'month' : unit).add(increment - 1, unit);
    const duration = originalEnd.diff(originalStart, 'minute');
    const nextEnd = nextStart.add(duration, 'minute');
  
    return {
      start: nextStart.toISOString(),
      end: nextEnd.toISOString(),
    };
  };
  

  useEffect(() => {
    const loadEvents = async () => {
      try {
        const res = await fetchEvents();
        dispatch(setEvents(res.data));
      } catch (err) {
        console.error("Failed to load events:", err);
      }
    };

    loadEvents();
  }, [dispatch]);

  const handleViewChange = (_, newView) => {
    if (!newView) return;
    setView(newView);
    calendarRef.current?.getApi().changeView(newView);
  };

  const handleEventClick = async (info) => {
    const event = info.event;
    const props = event.extendedProps;

    if (props.status === "completed") {
      alert("This task is already completed.");
      return;
    }

    const confirmDone = window.confirm("Mark this task as completed?");
    if (!confirmDone) return;

    const matchedEvent = {
      ...props,
      id: event.id,
      title: event.title,
      start: event.start,
      end: event.end,
    };

    const recurrence = props.recurrence;
    const nextDates = recurrence !== "none" ? calculateNextRecurrence(matchedEvent) : null;

    const updatedEvents = events.map((ev) =>
      ev.id === event.id
        ? {
            ...ev,
            status: "completed",
            backgroundColor: "#4caf50",
            borderColor: "#4caf50",
          }
        : ev
    );

    try {
      await updateEventAPI(event.id, {
        ...matchedEvent,
        status: "completed",
      });

      if (nextDates) {
        const newEvent = {
          ...props,
          id: Date.now().toString(),
          title: event.title,
          start: nextDates.start,
          end: nextDates.end,
          recurrence,
          status: "pending",
          allDay: false,
          category: props.category,
          type: props.type,
          activity: props.activity,
          owner: props.owner,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };

        await createEventAPI(newEvent);
        updatedEvents.push(newEvent);
      }

      dispatch(setEvents(updatedEvents));
    } catch (err) {
      console.error("Failed to update or create recurrence:", err);
    }
  };

  const handleEventDrop = async (info) => {
    const updatedEvent = {
      ...events.find((e) => e.id === info.event.id),
      start: info.event.startStr,
      end: info.event.endStr,
    };

    try {
      await updateEventAPI(info.event.id, updatedEvent);
      dispatch(updateEvent(updatedEvent));
    } catch (err) {
      console.error("Failed to update event:", err);
    }
  };

  const styledEvents = events.map((event) => ({
    ...event,
    backgroundColor: event.status === 'completed' ? '#4caf50' : '#000',
    borderColor: event.status === 'completed' ? '#4caf50' : '#000',
    textColor: '#fff',
    display: 'block',
  }));

  const handleDateSelect = (selectInfo) => {
    setNewEventData({
      ...newEventData,
      start: selectInfo.startStr,
      end: selectInfo.endStr,
    });
    setCreateDialogOpen(true);
  };
  
  

  return (
    <Box p={3}>
      <Typography variant="h5" mb={2}>
        Work Plan (Local Recurrence Simulation)
      </Typography>

      <ToggleButtonGroup
        value={view}
        exclusive
        onChange={handleViewChange}
        sx={{ mb: 2 }}
      >
        <ToggleButton value="timeGridDay">Day</ToggleButton>
        <ToggleButton value="timeGridWeek">Week</ToggleButton>
        <ToggleButton value="dayGridMonth">Month</ToggleButton>
      </ToggleButtonGroup>

      <FullCalendar
        plugins={[timeGridPlugin, dayGridPlugin, interactionPlugin]}
        initialView={view}
        ref={calendarRef}
        height="auto"
        events={styledEvents}
        selectable
        editable
        slotMinTime="09:00:00"
        slotMaxTime="17:00:00"
      
        headerToolbar={{ left: "prev,next today", center: "title", right: "" }}
        eventClick={handleEventClick}
        eventDrop={handleEventDrop}
        eventAllow={(dropInfo, draggedEvent) => {
            const isWeekend = [5, 6].includes(dropInfo.start.getDay());
          const isCompleted = draggedEvent.extendedProps.status === 'completed';
          return !isWeekend && !isCompleted;
        }}
        selectAllow={(selectInfo) => {
            const isWeekend = [5, 6].includes(selectInfo.start.getDay()); // Friday + Saturday
            return !isWeekend;
        }}
        select={handleDateSelect}
        eventContent={(eventInfo) => (
          <div
            title={eventInfo.event.title}
            style={{
              whiteSpace: "nowrap",
              overflow: "hidden",
              textOverflow: "ellipsis",
              padding: "2px 4px",
              fontSize: "0.85rem",
            }}
          >
            {eventInfo.event.title}
          </div>
        )}
      />
      <Dialog open={createDialogOpen} onClose={() => setCreateDialogOpen(false)} fullWidth maxWidth="sm">
  <DialogTitle>Create New Event</DialogTitle>
  <DialogContent sx={{ display: "flex", flexDirection: "column", gap: 2, mt: 1 }}>
    <TextField
      label="Title"
      value={newEventData.title}
      onChange={(e) => setNewEventData({ ...newEventData, title: e.target.value })}
      fullWidth
    />
    <TextField
      label="Category"
      value={newEventData.category}
      onChange={(e) => setNewEventData({ ...newEventData, category: e.target.value })}
      fullWidth
    />
    <TextField
      label="Recurrence"
      select
      value={newEventData.recurrence}
      onChange={(e) => setNewEventData({ ...newEventData, recurrence: e.target.value })}
      fullWidth
    >
      <MenuItem value="none">None</MenuItem>
      <MenuItem value="daily">Daily</MenuItem>
      <MenuItem value="weekly">Weekly</MenuItem>
      <MenuItem value="monthly">Monthly</MenuItem>
      <MenuItem value="quarterly">Quarterly</MenuItem>
      <MenuItem value="yearly">Yearly</MenuItem>
    </TextField>
  </DialogContent>
  <DialogActions>
    <Button onClick={() => setCreateDialogOpen(false)}>Cancel</Button>
    <Button
      variant="contained"
      onClick={async () => {
        const eventToCreate = {
          ...newEventData,
          id: Date.now().toString(),
          status: "pending",
          activity: "Manual",
          owner: "You",
          allDay: false,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };

        try {
          await createEventAPI(eventToCreate);
          dispatch(addEvent(eventToCreate));
          setCreateDialogOpen(false);
        } catch (err) {
          console.error("Failed to create event:", err);
          alert("Could not create event.");
        }
      }}
    >
      Create
    </Button>
  </DialogActions>
</Dialog>

    </Box>
  );
}