import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  getAllPlans,
  getPlanById,
  createPlan,
  updatePlan,
  deletePlan,
} from '../services/annualPlanSerices'; // fix the typo in 'Services'

// ✅ Fetch all plans
export const useGetPlans = () =>
  useQuery({
    queryKey: ['annualplans'],
    queryFn: getAllPlans,
    select: (res) => res.data,
  });

// ✅ Fetch one plan
export const useGetPlan = (id) =>
  useQuery({
    queryKey: ['annualplan', id],
    queryFn: () => getPlanById(id),
    enabled: !!id,
    select: (res) => res.data,
  });

// ✅ Create plan
export const useCreatePlan = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: createPlan,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['annualplans'] });
    },
  });
};

// ✅ Update plan
export const useUpdatePlan = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, data }) => updatePlan(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['annualplans'] });
    },
  });
};

// ✅ Delete plan
export const useDeletePlan = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: deletePlan,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['annualplans'] });
    },
  });
};
