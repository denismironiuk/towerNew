import dayjs from "dayjs";

export const transformAuditsToEvents = (audits = []) => {
    return audits.map(audit => ({
      id: audit.id,
      title: audit.activity,
      start: audit.dueDate + 'T' + audit.startTime, // e.g., "2025-04-10T09:00"
      end: audit.dueDate + 'T' + audit.endTime,     // e.g., "2025-04-10T11:00"
      backgroundColor: audit.status === 'done' ? '#4caf50' : '#000',
      textColor: "#fff",
      status: audit.status,
      recurrence: audit.recurrence,
    }));
  };
  export function transformAuditToEvent(audit) {
    const date = dayjs(audit.dueDate).format('YYYY-MM-DD');
  
  return {
    id: audit.id,
    title: audit.activity,
    start: dayjs(`${date}T${audit.startTime}`).toISOString(),
    end: dayjs(`${date}T${audit.endTime}`).toISOString(),
    backgroundColor: audit.status === 'done' ? '#4caf50' : '#000',
    textColor: "#fff",
    borderColor: audit.status === 'done' ? '#4caf50' : '#000',
    display: 'block', // ← forces solid background in month view
    status: audit.status,
    recurrence: audit.recurrence,
  };
  }
  
 

export const calculateNextRecurrence = (event) => {
    console.log(event)
    const originalStart = dayjs(event.start);
    const originalEnd = dayjs(event.end);
    if (!originalStart.isValid() || !originalEnd.isValid()) return null;
  
    const recurrence = (event.recurrence || "").toLowerCase();
    let nextStart;
  console.log(recurrence)
    switch (recurrence) {
      case "daily":
        nextStart = originalStart.add(1, "day");
        break;
      case "weekly":
        nextStart = originalStart.add(1, "week");
        break;
      case "monthly":
        nextStart = originalStart.add(1, "month");
        break;
      case "quarterly":
        nextStart = originalStart.add(3, "month");
        break;
      case "yearly":
        nextStart = originalStart.add(1, "year");
        break;
      default:
        console.warn("Unsupported recurrence:", recurrence);
        return null;
    }
  
    const duration = originalEnd.diff(originalStart, "minute");
    const nextEnd = nextStart.add(duration, "minute");
  
    return {
      start: nextStart.toISOString(),
      end: nextEnd.toISOString(),
    };
  };
