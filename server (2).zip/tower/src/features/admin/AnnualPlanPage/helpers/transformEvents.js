import dayjs from 'dayjs';

export const transformToFullCalendar = (plan) => {
  const date = dayjs(plan.dueDate).format('YYYY-MM-DD'); // Convert dueDate to YYYY-MM-DD

  const startTime = plan.startTime || '09:00:00'; // Default startTime if not provided
  const endTime = plan.endTime || '10:00:00';   // Default endTime if not provided

  // Convert to ISO string by combining dueDate with startTime and endTime
  const start = dayjs(`${date}T${startTime}`).toISOString();
  const end = dayjs(`${date}T${endTime}`).toISOString();

  return {
    id: plan.id,
    title: plan.activity, // Your custom field for the event
    start,                // FullCalendar uses this
    end,                  // FullCalendar uses this
    allDay: false,        // If you need to set as an all-day event, change to true
    backgroundColor: plan.status === 'done' ? '#4caf50' : '#000', // Example for color coding based on status
    textColor: '#fff',
    borderColor: '#000',
    status: plan.status,
    recurrence: plan.recurrence,
    // Include other fields if necessary (for recurrence or editing purposes)
    activity: plan.activity,
    dueDate: plan.dueDate,
    category: plan.category,
    type: plan.type,
    owner: plan.owner,
    reference: plan.reference,
    createdBy: plan.createdBy,
  };
};

export const revertToOriginalData = (event) => {
  const dueDate = dayjs(event.start).format('YYYY-MM-DD');
  const startTime = dayjs(event.start).format('HH:mm:ss');
  const endTime = dayjs(event.end).format('HH:mm:ss');

  return {
    id: event.id,
    activity: event.activity || event.title,
    dueDate,
    startTime,
    endTime,
    status: event.status,
    recurrence: event.recurrence,
    category: event.category,
    type: event.type,
    reference: event.reference,
    owner: event.owner,
    createdBy: event.createdBy,
  };
};
