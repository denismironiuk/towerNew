import React from 'react'
import Navbar from '../../commons/Navbar'
import AnnualPlancontainer from './containers/AnnualPlancontainer'

const AnnualPlanPage = () => {
  return (
    <>
    
    <AnnualPlancontainer/>
    </>
  )
}

export default AnnualPlanPage