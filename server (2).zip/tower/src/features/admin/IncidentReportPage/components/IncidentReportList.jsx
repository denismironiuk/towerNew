// File: components/IncidentsTaskList.jsx
import React, { useState, useMemo } from 'react';
import {
  Box,
  Button,
  TextField,
  Typography,
  MenuItem,
  Select,
  InputLabel,
  FormControl,
  Link,
  IconButton,
  Stack,
  Tooltip,
  Dialog,
  DialogTitle,
  DialogContent,
} from '@mui/material';
import { DataGrid, GridToolbarExport } from '@mui/x-data-grid';
import EditIcon from '@mui/icons-material/Edit';
import DoneIcon from '@mui/icons-material/Done';
import dayjs from 'dayjs';

const columns = [
  { field: 'id', headerName: 'ID', width: 80, sortable: true },
  { field: 'date', headerName: 'Incident Date', width: 130, sortable: true },
  { field: 'description', headerName: 'Description', flex: 1 },
  { field: 'consequence', headerName: 'Consequence', flex: 1 },
  { field: 'location', headerName: 'Location', width: 100 },
  { field: 'rootCause', headerName: 'Root Cause', flex: 1 },
  {
    field: 'report',
    headerName: 'Report',
    width: 100,
    renderCell: () => <Link component="button">Report</Link>,
    sortable: false,
    filterable: false,
  },
  {
    field: 'type',
    headerName: 'Type',
    width: 130,
    renderCell: (params) => (
      <Typography
        color={
          params.row.type === 'Car Accident'
            ? 'error'
            : params.row.type === 'Work Accident'
            ? 'orange'
            : 'textPrimary'
        }
      >
        {params.row.type}
      </Typography>
    ),
  },
  {
    field: 'status',
    headerName: 'Status',
    width: 100,
    renderCell: (params) => (
      <Typography color={params.row.status === 'Open' ? 'green' : 'red'}>
        {params.row.status}
      </Typography>
    ),
  },
  {
    field: 'actions',
    headerName: 'Actions',
    width: 100,
    renderCell: () => (
      <Stack direction="row" spacing={1}>
        <Tooltip title="Edit">
          <IconButton size="small">
            <EditIcon />
          </IconButton>
        </Tooltip>
        <Tooltip title="Close">
          <IconButton size="small">
            <DoneIcon />
          </IconButton>
        </Tooltip>
      </Stack>
    ),
  },
];

export default function IncidentsTaskList() {
  const [rows, setRows] = useState([
    {
      id: '0001',
      date: '2024-12-26',
      description: 'A worker fell down the stairs',
      consequence: 'Employee Heart hit his back',
      location: 'FAB-2',
      rootCause: 'The employee was distracted on the phone',
      type: 'General',
      status: 'Open',
    },
    {
      id: '0002',
      date: '2024-11-01',
      description: 'Car incident on the way home',
      consequence: 'Employee heart his back and knees',
      location: 'FAB-1',
      rootCause: 'Bad Luck',
      type: 'Car Accident',
      status: 'Close',
    },
    {
      id: '0003',
      date: '2025-01-02',
      description: 'Cl2 gas alarm from CNTO1',
      consequence: 'FAB Evacuation',
      location: 'FAB-2',
      rootCause: 'Technical Fail',
      type: 'On The Way',
      status: 'Open',
    },
    {
      id: '0004',
      date: '2025-01-04',
      description: 'Employee cut his finger',
      consequence: 'Deep cut that involved stitches',
      location: 'Kitchen',
      rootCause: 'Improper use in safety equipment',
      type: 'Work Accident',
      status: 'Open',
    },
  ]);

  const [newIncident, setNewIncident] = useState({
    date: '',
    description: '',
    consequence: '',
    location: '',
    rootCause: '',
    type: '',
    status: 'Open',
  });

  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilter, setTypeFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [locationFilter, setLocationFilter] = useState('');
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');
  const [period, setPeriod] = useState('');
  const [isAddOpen, setIsAddOpen] = useState(false);

  const filteredRows = useMemo(() => {
    let data = [...rows];

    if (period) {
      const now = dayjs();
      const from =
        period === 'week'
          ? now.subtract(7, 'day')
          : period === 'month'
          ? now.subtract(1, 'month')
          : period === 'quarter'
          ? now.subtract(3, 'month')
          : period === 'year'
          ? now.subtract(1, 'year')
          : null;
      data = data.filter((r) => dayjs(r.date).isAfter(from));
    }

    return data.filter((row) => {
      const matchesSearch =
        !searchTerm ||
        Object.values(row).some((val) =>
          val?.toString().toLowerCase().includes(searchTerm.toLowerCase())
        );

      const matchesType = !typeFilter || row.type === typeFilter;
      const matchesStatus = !statusFilter || row.status === statusFilter;
      const matchesLocation =
        !locationFilter || row.location === locationFilter;
      const matchesDate =
        (!fromDate ||
          dayjs(row.date).isAfter(dayjs(fromDate).subtract(1, 'day'))) &&
        (!toDate || dayjs(row.date).isBefore(dayjs(toDate).add(1, 'day')));

      return (
        matchesSearch &&
        matchesType &&
        matchesStatus &&
        matchesLocation &&
        matchesDate
      );
    });
  }, [
    rows,
    searchTerm,
    typeFilter,
    statusFilter,
    locationFilter,
    fromDate,
    toDate,
    period,
  ]);

  return (
    <Box p={3}>
      <Typography variant="h5" gutterBottom>
        Incidents Report Management
      </Typography>

      <Box display="flex" flexWrap="wrap" gap={2} mb={3}>
        <TextField
          label="Search"
          variant="outlined"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          sx={{ minWidth: 200 }}
        />
        <TextField
          type="date"
          label="From"
          value={fromDate}
          onChange={(e) => setFromDate(e.target.value)}
          InputLabelProps={{ shrink: true }}
        />
        <TextField
          type="date"
          label="To"
          value={toDate}
          onChange={(e) => setToDate(e.target.value)}
          InputLabelProps={{ shrink: true }}
        />
        <FormControl sx={{ minWidth: 140 }}>
          <InputLabel>Type</InputLabel>
          <Select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value)}
          >
            <MenuItem value="">All</MenuItem>
            <MenuItem value="General">General</MenuItem>
            <MenuItem value="Car Accident">Car Accident</MenuItem>
            <MenuItem value="Work Accident">Work Accident</MenuItem>
          </Select>
        </FormControl>
        <FormControl sx={{ minWidth: 140 }}>
          <InputLabel>Status</InputLabel>
          <Select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
          >
            <MenuItem value="">All</MenuItem>
            <MenuItem value="Open">Open</MenuItem>
            <MenuItem value="Close">Close</MenuItem>
          </Select>
        </FormControl>
        <FormControl sx={{ minWidth: 140 }}>
          <InputLabel>Location</InputLabel>
          <Select
            value={locationFilter}
            onChange={(e) => setLocationFilter(e.target.value)}
          >
            <MenuItem value="">All</MenuItem>
            <MenuItem value="FAB-1">FAB-1</MenuItem>
            <MenuItem value="FAB-2">FAB-2</MenuItem>
            <MenuItem value="Kitchen">Kitchen</MenuItem>
          </Select>
        </FormControl>
        <FormControl sx={{ minWidth: 140 }}>
          <InputLabel>Period</InputLabel>
          <Select value={period} onChange={(e) => setPeriod(e.target.value)}>
            <MenuItem value="">Custom</MenuItem>
            <MenuItem value="week">Last Week</MenuItem>
            <MenuItem value="month">Last Month</MenuItem>
            <MenuItem value="quarter">Last Quarter</MenuItem>
            <MenuItem value="year">Last Year</MenuItem>
          </Select>
        </FormControl>
        <Box     sx={{ display:'flex' ,justifyContent:'end',width:'100%'}}>
        <Button
      
          variant="contained"
          color="warning"
          onClick={() => setIsAddOpen(true)}
        >
          Add New
        </Button>
        </Box>
       

        {/* <Button variant="outlined">Generate Report</Button> */}
      </Box>

      <Box height={500}>
        <Dialog
          open={isAddOpen}
          onClose={() => setIsAddOpen(false)}
          maxWidth="sm"
          fullWidth
        >
          <DialogTitle>Add New Incident</DialogTitle>
          <DialogContent>
            {/* You can add TextFields here for new incident data */}
            <Stack spacing={2} mt={2}>
              <TextField
                label="Date"
                type="date"
                value={newIncident.date}
                onChange={(e) =>
                  setNewIncident({ ...newIncident, date: e.target.value })
                }
                InputLabelProps={{ shrink: true }}
                fullWidth
              />
              <TextField
                label="Description"
                value={newIncident.description}
                onChange={(e) =>
                  setNewIncident({
                    ...newIncident,
                    description: e.target.value,
                  })
                }
                fullWidth
              />
              <TextField
                label="Consequence"
                value={newIncident.consequence}
                onChange={(e) =>
                  setNewIncident({
                    ...newIncident,
                    consequence: e.target.value,
                  })
                }
                fullWidth
              />
              <TextField
                label="Location"
                value={newIncident.location}
                onChange={(e) =>
                  setNewIncident({ ...newIncident, location: e.target.value })
                }
                fullWidth
              />
              <TextField
                label="Root Cause"
                value={newIncident.rootCause}
                onChange={(e) =>
                  setNewIncident({ ...newIncident, rootCause: e.target.value })
                }
                fullWidth
              />
              <TextField
                label="Type"
                value={newIncident.type}
                onChange={(e) =>
                  setNewIncident({ ...newIncident, type: e.target.value })
                }
                fullWidth
              />
            </Stack>

            <Box mt={3} display="flex" justifyContent="flex-end">
              <Button onClick={() => setIsAddOpen(false)} color="primary">
                Cancel
              </Button>
              <Button
                onClick={() => {
                  const newId = `NEW-${Math.floor(Math.random() * 10000)}`;
                  const newRow = { ...newIncident, id: newId };

                  setRows((prevRows) => [newRow, ...prevRows]); // ✅ React-friendly update

                  setIsAddOpen(false);
                  setNewIncident({
                    date: '',
                    description: '',
                    consequence: '',
                    location: '',
                    rootCause: '',
                    type: '',
                    status: 'Open',
                  });
                }}
              >
                Save
              </Button>
            </Box>
          </DialogContent>
        </Dialog>

        <DataGrid
          rows={filteredRows}
          columns={columns}
          pageSize={5}
          getRowId={(row) => row.id}
          components={{ Toolbar: GridToolbarExport }}
          sx={{
            '& .MuiDataGrid-cell:focus': { outline: 'none' },
            '& .MuiTypography-root': { fontSize: 14 },
          }}
        />
      </Box>
    </Box>
  );
}
