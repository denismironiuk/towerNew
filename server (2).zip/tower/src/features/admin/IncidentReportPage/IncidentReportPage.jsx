import React from 'react'
import Navbar from '../../commons/Navbar'
import IncidentReportContainer from './containers/IncidentReportContainer'

const IncidentReportPage = () => {
  return (
   <>
  
   <IncidentReportContainer/>
   </>
  )
}

export default IncidentReportPage