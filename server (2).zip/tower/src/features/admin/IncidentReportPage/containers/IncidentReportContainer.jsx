import React from 'react'
import IncidentReportList from '../components/IncidentReportList'

const IncidentReportContainer = () => {
  return (
    <>
    <IncidentReportList
   
    />
    </>
  )
}

export default IncidentReportContainer