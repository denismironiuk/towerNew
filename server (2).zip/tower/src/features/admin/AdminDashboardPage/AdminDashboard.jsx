import React from 'react'
import Navbar from "../../commons/Navbar"
import AdminContainer from './containers/AdminContainer'

const AdminDashboard = () => {
  return (
    <>
   
    <AdminContainer/>
    </>
  )
}

export default AdminDashboard