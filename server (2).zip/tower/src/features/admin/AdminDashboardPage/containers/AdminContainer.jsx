import React from 'react'
import styles from './AdminContainer.module.css'
import { useNavigate } from 'react-router-dom';

const adminPages = [
    {
      title: "Annual Plan",
      image: "/images/annual_plan.webp",
      link: "/dashboard/annual-plan",
    },
    {
      title: "Incident Report",
      image: "/images/incudentwebp.webp",
      link: "/dashboard/incident-report",
    },
    {
      title: "Safety Audit",
      image: "/images/safety audit.jpg",
      link: "/dashboard/safety-audit",
    },
    {
      title: "Safety Training",
      image: "/images/training.jpg",
      link: "/dashboard/safety-training",
    },
    {
      title: "Do the Safety Walk",
      image: "/images/swa6.png",
      link: "/dashboard/safety-certification",
    },
  ];
const AdminContainer = () => {
  
    const navigate = useNavigate();

    return (
      <main className={styles.container}>
       
        <div className={styles.grid}>
          {adminPages.map(({ title, image, link }) => (
            <div
              key={title}
              className={styles.card}
              onClick={() => navigate(link)}
            >
              <img src={image} alt={title} className={styles.image} />
              <h3 className={styles.cardTitle}>{title}</h3>
            </div>
          ))}
        </div>
      </main>
    );
}

export default AdminContainer