import React from 'react'
import Navbar from '../../../commons/Navbar'
import { Outlet } from 'react-router-dom'

const DashboardLayout = () => {
  return (
   <>
   <Navbar 
   path="Dashboard"
   />
   <main>
    <Outlet/>
   </main>
   </>
  )
}

export default DashboardLayout
