// hooks/useSafetyAudits.js
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import safetyAuditService from '../services/safetyAuditServices';

export const useSafetyAudits = () => {
  return useQuery({
    queryKey: ['safetyAudits'],
    queryFn: safetyAuditService.getAllAudits,
  });
};
export const useAddSafetyAudit = () => {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: safetyAuditService.createAudit,
    onSuccess: () => {
      queryClient.invalidateQueries(['safetyAudits']);
    }
  });
};