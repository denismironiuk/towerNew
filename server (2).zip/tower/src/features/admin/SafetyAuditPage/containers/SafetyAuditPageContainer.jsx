import React from 'react'
import {useSafetyAudits} from '../hooks/useSafetyAudits'
import SafetyAuditList from '../components/SafetyAuditList';
const SafetyAuditPageContainer = () => {
  const { data: audits, error, isLoading } = useSafetyAudits();
  return (
    <SafetyAuditList
    audits={audits}
    loading={isLoading}
    error={error}
    />
  )
}

export default SafetyAuditPageContainer