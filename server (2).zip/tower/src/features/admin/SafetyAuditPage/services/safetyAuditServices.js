import axiosInstance from "../../../../utils/axiosConfig";


const safetyAuditService = {
  getAllAudits: async () => {
    const response = await axiosInstance.get('/safety-audits');
    return response.data;
  },
  getAuditById: async (id) => {
    const response = await axiosInstance.get(`/safety-audits/${id}`);
    return response.data;
  },
  createAudit: async (auditData) => {
    const response = await axiosInstance.post('/safety-audits', auditData);
    return response.data;
  },
  updateAudit: async (id, auditData) => {
    const response = await axiosInstance.put(`/safety-audits/${id}`, auditData);
    return response.data;
  },
  deleteAudit: async (id) => {
    const response = await axiosInstance.delete(`/safety-audits/${id}`);
    return response.data;
  },
};

export default safetyAuditService;
