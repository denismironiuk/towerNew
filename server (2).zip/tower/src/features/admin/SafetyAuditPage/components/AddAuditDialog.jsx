import React from "react";
import {
  Dialog, DialogTitle, DialogContent,
  Box, FormControl, InputLabel, Select, MenuItem,
  TextField, Button
} from "@mui/material";
import { LocalizationProvider, DatePicker } from "@mui/x-date-pickers";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import dayjs from "dayjs";

const AddAuditDialog = ({ open, onClose, newAudit, setNewAudit, onSave }) => (
  <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
    <DialogTitle>Add New Safety Audit</DialogTitle>
    <DialogContent>
      <Box display="flex" flexDirection="column" gap={2} mt={2}>
        <FormControl fullWidth>
          <InputLabel>Category</InputLabel>
          <Select value={newAudit.category} label="Category"
                  onChange={(e) => setNewAudit({ ...newAudit, category: e.target.value })}>
            <MenuItem value="Safety">Safety</MenuItem>
            <MenuItem value="Health">Health</MenuItem>
            <MenuItem value="Environmental">Environmental</MenuItem>
          </Select>
        </FormControl>

        <FormControl fullWidth>
          <InputLabel>Type</InputLabel>
          <Select value={newAudit.type} label="Type"
                  onChange={(e) => setNewAudit({ ...newAudit, type: e.target.value })}>
            <MenuItem value="Review & Audits">Review & Audits</MenuItem>
            <MenuItem value="Permits and licenses">Permits and licenses</MenuItem>
            <MenuItem value="Safety trainings">Safety trainings</MenuItem>
            <MenuItem value="Medical examination">Medical examination</MenuItem>
            <MenuItem value="EHS equipment control">EHS equipment control</MenuItem>
          </Select>
        </FormControl>

        <FormControl fullWidth>
          <InputLabel>Recurrence</InputLabel>
          <Select value={newAudit.recurrence} label="Recurrence"
                  onChange={(e) => setNewAudit({ ...newAudit, recurrence: e.target.value })}>
            <MenuItem value="none">None</MenuItem>
            <MenuItem value="weekly">Weekly</MenuItem>
            <MenuItem value="monthly">Monthly</MenuItem>
            <MenuItem value="quarterly">Quarterly</MenuItem>
            <MenuItem value="biannually">Biannually</MenuItem>
            <MenuItem value="yearly">Yearly</MenuItem>
          </Select>
        </FormControl>

        <LocalizationProvider dateAdapter={AdapterDayjs}>
          <DatePicker
            label="Due Date"
            value={newAudit.dueDate ? dayjs(newAudit.dueDate) : null}
            onChange={(date) => setNewAudit({ ...newAudit, dueDate: dayjs(date).format("YYYY-MM-DD") })}
            slotProps={{ textField: { fullWidth: true } }}
          />
        </LocalizationProvider>

        <TextField label="Activity" fullWidth onChange={(e) => setNewAudit({ ...newAudit, activity: e.target.value })} />
        <TextField label="Reference" fullWidth onChange={(e) => setNewAudit({ ...newAudit, reference: e.target.value })} />
        <TextField label="Owner" fullWidth onChange={(e) => setNewAudit({ ...newAudit, owner: e.target.value })} />
        <TextField type="time" label="Start Time" InputLabelProps={{ shrink: true }} fullWidth onChange={(e) => setNewAudit({ ...newAudit, startTime: e.target.value })} />
        <TextField type="time" label="End Time" InputLabelProps={{ shrink: true }} fullWidth onChange={(e) => setNewAudit({ ...newAudit, endTime: e.target.value })} />
      </Box>

      <Box mt={2} display="flex" justifyContent="flex-end">
        <Button onClick={onClose} sx={{ mr: 1 }}>Cancel</Button>
        <Button variant="contained" onClick={onSave}>Save</Button>
      </Box>
    </DialogContent>
  </Dialog>
);

export default AddAuditDialog;