import React, { useState, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import {
  Box, CircularProgress, Typography, Button
} from "@mui/material";
import { useAddSafetyAudit } from "../hooks/useSafetyAudits";
import AuditTable from "./AuditTable";
import AddAuditDialog from "./AddAuditDialog";

const SafetyAuditList = ({ audits, loading, error }) => {
  const [categoryFilter, setCategoryFilter] = useState("");
  const [typeFilter, setTypeFilter] = useState("");
  const [activityFilter, setActivityFilter] = useState("");
  const [isAddOpen, setIsAddOpen] = useState(false);

  const [newAudit, setNewAudit] = useState({
    category: "",
    type: "",
    activity: "",
    reference: "",
    owner: "",
    fileUrl: "",
    recurrence: "none",
    dueDate: "",
    startTime: "",
    endTime: "",
  });

  const navigate = useNavigate();
  const addAuditMutation = useAddSafetyAudit();

  const filteredAudits = useMemo(() => {
    return (audits || []).filter((a) => {
      return (!categoryFilter || a.category === categoryFilter) &&
             (!typeFilter || a.type === typeFilter) &&
             (!activityFilter || a.activity === activityFilter);
    });
  }, [audits, categoryFilter, typeFilter, activityFilter]);

  const handleSave = () => {
    addAuditMutation.mutate(newAudit, { onSuccess: () => setIsAddOpen(false) });
  };

  if (loading) return <Box textAlign="center" mt={4}><CircularProgress /></Box>;
  if (error) return <Typography color="error" textAlign="center" mt={4}>Error: {error.message || error}</Typography>;

  return (
    <Box sx={{ width: "100%", mt: 2 }}>
      <AuditTable
        audits={audits}
        filteredAudits={filteredAudits}
        categoryFilter={categoryFilter}
        setCategoryFilter={setCategoryFilter}
        typeFilter={typeFilter}
        setTypeFilter={setTypeFilter}
        activityFilter={activityFilter}
        setActivityFilter={setActivityFilter}
        setIsAddOpen={setIsAddOpen}
        navigate={navigate}
      />

      <AddAuditDialog
        open={isAddOpen}
        onClose={() => setIsAddOpen(false)}
        newAudit={newAudit}
        setNewAudit={setNewAudit}
        onSave={handleSave}
      />
    </Box>
  );
};

export default SafetyAuditList;