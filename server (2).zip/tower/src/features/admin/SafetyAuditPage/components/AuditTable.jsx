import React from "react";
import {
  Box, FormControl, InputLabel, Select, MenuItem, IconButton, Button
} from "@mui/material";
import { DataGrid } from "@mui/x-data-grid";
import InsertDriveFileIcon from "@mui/icons-material/InsertDriveFile";

const AuditTable = ({
  audits, filteredAudits,
  categoryFilter, setCategoryFilter,
  typeFilter, setTypeFilter,
  activityFilter, setActivityFilter,
  setIsAddOpen, navigate
}) => {
  const handleFilePreview = (fileUrl) => {
    if (fileUrl) window.open(fileUrl, "_blank");
  };

  const handleRowClick = (params) => {
    navigate(`/safety-audit/${params.row.id}`);
  };

  const columns = [
    { field: "category", headerName: "Category", flex: 1 },
    { field: "type", headerName: "Type", flex: 1.2 },
    { field: "activity", headerName: "Activity", flex: 1.5 },
    { field: "reference", headerName: "Reference", flex: 1 },
    { field: "owner", headerName: "Owner", flex: 1.2 },
    {
      field: "fileUrl",
      headerName: "File",
      width: 90,
      sortable: false,
      renderCell: (params) =>
        params.value ? (
          <IconButton onClick={() => handleFilePreview(params.value)}>
            <InsertDriveFileIcon color="primary" />
          </IconButton>
        ) : ("-"),
    },
  ];

  return (
    <>
      <Box display="flex" gap={2} mb={2} flexWrap="wrap">
        <FormControl sx={{ minWidth: 200 }}>
          <InputLabel>Category</InputLabel>
          <Select value={categoryFilter} label="Category" onChange={(e) => setCategoryFilter(e.target.value)}>
            <MenuItem value="">All</MenuItem>
            <MenuItem value="Safety">Safety</MenuItem>
            <MenuItem value="Health">Health</MenuItem>
            <MenuItem value="Environment">Environment</MenuItem>
            <MenuItem value="Compliance">Compliance</MenuItem>
          </Select>
        </FormControl>

        <FormControl sx={{ minWidth: 200 }}>
          <InputLabel>Type</InputLabel>
          <Select value={typeFilter} label="Type" onChange={(e) => setTypeFilter(e.target.value)}>
            <MenuItem value="">All</MenuItem>
            <MenuItem value="Review">Review</MenuItem>
            <MenuItem value="Inspection">Inspection</MenuItem>
            <MenuItem value="Survey">Survey</MenuItem>
            <MenuItem value="Drill">Drill</MenuItem>
            <MenuItem value="Audit">Audit</MenuItem>
            <MenuItem value="Permits and licenses">Permits and licenses</MenuItem>
          </Select>
        </FormControl>

        <FormControl sx={{ minWidth: 200 }}>
          <InputLabel>Activity</InputLabel>
          <Select value={activityFilter} label="Activity" onChange={(e) => setActivityFilter(e.target.value)}>
            <MenuItem value="">All</MenuItem>
            {audits.map((a) => (
              <MenuItem key={a.id} value={a.activity}>{a.activity}</MenuItem>
            ))}
          </Select>
        </FormControl>

        <Button variant="contained" onClick={() => setIsAddOpen(true)}>
          Add New
        </Button>
      </Box>

      <Box height={500}>
        <DataGrid
          rows={filteredAudits}
          columns={columns}
          pageSize={8}
          rowsPerPageOptions={[5, 10, 20]}
          getRowId={(row) => row.id}
          onRowClick={handleRowClick}
          disableRowSelectionOnClick
        />
      </Box>
    </>
  );
};

export default AuditTable;