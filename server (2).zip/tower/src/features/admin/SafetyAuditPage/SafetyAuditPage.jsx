import React from 'react'
import SafetyAuditPageContainer from './containers/SafetyAuditPageContainer'

const SafetyAuditPage = () => {
  return (
    <SafetyAuditPageContainer/>
  )
}

export default SafetyAuditPage