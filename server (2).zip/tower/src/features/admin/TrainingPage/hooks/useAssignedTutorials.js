import { useQuery } from '@tanstack/react-query';
import safetyAssignmentTutorialService from '../services/safetyAssignmentTutorial';

export const useAssignedTutorials = () => {
  return useQuery({
    queryKey: ['assignedTutorials'],
    queryFn: safetyAssignmentTutorialService.getAssignments,
    staleTime: 0,
  });
};
