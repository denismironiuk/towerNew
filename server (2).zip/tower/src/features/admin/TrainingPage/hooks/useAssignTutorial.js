// hooks/useAssignTutorial.js
import { useMutation, useQueryClient } from '@tanstack/react-query';
import safetyAssignmentTutorialService from '../services/safetyAssignmentTutorial';

export const useAssignTutorial = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: safetyAssignmentTutorialService.assignTutorial,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['assignedTutorials'] });
    },
  });
};
