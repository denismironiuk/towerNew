import { useQuery,useMutation, useQueryClient } from "@tanstack/react-query";
import trainingService from "../services/sefetyTrainingService"; // Adjust path if needed

export const useSafetyTrainings = () => {
  return useQuery({
    queryKey: ['safetyTrainings'],
    queryFn: () => trainingService.fetchTutorials(),
    staleTime: 0, // Optional: cache for 5 minutes
    refetchOnWindowFocus: true,
  });
};

export const useCreateTutorial = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (newTutorial) => trainingService.createTutorial(newTutorial),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['safetyTrainings'] });
    },
    onError: (error) => {
      console.error("Create tutorial failed:", error);
    },
  });
};

  export const useSafetyTrainingsEmployees = () => {
    return useQuery({
      queryKey: ['safetyTrainingsEmployees'],
      queryFn:  () => trainingService.getSubordinates(),
      staleTime: 5 * 60 * 1000, // Optional: cache for 5 minutes
      retry: 1, // Optional: number of retries on failure
    });
  };

  export const useEditTutorial = () => {
    const queryClient = useQueryClient();
  
    return useMutation({
      mutationFn: ({ id, data }) => trainingService.updateTutorial(id, data),
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: ['safetyTrainings'] });
      },
      onError: (error) => {
        console.error("Edit tutorial failed:", error);
      },
    });
  };
  