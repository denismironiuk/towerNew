import React from 'react'
import TrainingsList from '../components/Tutorials/TrainingsList';

const AvailabelTrainingsPage = () => {
  
  return (
   <TrainingsList
   
   />
  )
}

export default AvailabelTrainingsPage