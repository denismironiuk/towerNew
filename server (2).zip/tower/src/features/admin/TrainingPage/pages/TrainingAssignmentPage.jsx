import React from 'react'
import TutorialAssignmentList from '../components/TutorialAssignment/TutorialAssignmentList'

const TrainingAssignmentPage = () => {
  return (
 <TutorialAssignmentList/>
  )
}

export default TrainingAssignmentPage