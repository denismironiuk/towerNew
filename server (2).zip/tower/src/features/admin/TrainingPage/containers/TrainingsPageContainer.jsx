import React from 'react';
import { NavLink } from 'react-router-dom';

const linkStyle = {
  padding: '8px 16px',
  textDecoration: 'none',
  fontWeight: 'bold',
  color: '#333',
};

const activeStyle = {
  borderBottom: '2px solid grey',
};

const TrainingsPageContainer = () => {
  return (
    <div
      style={{
        display: 'flex',
        gap: '1rem',
        justifyContent: 'space-around',
        alignItems: 'center',
        maxWidth: '1200px',
        margin: '0 auto',
        padding: '1rem 0.5rem',
      }}
    >
      <NavLink
        to=""
        end
        style={({ isActive }) =>
          isActive ? { ...linkStyle, ...activeStyle } : linkStyle
        }
      >
        List workers
      </NavLink>
      <NavLink
        to="list"
        style={({ isActive }) =>
          isActive ? { ...linkStyle, ...activeStyle } : linkStyle
        }
      >
        List trainings
      </NavLink>
    </div>
  );
};

export default TrainingsPageContainer;
