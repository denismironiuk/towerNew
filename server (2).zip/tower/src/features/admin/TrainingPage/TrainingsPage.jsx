import React from 'react'
import TrainingsPageContainer from './containers/TrainingsPageContainer'
import { Outlet } from 'react-router-dom'

const TrainingsPage = () => {
  return (
    <>
    <TrainingsPageContainer/>
    <Outlet/>
    </>
    
  )
}

export default TrainingsPage