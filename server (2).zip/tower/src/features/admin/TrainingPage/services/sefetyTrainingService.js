import axiosInstance from "../../../../utils/axiosConfig";

const trainingService = {
  fetchTutorials: async () => {
    const response = await axiosInstance.get("/tutorials");
    return response.data;
  },

  fetchTutorialById: async (id) => {
    const response = await axiosInstance.get(`/tutorials/${id}`);
    return response.data;
  },

  createTutorial: async (data) => {
    const response = await axiosInstance.post("/tutorials", data);
    return response.data;
  },

  updateTutorial: async (id, data) => {
    const response = await axiosInstance.put(`/tutorials/${id}`, data);
    return response.data;
  },

  deleteTutorial: async (id) => {
    const response = await axiosInstance.delete(`/tutorials/${id}`);
    return response.data;
  },
  getSubordinates:async() =>{
    const response =await axiosInstance.get(`/users/workersByRole`);
    return response.data || [];
  }
};



export default trainingService;
