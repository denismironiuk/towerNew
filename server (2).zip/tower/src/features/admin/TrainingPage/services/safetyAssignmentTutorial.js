import axiosInstance from "../../../../utils/axiosConfig";

const safetyAssignmentTutorialService = {
  getAssignments: async () => {
    const response = await axiosInstance.get('/user-tutorials');
    return response.data;
  },

  assignTutorial: async (data) => {
    const response = await axiosInstance.post('/user-tutorials/assign', data);
    return response.data;
  },
};

export default safetyAssignmentTutorialService;
