import React, { useState } from 'react';
import { Box, Button, Typography } from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import { useSafetyTrainingsEmployees,useCreateTutorial,useEditTutorial, useSafetyTrainings } from '../../hooks/useSafetyTrainings';
import TutorialDialog from './TutorialDialog';
import AssignDialog from './AssignDialog';
import TutorialTable from './TutorialTable';

const TutorialsList = () => {
  const { data: tutorials, isLoading } = useSafetyTrainings();
  const { data: workers } = useSafetyTrainingsEmployees();

  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingTutorial, setEditingTutorial] = useState(null);
  const [assignDialogOpen, setAssignDialogOpen] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState(null);
  const [selectedTutorial, setSelectedTutorial] = useState(null);

  const { mutate: createTutorial } = useCreateTutorial();
  const { mutate: editTutorial } = useEditTutorial();

  const handleEditClick = (tutorial) => {
    setEditingTutorial(tutorial);
    setIsDialogOpen(true);
  };

  const handleAddClick = () => {
    setEditingTutorial({ name: '', description: '', duration: '' });
    setIsDialogOpen(true);
  };

  const handleSave = () => {
    if (editingTutorial.id) {
      editTutorial(
        {
          id: editingTutorial.id,
          data: {
            name: editingTutorial.name,
            description: editingTutorial.description,
            duration: editingTutorial.duration,
          },
        },
        {
          onSuccess: () => {
            setIsDialogOpen(false);
            setEditingTutorial(null);
          },
        }
      );
    } else {
      createTutorial(editingTutorial, {
        onSuccess: () => {
          setIsDialogOpen(false);
          setEditingTutorial(null);
        },
      });
    }
  };

  // const handleAssignSubmit = () => {
  //   if (selectedEmployee && selectedTutorial) {
  //     console.log(`Assign tutorial ${selectedTutorial.id} to ${selectedEmployee.id}`);
  //     setAssignDialogOpen(false);
  //   }
  // };

  return (
    <Box p={2} mb={2}>
      <Box display="flex" justifyContent="space-between" alignItems="center" p={2} mb={2}>
        <Typography variant="h5">Available Trainings</Typography>
        <Box display="flex" gap={2}>
          <Button variant="contained" startIcon={<AddIcon />} onClick={handleAddClick}>
            Add New
          </Button>
          {/* <Button variant="outlined" color="secondary" onClick={() => setAssignDialogOpen(true)}>
            Assign Tutorial
          </Button> */}
        </Box>
      </Box>

      <TutorialTable rows={tutorials || []} onEditClick={handleEditClick} />

      <TutorialDialog
        open={isDialogOpen}
        tutorial={editingTutorial}
        onClose={() => setIsDialogOpen(false)}
        onChange={setEditingTutorial}
        onSave={handleSave}
      />

      {/* <AssignDialog
        open={assignDialogOpen}
        onClose={() => setAssignDialogOpen(false)}
        onSubmit={handleAssignSubmit}
        employees={workers}
        tutorials={tutorials || []}
        selectedEmployee={selectedEmployee}
        setSelectedEmployee={setSelectedEmployee}
        selectedTutorial={selectedTutorial}
        setSelectedTutorial={setSelectedTutorial}
      /> */}
    </Box>
  );
};


export default TutorialsList;
