import React from 'react';
import { DataGrid, GridToolbarExport } from '@mui/x-data-grid';
import { Stack, IconButton, Tooltip } from '@mui/material';
import EditIcon from '@mui/icons-material/Edit';

const TutorialTable = ({ rows, onEditClick }) => {
  const columns = [
    { field: 'id', headerName: 'ID', width: 90 },
    { field: 'name', headerName: 'Title', flex: 1 },
    { field: 'description', headerName: 'Description', flex: 2 },
    {
      field: 'createdAt',
      headerName: 'Created At',
      width: 180,
      valueFormatter: (params) =>
        params ? new Date(params).toLocaleString() : '',
    },
    {
      field: 'actions',
      headerName: 'Actions',
      width: 160,
      renderCell: (params) => (
        <Stack direction="row" spacing={1}>
          <Tooltip title="Edit">
            <IconButton onClick={() => onEditClick(params.row)}>
              <EditIcon />
            </IconButton>
          </Tooltip>
        </Stack>
      ),
    },
  ];

  return (
    <DataGrid
      rows={rows}
      columns={columns}
      pageSize={5}
      autoHeight
      getRowId={(row) => row.id}
      components={{ Toolbar: GridToolbarExport }}
      sx={{
        '& .MuiDataGrid-cell:focus': { outline: 'none' },
        '& .MuiTypography-root': { fontSize: 14 },
      }}
    />
  );
};

export default TutorialTable;
