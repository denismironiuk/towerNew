import React from 'react';
import {
  Dialog, DialogTitle, DialogContent, DialogActions,
  Button, Autocomplete, TextField, Stack, Box
} from '@mui/material';

const AssignDialog = ({
  open, onClose, onSubmit, employees, tutorials,
  selectedEmployee, setSelectedEmployee,
  selectedTutorial, setSelectedTutorial
}) => (
  <Dialog open={open} onClose={onClose} PaperProps={{ sx: { width: '500px' } }}>
    <DialogTitle>Assign Tutorial to Employee</DialogTitle>
    <DialogContent sx={{ pt: 2 }}>
      <Stack spacing={4}>
        <Box p={2} display="flex" flexDirection="column" gap={2}>
          <Autocomplete
            options={employees || []}
            getOptionLabel={(option) => `${option.name} (${option.employee_number})`}
            value={selectedEmployee}
            onChange={(e, val) => setSelectedEmployee(val)}
            renderInput={(params) => <TextField {...params} label="Select Employee" fullWidth />}
          />
          <Autocomplete
            options={tutorials}
            getOptionLabel={(option) => `${option.name} (ID: ${option.id})`}
            value={selectedTutorial}
            onChange={(e, val) => setSelectedTutorial(val)}
            renderInput={(params) => <TextField {...params} label="Select Tutorial" fullWidth />}
          />
        </Box>
      </Stack>
    </DialogContent>
    <DialogActions>
      <Button onClick={onClose}>Cancel</Button>
      <Button
        variant="contained"
        onClick={onSubmit}
        disabled={!selectedEmployee || !selectedTutorial}
      >
        Assign
      </Button>
    </DialogActions>
  </Dialog>
);

export default AssignDialog;
