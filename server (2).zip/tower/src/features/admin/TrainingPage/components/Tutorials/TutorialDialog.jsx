import React from 'react';
import { Dialog, DialogContent, DialogTitle, Button, TextField, Stack, Box } from '@mui/material';

const TutorialDialog = ({ open, tutorial, onClose, onChange, onSave }) => (
  <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
    <DialogTitle>{tutorial?.id ? 'Edit Tutorial' : 'New Tutorial'}</DialogTitle>
    <DialogContent>
      <Stack spacing={2} mt={2}>
        <TextField
          label="Title"
          fullWidth
          value={tutorial?.name || ''}
          onChange={(e) => onChange({ ...tutorial, name: e.target.value })}
        />
        <TextField
          label="Description"
          fullWidth
          multiline
          rows={4}
          value={tutorial?.description || ''}
          onChange={(e) => onChange({ ...tutorial, description: e.target.value })}
        />
      </Stack>
      <Box mt={3} display="flex" justifyContent="flex-end">
        <Button onClick={onClose} sx={{ mr: 1 }}>Cancel</Button>
        <Button variant="contained" onClick={onSave}>Save</Button>
      </Box>
    </DialogContent>
  </Dialog>
);

export default TutorialDialog;
