import React from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  TextField,
  Stack,
  Autocomplete,
  Box,
  Typography,
  MenuItem, Select, InputLabel, FormControl
} from '@mui/material';


const TutorialAssignmentDialog = ({
    open,
    onClose,
    onSubmit,
    employees = [],
    tutorials = [],
    selectedEmployee,
    setSelectedEmployee,
    selectedTutorial,
    setSelectedTutorial,
    lifecycle,
    setLifecycle,
}) => {
  const isTutorialDisabled = !selectedEmployee;

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle>Assign Tutorial</DialogTitle>

      <DialogContent sx={{ pt: 2 }}>
        <Stack spacing={3}>
        <Box p={2} display="flex" flexDirection="column" gap={2}>
          <Autocomplete
            options={employees}
            getOptionLabel={(option) =>
              `${option.name} (${option.employee_number})`
            }
            value={selectedEmployee}
            onChange={(e, value) => {
              setSelectedEmployee(value);
              setSelectedTutorial(null); // Reset tutorial when employee changes
            }}
            renderInput={(params) => (
              <TextField {...params} label="Select Employee" fullWidth />
            )}
          />

          <Autocomplete
            options={tutorials}
            getOptionLabel={(option) => `${option.name} (ID: ${option.id})`}
            value={selectedTutorial}
            onChange={(e, value) => setSelectedTutorial(value)}
            renderInput={(params) => (
              <TextField
                {...params}
                label="Select Tutorial"
                fullWidth
                disabled={isTutorialDisabled}
              />
            )}
            disabled={isTutorialDisabled}
          />
          <FormControl fullWidth>
  <InputLabel id="lifecycle-label">Lifecycle</InputLabel>
  <Select
    labelId="lifecycle-label"
    value={lifecycle || ''}
    label="Lifecycle"
    onChange={(e) => setLifecycle(e.target.value)}
    disabled={!selectedEmployee || !selectedTutorial}
  >
    <MenuItem value={3}>3 Months</MenuItem>
    <MenuItem value={6}>6 Months</MenuItem>
    <MenuItem value={12}>12 Months</MenuItem>
  </Select>
</FormControl>

</Box>
          {selectedEmployee && tutorials.length === 0 && (
            <Box>
              <Typography color="error" fontSize="0.875rem">
                This employee has already been assigned all available tutorials.
              </Typography>
            </Box>
          )}
        </Stack>
      </DialogContent>

      <DialogActions>
        <Button onClick={onClose}>Cancel</Button>
        <Button
          variant="contained"
          onClick={onSubmit}
          disabled={
            !selectedEmployee || !selectedTutorial || tutorials.length === 0
          }
        >
          Assign
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default TutorialAssignmentDialog;
