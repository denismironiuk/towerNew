import React, { useState } from 'react';
import { Box, Button,TextField } from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import { useAssignedTutorials } from '../../hooks/useAssignedTutorials';
import { useSafetyTrainingsEmployees, useSafetyTrainings } from '../../hooks/useSafetyTrainings';
import dayjs from 'dayjs';
import TutorialAssignmentTable from './TutorialAssignmentTable';
import TutorialAssignmentDialog from './TutorialAssignmentDialog';
import { useAssignTutorial } from '../../hooks/useAssignTutorial';

const 
TutorialAssignmentList = () => {
  const { data = [], isLoading } = useAssignedTutorials();
  const { data: workers = [] } = useSafetyTrainingsEmployees();
  const { data: tutorials = [] } = useSafetyTrainings();
  const { mutate: assignTutorial } = useAssignTutorial();
  // Dialog state
  const [assignDialogOpen, setAssignDialogOpen] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState(null);

  const [selectedTutorial, setSelectedTutorial] = useState(null);
  const [lifecycle, setLifecycle] = useState(null);
  const [filterEmployeeId, setFilterEmployeeId] = useState('');
  const [filterEmployeeName, setFilterEmployeeName] = useState('');

  const handleAssignSubmit = () => {
    if (!selectedEmployee || !selectedTutorial || !lifecycle) return;
  
    const validUntil = dayjs().add(Number(lifecycle), 'month').toDate();
  
    assignTutorial(
      {
        employee_number: selectedEmployee.employee_number,
        tutorial_id: selectedTutorial.id,
        valid_until: validUntil,
      },
      {
        onSuccess: () => {
          setAssignDialogOpen(false);
          setSelectedEmployee(null);
          setSelectedTutorial(null);
          setLifecycle(null);
        },
        onError: (err) => {
          console.error('Failed to assign tutorial:', err);
          alert('Failed to assign. Please try again.');
        },
      }
    );
  };
  
  
  
  const assignedTutorialIds = data
  .filter(item => item.employee_number === selectedEmployee?.employee_number)
  .map(item => item.tutorial_id);

const filteredTutorials = tutorials.filter(
  t => !assignedTutorialIds.includes(t.id)
);

// const filteredRows = selectedEmployeeFilter
//   ? data.filter(
//       row => row.employee_number === selectedEmployeeFilter.employee_number
//     )
//   : data;
const filteredRows = data.filter((row) => {
  const matchesId = row.employee_number.toLowerCase().includes(filterEmployeeId.toLowerCase());
  const matchesName = row.employee_name.toLowerCase().includes(filterEmployeeName.toLowerCase());
  return matchesId && matchesName;
});
  return (
    <Box p={2} mb={2}>
      <Box display="flex" justifyContent="space-between" alignItems="center" p={2} mb={2}>
        
      <Box display="flex" gap={2} mb={2}>
  <TextField
    label="Filter by Employee ID"
    variant="outlined"
    size="small"
    value={filterEmployeeId}
    onChange={(e) => setFilterEmployeeId(e.target.value)}
  />
  <TextField
    label="Filter by Employee Name"
    variant="outlined"
    size="small"
    value={filterEmployeeName}
    onChange={(e) => setFilterEmployeeName(e.target.value)}
  />
</Box>


        <Button
          variant="contained"
          startIcon={<AddIcon />}
          onClick={() => setAssignDialogOpen(true)}
        >
          Add New
        </Button>
      </Box>

      <TutorialAssignmentTable rows={filteredRows} loading={isLoading} />

      <TutorialAssignmentDialog
  open={assignDialogOpen}
  onClose={() => setAssignDialogOpen(false)}
  onSubmit={handleAssignSubmit}
  employees={workers}
  tutorials={filteredTutorials} // ✅ filtered based on selectedEmployee
  selectedEmployee={selectedEmployee}
  setSelectedEmployee={setSelectedEmployee}
  selectedTutorial={selectedTutorial}
  setSelectedTutorial={setSelectedTutorial}
  lifecycle={lifecycle}
  setLifecycle={setLifecycle}
/>

    </Box>
  );
};

export default TutorialAssignmentList;
