import React from 'react'
import DoweSafetyWalkContainer from './containers/DoweSafetyWalkContainer'
import { Outlet } from 'react-router-dom'

const DoWeSafetyWalkPage = () => {
  return (
    <>
    <DoweSafetyWalkContainer/>
    <Outlet/>
    </>
   
  )
}

export default DoWeSafetyWalkPage