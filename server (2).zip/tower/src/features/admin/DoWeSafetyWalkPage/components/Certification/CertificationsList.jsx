import React, { useState } from 'react';
import { Box, Button, Typography } from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import { useSafetyCertificationsEmployees,useCreateCertification,useEditCertification,useSafetyCertifications } from '../../hooks/useSafetyCertification';
import CertificationDialog from './CertificationDialog';
import AssignCertificationDialog from './AssignCertificationDialog';
import CertificationTable from './CertificationTable';

const CertificationsList = () => {
  const { data: certifications, isLoading } = useSafetyCertifications();
  const { data: workers } = useSafetyCertificationsEmployees();
console.log(workers)
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingCertification, setEditingCertification] = useState(null);
  const [assignDialogOpen, setAssignDialogOpen] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState(null);
  const [selectedCertification, setSelectedCertification] = useState(null);

  const { mutate: createCertification } = useCreateCertification();
  const { mutate: editCertification } = useEditCertification();

  const handleEditClick = (cert) => {
    setEditingCertification(cert);
    setIsDialogOpen(true);
  };

  const handleAddClick = () => {
    setEditingCertification({ name: '', description: '' });
    setIsDialogOpen(true);
  };

  const handleSave = () => {
    if (editingCertification.id) {
      editCertification(
        { 
          id: editingCertification.id, 
          data:  {
            name: editingCertification.name,
            description: editingCertification.description,
          }
        },
        { onSuccess: () => { setIsDialogOpen(false); setEditingCertification(null); } }
      );
    } else {
      createCertification(editingCertification, {
        onSuccess: () => {
          setIsDialogOpen(false);
          setEditingCertification(null);
        },
      });
    }
  };

  return (
    <Box p={2} mb={2}>
      <Box display="flex" justifyContent="space-between" alignItems="center" p={2} mb={2}>
        <Typography variant="h5">Available Certifications</Typography>
        <Box display="flex" gap={2}>
          <Button variant="contained" startIcon={<AddIcon />} onClick={handleAddClick}>
            Add New
          </Button>
          {/* <Button variant="outlined" onClick={() => setAssignDialogOpen(true)}>
            Assign Certification
          </Button> */}
        </Box>
      </Box>

      <CertificationTable rows={certifications || []} onEditClick={handleEditClick} />

      <CertificationDialog
        open={isDialogOpen}
        certification={editingCertification}
        onClose={() => setIsDialogOpen(false)}
        onChange={setEditingCertification}
        onSave={handleSave}
      />

      {/* <AssignCertificationDialog
        open={assignDialogOpen}
        onClose={() => setAssignDialogOpen(false)}
        onSubmit={() => {
          console.log(`Assign cert ${selectedCertification.id} to ${selectedEmployee.employee_number}`);
          setAssignDialogOpen(false);
        }}
        employees={workers}
        certifications={certifications || []}
        selectedEmployee={selectedEmployee}
        setSelectedEmployee={setSelectedEmployee}
        selectedCertification={selectedCertification}
        setSelectedCertification={setSelectedCertification}
      /> */}
    </Box>
  );
};

export default CertificationsList;
