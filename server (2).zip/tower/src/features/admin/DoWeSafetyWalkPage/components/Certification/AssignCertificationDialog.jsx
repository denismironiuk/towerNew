import React from 'react';
import {
  Dialog, DialogTitle, DialogContent, DialogActions,
  Button, Autocomplete, TextField, Stack, Box
} from '@mui/material';

const AssignCertificationDialog = ({
  open, onClose, onSubmit, employees, certifications,
  selectedEmployee, setSelectedEmployee,
  selectedCertification, setSelectedCertification
}) => (
  <Dialog open={open} onClose={onClose} PaperProps={{ sx: { width: '500px' } }}>
    <DialogTitle>Assign Certification to Employee</DialogTitle>
    <DialogContent sx={{ pt: 2 }}>
      <Stack spacing={4}>
        <Box p={2} display="flex" flexDirection="column" gap={2}>
          <Autocomplete
            options={employees || []}
            getOptionLabel={(option) => `${option.name} (${option.employee_number})`}
            value={selectedEmployee}
            onChange={(e, val) => setSelectedEmployee(val)}
            renderInput={(params) => <TextField {...params} label="Select Employee" fullWidth />}
          />
          <Autocomplete
            options={certifications}
            getOptionLabel={(option) => `${option.name} (ID: ${option.id})`}
            value={selectedCertification}
            onChange={(e, val) => setSelectedCertification(val)}
            renderInput={(params) => <TextField {...params} label="Select Certification" fullWidth />}
          />
        </Box>
      </Stack>
    </DialogContent>
    <DialogActions>
      <Button onClick={onClose}>Cancel</Button>
      <Button
        variant="contained"
        onClick={onSubmit}
        disabled={!selectedEmployee || !selectedCertification}
      >
        Assign
      </Button>
    </DialogActions>
  </Dialog>
);

export default AssignCertificationDialog;
