import React from 'react';
import { Dialog, DialogTitle, DialogContent, TextField, Stack, Box, Button } from '@mui/material';

const CertificationDialog = ({ open, certification, onClose, onChange, onSave }) => (
  <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
    <DialogTitle>{certification?.id ? 'Edit Certification' : 'New Certification'}</DialogTitle>
    <DialogContent>
      <Stack spacing={2} mt={2}>
        <TextField
          label="Name"
          fullWidth
          value={certification?.name || ''}
          onChange={(e) => onChange({ ...certification, name: e.target.value })}
        />
        <TextField
          label="Description"
          fullWidth
          multiline
         
          rows={4}
          value={certification?.description || ''}
          onChange={(e) => onChange({ ...certification, description: e.target.value })}
        />
      </Stack>
      <Box mt={3} display="flex" justifyContent="flex-end">
        <Button onClick={onClose} sx={{ mr: 1 }}>Cancel</Button>
        <Button variant="contained" onClick={onSave}>Save</Button>
      </Box>
    </DialogContent>
  </Dialog>
);

export default CertificationDialog;
