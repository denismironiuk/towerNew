import React from 'react';
import { DataGrid } from '@mui/x-data-grid';

const CertificationAssignmentTable = ({ rows = [], loading }) => {
  const columns = [
    { field: 'id', headerName: 'ID', width: 100 },
    { field: 'employee_name', headerName: 'Name', flex: 1 },
    { field: 'employee_number', headerName: 'Employee ID', width: 150 },
    { field: 'department', headerName: 'Department', width: 130 },
    { field: 'company', headerName: 'Company', width: 130 },
    { field: 'certification_name', headerName: 'Certification', flex: 1.5 },
    {
      field: 'valid_until',
      headerName: 'Expiration Date',
      width: 140,
      valueFormatter: (params) =>
        params ? new Date(params).toLocaleString() : '',
    },
  ];

  return (
    <DataGrid
      rows={rows}
      columns={columns}
      loading={loading}
      autoHeight
      getRowId={(row) => row.id}
      pageSize={10}
      rowsPerPageOptions={[10, 20, 50]}
      sx={{
        '& .MuiDataGrid-columnHeaders': {
          backgroundColor: '#f3f4f6',
          fontWeight: 'bold',
        },
        '& .MuiDataGrid-cell:focus': { outline: 'none' },
      }}
    />
  );
};

export default CertificationAssignmentTable;
