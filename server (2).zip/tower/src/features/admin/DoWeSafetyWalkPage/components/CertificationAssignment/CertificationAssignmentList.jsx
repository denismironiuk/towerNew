import React, { useState } from 'react';
import { Box, Button, TextField } from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import { useAssignedCertifications} from '../../hooks/usedAssignedCertifications';
import { useSafetyCertificationsEmployees, useSafetyCertifications } from '../../hooks/useSafetyCertification';
import CertificationAssignmentDialog from './CertificationAssignmentDialog';
import CertificationAssignmentTable from './CertificationAssignmentTable';
import { useAssignCertification } from '../../hooks/useAssignCertification';
import dayjs from 'dayjs';

const CertificationAssignmentList = () => {
  const { data = [], isLoading } = useAssignedCertifications();
  const { data: workers = [] } = useSafetyCertificationsEmployees();
  const { data: certifications = [] } = useSafetyCertifications();
  const { mutate: assignCertification } = useAssignCertification();

  const [assignDialogOpen, setAssignDialogOpen] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState(null);
  const [selectedCertification, setSelectedCertification] = useState(null);
  const [lifecycle, setLifecycle] = useState(null);
  const [filterEmployeeId, setFilterEmployeeId] = useState('');
  const [filterEmployeeName, setFilterEmployeeName] = useState('');
console.log(data)
  const handleAssignSubmit = () => {
    if (!selectedEmployee || !selectedCertification || !lifecycle) return;

    const validUntil = dayjs().add(Number(lifecycle), 'month').toDate();

    assignCertification(
      {
        user_number: selectedEmployee.employee_number,
        certification_id: selectedCertification.id,
        valid_until: validUntil,
      },
      {
        onSuccess: () => {
          setAssignDialogOpen(false);
          setSelectedEmployee(null);
          setSelectedCertification(null);
          setLifecycle(null);
        },
        onError: (err) => {
          console.error('Failed to assign certification:', err);
          alert('Assignment failed. Try again.');
        },
      }
    );
  };

  const assignedCertificationIds = data
    .filter(item => item.employee_number === selectedEmployee?.employee_number)
    .map(item => item.certification_id);

  const filteredCertifications = certifications.filter(
    cert => !assignedCertificationIds.includes(cert.id)
  );

  const filteredRows = data.filter((row) => {
    console.log(row)
    const matchesId = row.employee_number?.toLowerCase().includes(filterEmployeeId.toLowerCase());
    const matchesName = row.employee_name?.toLowerCase().includes(filterEmployeeName.toLowerCase());
    return matchesId && matchesName;
  });

  return (
    <Box p={2} mb={2}>
      <Box display="flex" justifyContent="space-between" alignItems="center" p={2} mb={2}>
        <Box display="flex" gap={2}>
          <TextField
            label="Filter by Employee ID"
            size="small"
            value={filterEmployeeId}
            onChange={(e) => setFilterEmployeeId(e.target.value)}
          />
          <TextField
            label="Filter by Name"
            size="small"
            value={filterEmployeeName}
            onChange={(e) => setFilterEmployeeName(e.target.value)}
          />
        </Box>

        <Button variant="contained" startIcon={<AddIcon />} onClick={() => setAssignDialogOpen(true)}>
          Add New
        </Button>
      </Box>

      <CertificationAssignmentTable rows={filteredRows} loading={isLoading} />

      <CertificationAssignmentDialog
        open={assignDialogOpen}
        onClose={() => setAssignDialogOpen(false)}
        onSubmit={handleAssignSubmit}
        employees={workers}
        certifications={filteredCertifications}
        selectedEmployee={selectedEmployee}
        setSelectedEmployee={setSelectedEmployee}
        selectedCertification={selectedCertification}
        setSelectedCertification={setSelectedCertification}
        lifecycle={lifecycle}
        setLifecycle={setLifecycle}
      />
    </Box>
  );
};

export default CertificationAssignmentList;
