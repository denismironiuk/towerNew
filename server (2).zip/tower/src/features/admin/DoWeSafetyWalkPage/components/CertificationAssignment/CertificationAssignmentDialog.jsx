import React from 'react';
import {
  Dialog, DialogTitle, DialogContent, DialogActions, Button,
  TextField, Stack, Autocomplete, Box, Typography, FormControl,
  InputLabel, Select, MenuItem
} from '@mui/material';

const CertificationAssignmentDialog = ({
  open,
  onClose,
  onSubmit,
  employees,
  certifications,
  selectedEmployee,
  setSelectedEmployee,
  selectedCertification,
  setSelectedCertification,
  lifecycle,
  setLifecycle,
}) => {
  const isDisabled = !selectedEmployee;

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle>Assign Certification</DialogTitle>
      <DialogContent sx={{ pt: 2 }}>
        <Stack spacing={3}>
          <Box display="flex" flexDirection="column" gap={2}>
            <Autocomplete
              options={employees}
              getOptionLabel={(option) => `${option.name} (${option.employee_number})`}
              value={selectedEmployee}
              onChange={(e, val) => {
                setSelectedEmployee(val);
                setSelectedCertification(null);
              }}
              renderInput={(params) => <TextField {...params} label="Select Employee" fullWidth />}
            />
            <Autocomplete
              options={certifications}
              getOptionLabel={(option) => `${option.name} (ID: ${option.id})`}
              value={selectedCertification}
              onChange={(e, val) => setSelectedCertification(val)}
              renderInput={(params) => (
                <TextField {...params} label="Select Certification" fullWidth disabled={isDisabled} />
              )}
              disabled={isDisabled}
            />
            <FormControl fullWidth>
              <InputLabel id="lifecycle-label">Lifecycle</InputLabel>
              <Select
                labelId="lifecycle-label"
                value={lifecycle || ''}
                label="Lifecycle"
                onChange={(e) => setLifecycle(e.target.value)}
                disabled={!selectedEmployee || !selectedCertification}
              >
                <MenuItem value={3}>3 Months</MenuItem>
                <MenuItem value={6}>6 Months</MenuItem>
                <MenuItem value={12}>12 Months</MenuItem>
              </Select>
            </FormControl>
          </Box>

          {selectedEmployee && certifications.length === 0 && (
            <Typography color="error" fontSize="0.875rem">
              This employee has already been assigned all available certifications.
            </Typography>
          )}
        </Stack>
      </DialogContent>

      <DialogActions>
        <Button onClick={onClose}>Cancel</Button>
        <Button variant="contained" onClick={onSubmit} disabled={!selectedEmployee || !selectedCertification}>
          Assign
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default CertificationAssignmentDialog;
