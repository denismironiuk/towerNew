import axiosInstance from "../../../../utils/axiosConfig";

const safetyAssignmentCertificationService={
    getAssignments: async () => {
        const response = await axiosInstance.get('/user-certifications');
        return response.data;
},
assignCertification: async (data) => {
    const response = await axiosInstance.post('/user-certifications/assign', data);
    return response.data;
  },
}

export default safetyAssignmentCertificationService