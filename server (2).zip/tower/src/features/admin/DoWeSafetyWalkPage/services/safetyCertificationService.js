import axiosInstance from "../../../../utils/axiosConfig";

const CertificationService={
    fetchCertifications: async () => {
      console.log("📥 axios GET /certifications"); // ADD THIS
        const response = await axiosInstance.get("/certifications");
        return response.data;
      },
    
      fetchCertificationById: async (id) => {
        const response = await axiosInstance.get(`/certifications/${id}`);
        return response.data;
      },
    
      createCertification: async (data) => {
        const response = await axiosInstance.post("/certifications", data);
        return response.data;
      },
    
      updateCertification: async (id, data) => {
        const response = await axiosInstance.put(`/certifications/${id}`, data);
        return response.data;
      },
    
      deleteCertification: async (id) => {
        const response = await axiosInstance.delete(`/certifications/${id}`);
        return response.data;
      },
      getSubordinates:async() =>{
        const response =await axiosInstance.get(`/users/workersByRole`);
        return response.data || [];
      }
}

export default CertificationService