import React from 'react'
import CertificationAssignmentList from '../components/CertificationAssignment/CertificationAssignmentList'

const CertificationAssignmentPage = () => {
  return (
    <CertificationAssignmentList/>
  )
}

export default CertificationAssignmentPage