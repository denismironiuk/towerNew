import React from 'react'
import CertificationsList from '../components/Certification/CertificationsList'

const AvailableCertificationsPage = () => {
  return (
   <CertificationsList/>
  )
}

export default AvailableCertificationsPage