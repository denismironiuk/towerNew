import { useQuery,useMutation, useQueryClient } from "@tanstack/react-query";
import CertificationService from "../services/safetyCertificationService"; // Adjust path if needed

export const useSafetyCertifications = () => {
    console.log("✅ Hook: useSafetyCertifications called"); // ADD THIS
  
    return useQuery({
      queryKey: ['safetyCertifications'],
      queryFn: () => {
        console.log("📡 Fetching certifications...");
        return CertificationService.fetchCertifications();
      },
      staleTime: 0,
      refetchOnWindowFocus: true,
    });
  };

export const useCreateCertification = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (newCertification) => CertificationService.createCertification(newCertification),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['safetyCertifications'] });
    },
    onError: (error) => {
      console.error("Create cerificate failed:", error);
    },
  });
};

  export const useSafetyCertificationsEmployees = () => {
    return useQuery({
      queryKey: ['safetyCertificationsEmployees'],
      queryFn:  () => CertificationService.getSubordinates(),
      staleTime: 5 * 60 * 1000, // Optional: cache for 5 minutes
      retry: 1, // Optional: number of retries on failure
    });
  };

  export const useEditCertification = () => {
    const queryClient = useQueryClient();
  
    return useMutation({
      mutationFn: ({ id, data }) => CertificationService.updateCertification(id, data),
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: ['safetyCertifications'] });
      },
      onError: (error) => {
        console.error("Edit certification failed:", error);
      },
    });
  };
  