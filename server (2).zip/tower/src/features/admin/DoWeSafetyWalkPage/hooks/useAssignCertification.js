import { useMutation, useQueryClient } from '@tanstack/react-query';
import safetyAssignmentCertificationService from '../services/safetyAssignmentCertification';
export const useAssignCertification = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: safetyAssignmentCertificationService.assignCertification,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['assignedCertifications'] });
    },
  });
};