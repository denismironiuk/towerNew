import {useQuery} from '@tanstack/react-query'
import safetyAssignmentCertificationService from '../services/safetyAssignmentCertification'

export const useAssignedCertifications = () => {
    return useQuery({
      queryKey: ['assignedCertifications'],
      queryFn: safetyAssignmentCertificationService.getAssignments,
      staleTime: 0,
    });
  };
  