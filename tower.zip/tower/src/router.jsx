import { createBrowserRouter, Navigate } from "react-router-dom";
import { lazy, Suspense } from "react";
import ProtectedRoute from "./components/protected/ProtectedRoute";
import NotFound from "./pages/NotFound"; // ✅ Import 404 page
import AuthRedirect from "./components/protected/AuthRedirect";

const Authentication = lazy(() => import("./components/Authentication"));
const Dashboard = lazy(() => import("./pages/EhsDashboard"));
const SafetyWalkAround = lazy(() => import("./pages/SafetyWalkAround"));
const Profile = lazy(() => import("./pages/Profile")); // ✅ Ensure lazy loading

// ✅ Centralized loading component
const LoadingScreen = <div className="loading-screen">Loading...</div>;

const router = createBrowserRouter([
  { path: "/", element: <Navigate to="/login" /> },
  {
    path: "/login",
    element: (
      <Suspense fallback={<div>Loading...</div>}>
        <AuthRedirect>
          <Authentication />
        </AuthRedirect>
      </Suspense>
    ),
  },
  
  {
    path: "/dashboard",
    element: (
      <ProtectedRoute allowedRoles={["admin"]}>
        <Suspense fallback={LoadingScreen}>
          <Dashboard />
        </Suspense>
      </ProtectedRoute>
    ),
  },
  {
    path: "/profile",
    element: (
      <ProtectedRoute allowedRoles={["SAM", "user"]}>
        <Suspense fallback={LoadingScreen}>
          <Profile />
        </Suspense>
      </ProtectedRoute>
    ),
  },
  {
    path: "/safety-walk-around",
    element: (
      <ProtectedRoute allowedRoles={["admin", "SAM","user"]}>
        <Suspense fallback={LoadingScreen}>
          <SafetyWalkAround />
        </Suspense>
      </ProtectedRoute>
    ),
  },
  // ✅ 404 - Not Found Route
  {
    path: "*",
    element: <NotFound />, // Redirects unknown routes to a custom 404 page
  },
]);

export default router;
