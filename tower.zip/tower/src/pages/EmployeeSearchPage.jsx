import React, { useState, useEffect } from "react";

import styles from "./EmployeeSearch.module.css";
import EmployeeTable from "../components/EmployeesList/EmployeeTable";
import SearchBar from "../components/EmployeesList/SearchBar";
import Navbar from "../components/SafetyWalkAround/Navbar";

const dummyEmployees = [
  { badge: "11328", firstName: "Zion", lastName: "Cohen", jobTitle: "Manager, Test Production", email: "ZIONC@TOWERSEMI.COM" },
  { badge: "14384", firstName: "Moris", lastName: "Helimelech", jobTitle: "Etch GF", email: "MORISHE@TOWERSEMI.COM" },
  { badge: "14897", firstName: "Shlomy", lastName: "Arzony", jobTitle: "Diff/Imp GF", email: "SHLOMIAR@TOWERSEMI.COM" },
  { badge: "14949", firstName: "Hen", lastName: "Ofeck", jobTitle: "TF/CMP GF", email: "HENOF@TOWERSEMI.COM" },
  { badge: "15018", firstName: "Artur", lastName: "Foigelman", jobTitle: "Shift Manager 1", email: "HRTURFO@TOWERSEMI.COM" },
  { badge: "16191", firstName: "Arthur", lastName: "Litvachuk", jobTitle: "Shift Manager 4", email: "ARTHURLI@TOWERSEMI.COM" },
  { badge: "17055", firstName: "Sufian", lastName: "Nijem", jobTitle: "Shift Manager 2", email: "NIJEMSU@TOWERSEMI.COM" },
  { badge: "17260", firstName: "Sahar", lastName: "Difani", jobTitle: "Photo GF", email: "SAHARDIF@TOWERSEMI.COM" },
  { badge: "17753", firstName: "Michel", lastName: "Rozen", jobTitle: "Shift Manager 3", email: "MICHELRO@TOWERSEMI.COM" }
];

const EmployeeSearchPage = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [employees, setEmployees] = useState(dummyEmployees);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const filterEmployees = (employees, searchQuery) =>
    employees.filter(emp =>
      Object.values(emp).some(val =>
        val.toString().toLowerCase().includes(searchQuery.toLowerCase())
      )
    );

  return (
    <div className={styles.container}>
        <Navbar/>
      
      <SearchBar searchQuery={searchQuery} setSearchQuery={setSearchQuery} />
      {loading ? (
        <p>Loading employees...</p>
      ) : error ? (
        <p className={styles.error}>{error}</p>
      ) : (
        <EmployeeTable employees={filterEmployees(employees, searchQuery)} />
      )}
    </div>
  );
};

export default EmployeeSearchPage;
