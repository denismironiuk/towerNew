import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import Navbar from "../components/SafetyWalkAround/Navbar";
import AuditForm from "../components/SafetyWalkAround/AuditForm";
import styles from "./SafetyWalkAround.module.css";

const SafetyWalkAround = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState(() => {
    return JSON.parse(localStorage.getItem("auditData")) || {};
  });

  const handleSave = () => {
    const filteredData = {};

    // ✅ Only include rows where "Follow-Up" is checked
    Object.keys(formData).forEach((sectionId) => {
      const section = formData[sectionId];
      const filteredQuestions = Object.keys(section).reduce((acc, questionId) => {
        if (section[questionId].followUp) {
          acc[questionId] = section[questionId]; // ✅ Only save if followUp is true
        }
        return acc;
      }, {});

      if (Object.keys(filteredQuestions).length > 0) {
        filteredData[sectionId] = filteredQuestions;
      }
    });

    console.log("✅ Submitting Audit Data:", JSON.stringify(filteredData, null, 2)); // ✅ Print final submitted data

    localStorage.removeItem("auditData"); // ✅ Remove saved data
    setFormData({}); // ✅ Reset form state

    alert("Audit submitted successfully! The form has been cleared.");
  };

  return (
    <div className={styles.container}>
      <Navbar />
      
      {/* ✅ Breadcrumb Navigation */}
      <div className={styles.breadcrumb}>
        <div><Link to="/dashboard">Home</Link> &gt; <span>Create Audit</span></div> 
        <div className={styles.auditActions}>
          <button className={styles.save} onClick={handleSave}>Save</button>
          <button className={styles.exit} onClick={() => navigate("/profile")}>Exit</button>
        </div>
      </div>

      {/* ✅ Pass state & update function to AuditForm */}
      <AuditForm formData={formData} setFormData={setFormData} />
    </div>
  );
};

export default SafetyWalkAround;
