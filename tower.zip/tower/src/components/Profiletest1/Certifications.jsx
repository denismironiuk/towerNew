import React from "react";
import styles from "./Certifications.module.css";

const Certifications = () => {
  return (
    <div className={styles.certifications}>
      <h2>Certification</h2>
      <ul>
        <li>Centura Poly <span>22/11/2025</span></li>
        <li>Centura Metal <span>02/06/2025</span></li>
        <li>Asher <span>12/02/2025</span></li>
        <li>Metrology <span>12/02/2025</span></li>
      </ul>
    </div>
  );
};

export default Certifications;
