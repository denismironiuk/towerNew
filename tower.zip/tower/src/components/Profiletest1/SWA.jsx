import React from "react";
import styles from "./SWA.module.css";

const SWA = () => {
  return (
    <div className={styles.swa}>
      <h2>SWA</h2>
      <p>Total <span>10</span></p>
      <p>Last <span>12/12/2024</span></p>
    </div>
  );
};

export default SWA;
