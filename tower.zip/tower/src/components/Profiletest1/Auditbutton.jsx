import React from "react";
import styles from "./AuditButton.module.css";

const AuditButton = () => {
  return <button className={styles.auditButton}>New Audit</button>;
};

export default AuditButton;
