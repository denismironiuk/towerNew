import React from "react";
import styles from "./Tutorials.module.css";

const Tutorials = () => {
  return (
    <div className={styles.tutorials}>
      <h2>Tutorials</h2>
      <p style={{textAlign:'start'}}>Safety Training <span>26/05/2025</span></p>
    </div>
  );
};

export default Tutorials;
