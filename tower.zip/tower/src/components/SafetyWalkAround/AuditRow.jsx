import React from "react";
import styles from "./AuditRow.module.css";

const AuditRow = ({ sectionId, questionId, text, example, updateFormData, savedData }) => {
  return (
    <div className={styles.row}>
      <div className={styles.question}>
        <p><strong>{text}</strong></p>
        <p className={styles.example}>{example}</p>
      </div>
      
      {/* ✅ Select Score - Preserves State */}
      <select
        className={styles.select}
        value={savedData?.score || ""}  // ✅ Ensures previous value is shown
        onChange={(e) => updateFormData(sectionId, questionId, "score", e.target.value)}
      >
        <option value="">Select</option>
        <option value="Yes">Yes</option>
        <option value="No">No</option>
        <option value="N/A">N/A</option>
      </select>

      {/* ✅ Issue Found - Preserves State */}
      <input
        type="text"
        className={styles.input}
        placeholder="Describe issue..."
        value={savedData?.issue || ""}  // ✅ Ensures previous value is shown
        onChange={(e) => updateFormData(sectionId, questionId, "issue", e.target.value)}
      />

      {/* ✅ Corrective Actions - Preserves State */}
      <input
        type="text"
        className={styles.input}
        placeholder="Corrective actions..."
        value={savedData?.action || ""}  // ✅ Ensures previous value is shown
        onChange={(e) => updateFormData(sectionId, questionId, "action", e.target.value)}
      />

      {/* ✅ Follow-Up Checkbox - Preserves State */}
      <input
        type="checkbox"
        className={styles.checkbox}
        checked={savedData?.followUp || false}  // ✅ Ensures previous value is shown
        onChange={(e) => updateFormData(sectionId, questionId, "followUp", e.target.checked)}
      />
    </div>
  );
};

export default AuditRow;
