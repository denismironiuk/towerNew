import React from "react";
import { useAuth } from "../../context/AuthContext"; // ✅ Import AuthContext
import styles from "./Navbar.module.css";
import logo from "../../assets/Tower_Semiconductor.svg.png";
import userlogo from "../../assets/default.webp";

const Navbar = () => {
  const { user } = useAuth(); // ✅ Get logged-in user data

  return (
    <nav className={styles.navbar}>
      <img src={logo} alt="Company Logo" className={styles.logo} />
      
      <div className={styles.user}>
        <span>{user?.profile?.name || "Guest User"}</span>
        <img src={userlogo} alt="User" className={styles.userIcon} />
      </div>
    </nav>
  );
};

export default Navbar;
