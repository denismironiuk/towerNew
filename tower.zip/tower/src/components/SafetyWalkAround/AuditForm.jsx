import React, { useState, useEffect } from "react";
import styles from "./AuditForm.module.css";
import AuditSection from "./AuditSection";
import AuditActions from "./AuditActions";

// ✅ Define audit questions separately for easy updates
const auditSections = [
  {
    title: "Slip, Trip and Fall Hazards",
    id: "section1",
    questions: [
      { id: "q1", text: "Slip/trip hazards on floor?", example: "Wipes, liquids, power cords, etc." },
      { id: "q2", text: "Falling objects - above or below?", example: "Holes in floor or overhead items that could fall?" },
      { id: "q3", text: "Barricading Hazards?", example: "Are all hazardous areas properly barricaded?" },
      { id: "q4", text: "Is area organized as per site requirements?", example: "Trash disposed of, tools and parts not cluttering area?" },
    ],
  },
  {
    title: "Work Area Safety",
    id: "section2",
    questions: [
      { id: "q5", text: "Is the buddy system being used when required?", example: "Are certified technicians present during maintenance?" },
      { id: "q6", text: "Customer Spec or AMAT Procedure available?", example: "If PTP is required, is it properly completed and present?" },
      { id: "q7", text: "Proper ergonomic precautions being followed?", example: "Proper lifting, minimizing prolonged body positions?" },
    ],
  },
];

const AuditForm = ({ formData, setFormData }) => {
  const updateFormData = (sectionId, questionId, field, value) => {
    setFormData((prev) => ({
      ...prev,
      [sectionId]: {
        ...prev[sectionId],
        [questionId]: {
          ...prev[sectionId]?.[questionId],
          [field]: value,
        },
      },
    }));
  };

  return (
    <div className={styles.auditForm}>
      {auditSections.map((section) => (
        <AuditSection
          key={section.id}
          title={section.title}
          sectionId={section.id}
          questions={section.questions}
          updateFormData={updateFormData}
          formData={formData}  // ✅ Pass formData to pre-fill fields
        />
      ))}
    </div>
  );
};

export default AuditForm;
