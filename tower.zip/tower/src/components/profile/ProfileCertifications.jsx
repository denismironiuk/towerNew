import React from "react";


const ProfileCertifications = ({ certifications }) => {
  return (
    <section>
      <h2>Certification</h2>
      <ul>
        {certifications.map((cert, index) => (
          <li key={index}>
            {cert.name} <span>{cert.date}</span>
          </li>
        ))}
      </ul>
    </section>
  );
};

export default ProfileCertifications;
