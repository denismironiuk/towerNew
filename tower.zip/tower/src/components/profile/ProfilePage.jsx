import React, { useState, useEffect } from "react";
import { useAuth } from "../../context/AuthContext";
import { useNavigate } from "react-router-dom";
import { fetchUserProfile } from "../../fakeDB"; // ✅ Ensure correct import path
import ProfileSidebar from "./ProfileSidebar";
import ProfileContent from "./ProfileContent";
import styles from "./styles/ProfilePage.module.css";

const ProfilePage = () => {
  const { user } = useAuth();
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    if (user?.role === "admin") {
      navigate("/dashboard", { replace: true });
    }
  }, [user, navigate]);

  useEffect(() => {
    if (user) {
      fetchUserProfile(user.username).then((data) => {
        setProfile(data);
        setLoading(false);
      });
    }
  }, [user]);

  if (loading) {
    return <div className={styles.loading}>Loading profile...</div>;
  }

  return (
    <div className={styles.profilePage}>
      <ProfileSidebar user={profile} />
      <ProfileContent user={profile} />
    </div>
  );
};

export default ProfilePage;
