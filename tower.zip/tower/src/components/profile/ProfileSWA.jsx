import React from "react";


const ProfileSWA = ({ swa }) => {
  return (
    <section>
      <h2>SWA</h2>
      <p>Total: <strong>{swa.total}</strong></p>
      <p>Last: <strong>{swa.last}</strong></p>
    </section>
  );
};

export default ProfileSWA;
