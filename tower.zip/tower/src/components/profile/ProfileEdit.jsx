import React, { useState } from "react";
import styles from "./styles/ProfileEdit.module.css";

const ProfileEdit = ({ user, onSave, onCancel }) => {
  const [editedProfile, setEditedProfile] = useState(user);

  const handleChange = (e) => {
    setEditedProfile({
      ...editedProfile,
      [e.target.name]: e.target.value,
    });
  };

  const handleCertChange = (index, field, value) => {
    const updatedCertifications = [...editedProfile.certifications];
    updatedCertifications[index][field] = value;
    setEditedProfile({ ...editedProfile, certifications: updatedCertifications });
  };

  return (
    <div className={styles.editContainer}>
      <h2>Edit Profile</h2>
      <label>Name:</label>
      <input type="text" name="name" value={editedProfile.name} onChange={handleChange} />

      <label>Role:</label>
      <input type="text" name="role" value={editedProfile.role} onChange={handleChange} />

      <label>Department:</label>
      <input type="text" name="department" value={editedProfile.department} onChange={handleChange} />

      <h3>Certifications:</h3>
      {editedProfile.certifications.map((cert, index) => (
        <div key={index} className={styles.certRow}>
          <input
            type="text"
            value={cert.name}
            onChange={(e) => handleCertChange(index, "name", e.target.value)}
          />
          <input
            type="date"
            value={cert.date}
            onChange={(e) => handleCertChange(index, "date", e.target.value)}
          />
        </div>
      ))}

      <div className={styles.buttons}>
        <button onClick={() => onSave(editedProfile)}>Save</button>
        <button onClick={onCancel}>Cancel</button>
      </div>
    </div>
  );
};

export default ProfileEdit;
