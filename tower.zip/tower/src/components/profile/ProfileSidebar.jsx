import React from "react";
import styles from "./styles/ProfileSidebar.module.css";
import ProfilePic from "../../assets/default.webp";
import TowerLogo from "../../assets/Tower_Semiconductor.svg.png";
import { useAuth } from "../../context/AuthContext";

const ProfileSidebar = ({ user }) => {
    const { user: loggedInUser } = useAuth(); // Get logged-in user role
  return (
    <div className={styles.sidebar}>
      <img src={TowerLogo} alt="Tower Semiconductor" className={styles.logo} />
      <img src={ProfilePic} alt="User" className={styles.profileImage} />

      <div className={styles.info}>
        <h3>{user.name}</h3>
        <p>{user.role}</p>
        <p>{user.department}</p>
      </div>

      <nav className={styles.nav}>
        <ul>
          <li>👤 Personal Information</li>

          {/* Only show these options for SAM users */}
          {loggedInUser.role === "SAM" && (
            <>
              <li>👥 Subordinates</li>
              <li>📋 Tasks</li>
              <li>📑 Reports</li>
            </>
          )}
        </ul>
      </nav>
    </div>
  );
};

export default ProfileSidebar;
