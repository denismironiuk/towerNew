import React from "react";

const ProfileTutorials = ({ tutorials }) => {
  return (
    <section>
      <h2>Tutorials</h2>
      <ul>
        {tutorials.map((tutorial, index) => (
          <li key={index}>
            {tutorial.name} <span>{tutorial.date}</span>
          </li>
        ))}
      </ul>
    </section>
  );
};

export default ProfileTutorials;
