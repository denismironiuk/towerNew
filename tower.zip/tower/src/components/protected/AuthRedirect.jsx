import { Navigate } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";

const AuthRedirect = ({ children }) => {
  const { user } = useAuth();

  if (user) {
    return <Navigate to={user.role === "admin" ? "/dashboard" : "/profile"} replace />;
  }

  return children; // ✅ If not logged in, show login page
};

export default AuthRedirect;
