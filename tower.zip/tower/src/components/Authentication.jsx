import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { fakeLogin } from "../fakeDB"; // Import fake login function
import styles from "./Authentication.module.css";
import Tower from "../assets/Tower_Semiconductor.svg.png";

const Authentication = () => {
  const [userEmail, setUserEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const { login } = useAuth(); // Get login function from AuthContext

  const handleLogin = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      const user = await fakeLogin(username, password); // Fetch from fakeDB
      login(user); // Store user in AuthContext & localStorage
      console.log("Login successful:", user);

      // Redirect based on user role
      navigate(user.role === "admin" ? "/dashboard" : "/profile", { replace: true });
    } catch (err) {
      setError(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={styles.container}>
      <img src={Tower} alt="Tower Semiconductor" className={styles.logo} />
      <h2 className={styles.title}>Sign in to your account</h2>

      <form onSubmit={handleLogin} className={styles.form}>
        {error && <p className={styles.error}>{error}</p>}

        <div className={styles.inputContainer}>
          <label htmlFor="useremail">User Name:</label>
          <input
            type="email"
            id="useremail"
            placeholder="Enter your username"
            value={username}
            onChange={(e) => setUserEmail(e.target.value)}
            required
          />
        </div>

        <div className={styles.inputContainer}>
          <label htmlFor="password">Password:</label>
          <input
            type="password"
            id="password"
            placeholder="Enter your password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            autoComplete="current-password"
          />
        </div>

        <button type="submit" className={styles.signInButton} disabled={loading}>
          {loading ? "Signing in..." : "Sign In"}
        </button>
      </form>
    </div>
  );
};

export default Authentication;
